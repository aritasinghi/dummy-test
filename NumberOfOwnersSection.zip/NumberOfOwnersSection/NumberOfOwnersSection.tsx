import { useState, useRef, useEffect } from 'react';
import './NumberOfOwnersSection.css';

// =============================================================================
// Types
// =============================================================================

export interface NumberOfOwnersValue {
    /** One of the preset options, or 'custom' when the free-text number is in use. */
    preset: number | 'custom';
    /** The number actually submitted — either the preset or the parsed custom value. */
    count: number;
}

interface Texts {
    heading: string;
    include: string;
    largestOwnersSuffix: string;
    orSpecify: string;
}

const EN: Texts = {
    heading: 'Number of owners included in the report',
    include: 'Include',
    largestOwnersSuffix: 'largest owners. Or specify the number:',
    orSpecify: 'Or specify the number:',
};

const DEFAULT_PRESETS = [10, 25, 50, 100, 500, 1000];

interface Props {
    /** Only render this section when the active report type is Major Owners — pass that check in from the parent. */
    show: boolean;
    presets?: number[];
    /** Controlled value; omit to let the component manage its own state and just read via onChange. */
    value?: NumberOfOwnersValue;
    onChange: (value: NumberOfOwnersValue) => void;
    texts?: Partial<Texts>;
}

// =============================================================================
// Component
// =============================================================================

export default function NumberOfOwnersSection({
    show,
    presets = DEFAULT_PRESETS,
    value,
    onChange,
    texts,
}: Props) {
    const t: Texts = { ...EN, ...texts };

    const [internalPreset, setInternalPreset] = useState<number>(presets[0]);
    const [customValue, setCustomValue] = useState<string>('');
    const [isOpen, setIsOpen] = useState(false);
    const rootRef = useRef<HTMLDivElement>(null);

    const activePreset = value?.preset ?? internalPreset;

    useEffect(() => {
        function handleClickOutside(e: MouseEvent) {
            if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
                setIsOpen(false);
            }
        }
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    if (!show) return null;

    const selectPreset = (preset: number) => {
        setInternalPreset(preset);
        setCustomValue('');
        setIsOpen(false);
        onChange({ preset, count: preset });
    };

    const handleCustomChange = (raw: string) => {
        // digits only
        const cleaned = raw.replace(/[^\d]/g, '');
        setCustomValue(cleaned);
        const parsed = parseInt(cleaned, 10);
        if (!Number.isNaN(parsed) && parsed > 0) {
            onChange({ preset: 'custom', count: parsed });
        }
    };

    return (
        <section className="noo-section">
            <h3 className="noo-section__heading">{t.heading}</h3>

            <div className="noo-section__row">
                <span className="noo-section__label">{t.include}</span>

                <div className="noo-section__dropdown" ref={rootRef}>
                    <button
                        type="button"
                        className="noo-section__dropdown-trigger"
                        onClick={() => setIsOpen((o) => !o)}
                        aria-haspopup="listbox"
                        aria-expanded={isOpen}
                    >
                        <span>{typeof activePreset === 'number' ? activePreset : presets[0]}</span>
                        <svg
                            className={`noo-section__chevron${isOpen ? ' noo-section__chevron--open' : ''}`}
                            width="12"
                            height="8"
                            viewBox="0 0 12 8"
                            fill="none"
                        >
                            <path d="M1 1.5L6 6.5L11 1.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                    </button>

                    {isOpen && (
                        <ul className="noo-section__dropdown-list" role="listbox">
                            {presets.map((p) => (
                                <li
                                    key={p}
                                    role="option"
                                    aria-selected={activePreset === p}
                                    className={
                                        'noo-section__dropdown-item' +
                                        (activePreset === p ? ' noo-section__dropdown-item--selected' : '')
                                    }
                                    onClick={() => selectPreset(p)}
                                >
                                    {p}
                                </li>
                            ))}
                        </ul>
                    )}
                </div>

                <span className="noo-section__suffix">{t.largestOwnersSuffix}</span>

                <input
                    type="text"
                    inputMode="numeric"
                    className="noo-section__custom-input"
                    value={customValue}
                    placeholder=""
                    onChange={(e) => handleCustomChange(e.target.value)}
                />
            </div>
        </section>
    );
}
