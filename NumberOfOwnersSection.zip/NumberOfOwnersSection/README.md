# NumberOfOwnersSection

Standalone drop-in for the **Major Owners** report type. Renders the
"Number of owners included in the report" block: a dropdown of preset
counts (10 / 25 / 50 / 100 / 500 / 1000, configurable) plus a free-text
"Or specify the number" override — matching your screenshots exactly,
including the placement directly above the Cancel/Continue (PERUUTA/JATKA)
footer.

## Files

- `NumberOfOwnersSection.tsx`
- `NumberOfOwnersSection.css`

## Where it goes

You mentioned the one-time and recurring order forms now share a common
section file, separate from the two order-type-specific files. This
component is built to slot into that **common section file**, gated on
report type:

```tsx
import NumberOfOwnersSection, { NumberOfOwnersValue } from '@/components/NumberOfOwnersSection/NumberOfOwnersSection';

function CommonOrderSections({ reportType, ...otherProps }: CommonSectionsProps) {
    const [numberOfOwners, setNumberOfOwners] = useState<NumberOfOwnersValue>({ preset: 10, count: 10 });

    return (
        <>
            {/* ... your existing shared sections (Book-entry types and reference, etc.) ... */}

            <NumberOfOwnersSection
                show={reportType === 'Major Owners'}
                value={numberOfOwners}
                onChange={setNumberOfOwners}
            />

            {/* Footer: Cancel / Continue stays below this, unchanged */}
        </>
    );
}
```

Because `show` is a plain boolean prop, the component renders nothing
(`null`) for every other report type — no layout shift, no wrapping
`if` needed at the call site beyond the one prop.

## Behavior

- Default preset is the first entry in `presets` (10, matching your Figma).
- Picking a preset from the dropdown clears any custom number.
- Typing in "Or specify the number" is digit-only (non-digit characters are
  stripped as you type) and takes priority — `onChange` fires with
  `{ preset: 'custom', count: <parsed number> }`.
- Dropdown closes on outside click, matches keyboard-accessible listbox
  semantics (`role="listbox"` / `role="option"` / `aria-selected`).

## Payload shape

```ts
interface NumberOfOwnersValue {
    preset: number | 'custom';
    count: number; // the number to actually send to the backend
}
```

Merge `count` into your existing order payload however your API expects it
(e.g. `{ ...orderPayload, numberOfOwners: numberOfOwners.count }`).

## Still needed from you

To wire this into the real common-section file rather than this standalone
demo, upload that file (and the report-type switch that currently decides
what renders) whenever you're ready — same as the `SubscriptionModal`
request from before.
