
//src/Utils/helper.tsx
function getRandomDate() {
    const start = new Date(2023, 0, 1);   // Jan 1, 2023
    const end = new Date();               // today
    const date = new Date(
        start.getTime() +
        Math.random() * (end.getTime() - start.getTime())
    );

    // Format as DD.MM.YYYY
    return date.toLocaleDateString('fi-FI');
}

export default getRandomDate;