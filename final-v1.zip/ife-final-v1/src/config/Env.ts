// src/config/Env.ts

interface AppConfig {
    API_SERVER_URL: string;
}

export default class Env {
    static get appConfig(): AppConfig {
        const win = window as unknown as { appConfig?: AppConfig };

        if (!win.appConfig) {
            const request = new XMLHttpRequest();
            request.open('GET', `${window.location.origin}/config/env.json`, false);
            request.send(null);

            if (request.status === 200) {
                win.appConfig = JSON.parse(request.response);
            }
        }

        return win.appConfig!;
    }

    static get API_SERVER_URL() {
        return Env.appConfig.API_SERVER_URL;
    }
}