import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { reportsApi } from '@/api/services/reportsService';
import type { CreateReportOrderRequest } from '@/api/services/reportsService';

export function useReportTypes() {
    return useQuery({ queryKey: ['reportTypes'], queryFn: reportsApi.getReportTypes, staleTime: 10 * 60 * 1000 });
}

export function useCreateOrder() {
    const qc = useQueryClient();
    return useMutation({
        mutationFn: (req: CreateReportOrderRequest) => reportsApi.createOrder(req),
        onSuccess: () => qc.invalidateQueries({ queryKey: ['reportTypes'] }),
    });
}
