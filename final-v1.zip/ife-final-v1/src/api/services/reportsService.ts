import apiClient from '@/api/client';

export interface ReportTypeDTO {
    report_type_id: number;
    report_name: string;
    report_group: number;
}

export interface CreateReportOrderRequest {
    reportTypeId: number;
    organizationId: number;
    userId: string;
    // One-time order fields
    reportDate?: string;
    // Recurring order fields
    frequency?: string;
    dayOfMonth?: number;
    // Common fields
    reportTypeMode: 'full' | 'summary';   // NEW — Täysi / Vain yhteenveto
    instruments: number[];
    includeExpiredShares?: boolean;        // NEW — päättyneet arvo-osuuslajit
    referenceCode?: string;
}

export interface CreateOrderResponse {
    reportOrderId: number;
}

export const REPORT_TYPE_LABELS: Record<string, Record<string, string>> = {
    SHAREHOLDER_LIST: {
        en: 'SHAREHOLDER_LIST',
        fi: 'Liikkeeseenlaskijan osakasluettelo',
        sv: 'Emittentens aktieägarförteckning',
    },
    SHAREHOLDER_PUBLIC: {
        en: 'SHAREHOLDER_PUBLIC',
        fi: 'Julkinen osakasluettelo',
        sv: 'Offentlig aktieägarförteckning',
    },
    SHAREHOLDER_CUSTOM: {
        en: 'SHAREHOLDER_CUSTOM',
        fi: 'Osakaspoiminta',
        sv: 'Anpassat aktieägaruttag',
    },
    SHAREHOLDER_BIGGEST: {
        en: 'SHAREHOLDER_BIGGEST',
        fi: 'Suurimmat omistajat',
        sv: 'Största aktieägarna',
    },
    SECTOR_DISTRIBUTION: {
        en: 'SECTOR_DISTRIBUTION',
        fi: 'Sektorijakauma',
        sv: 'Sektorsfördelning',
    },
    OWNERSHIP_DISTRIBUTION: {
        en: 'OWNERSHIP_DISTRIBUTION',
        fi: 'Omistusmääräjakauma',
        sv: 'Äganderättsfördelning',
    },
    TEMPORARY_SHAREHOLDER_LIST: {
        en: 'TEMPORARY_SHAREHOLDER_LIST',
        fi: 'Tilapäinen osakasluettelo',
        sv: 'Tillfällig aktieägarförteckning',
    },
    SEQUENCE: {
        en: 'SEQUENCE',
        fi: 'Sektorijakauma',
        sv: 'Sektorsfördelning',
    },
};

export const REPORT_TYPE_DESCRIPTIONS: Record<string, string> = {
    'SHAREHOLDER_LIST':           'Raportti on luettelo liikkeeseenlaskijan puolesta ylläpidettävistä osakkeiden omistajista.',
    'SHAREHOLDER_PUBLIC':         'Raportti sisältää julkiset osakasluettelotiedot.',
    'SHAREHOLDER_CUSTOM':         'Raportissa kuvataan valittujen omistajien tiedot.',
    'SHAREHOLDER_BIGGEST':        'Raportti perustuu osakasluetteloon, mutta sisältää vain arvo-osuuksien suurimmat omistajat.',
    'SECTOR_DISTRIBUTION':        'Raportti perustuu Tilastokeskuksen sektoriluokitukseen ja kuvaa omistajien sektorijakaumaa.',
    'OWNERSHIP_DISTRIBUTION':     'Raportissa kuvataan omistusten jakauma osakkeenomistajien omistusten perusteella.',
    'TEMPORARY_SHAREHOLDER_LIST': 'Raportti sisältää liikkeeseenlaskijan osakasluetteloon merkityt omistajat yhtiökokouksen täsmäytyspäivältä.',
    'SEQUENCE':                   'Raportti perustuu Tilastokeskuksen sektoriluokitukseen.',
};

// Instrument value → backend index mapping
const INSTRUMENT_MAP: Record<string, number> = {
    'euroflex-a-1':   0,
    'euroflex-b-1':   1,
    'euroflex-c-1':   2,
    'euroflex-a-old': 3,
    'euroflex-b-old': 4,
};

export const reportsApi = {
    getReportTypes: async (): Promise<ReportTypeDTO[]> => {
        const { data } = await apiClient.get<ReportTypeDTO[]>('/reports/reporttypes');
        return data;
    },

    createOrder: async (request: CreateReportOrderRequest): Promise<CreateOrderResponse> => {
        const { data } = await apiClient.post<CreateOrderResponse>('/reports/order/', request);
        return data;
    },
};

/**
 * Maps SubscriptionFormData from the modal into a CreateReportOrderRequest
 * for the backend API. Handles both one-time and recurring orders.
 */
export function mapFormToOrderRequest(
    form: {
        orderType: string;
        dateMode: string;
        selectedDate?: Date;
        reportTypeMode: 'full' | 'summary';
        frequency: string;
        dayOfMonth: number;
        selectedShares: string[];
        reference: string;
    },
    reportTypeId: number,
): CreateReportOrderRequest {
    const EXPIRED_VALUES = ['euroflex-a-old', 'euroflex-b-old'];
    const includeExpiredShares = form.selectedShares.some(s => EXPIRED_VALUES.includes(s));
    const instruments = form.selectedShares.map(v => INSTRUMENT_MAP[v] ?? 0);

    const base = {
        reportTypeId,
        organizationId: 1234567,
        userId: 'demo_user',
        reportTypeMode: form.reportTypeMode,
        instruments,
        includeExpiredShares,
        referenceCode: form.reference || undefined,
    };

    if (form.orderType === 'one-time') {
        let reportDate: string;
        if (form.dateMode === 'latest') {
            const d = new Date();
            d.setDate(d.getDate() - 1);
            reportDate = d.toISOString().slice(0, 10);
        } else if (form.dateMode === 'end-of-day') {
            reportDate = new Date().toISOString().slice(0, 10);
        } else {
            reportDate = form.selectedDate!.toISOString().slice(0, 10);
        }
        return { ...base, reportDate };
    } else {
        // Recurring
        const needsDay = ['monthly', 'quarterly', 'yearly'].includes(form.frequency);
        return {
            ...base,
            frequency: form.frequency,
            dayOfMonth: needsDay ? form.dayOfMonth : undefined,
        };
    }
}
