import "./Field.css";

interface FieldProps {
    heading: string;
    value: string;
}

export default function Field({ heading, value }: FieldProps) {
    return (
        <div className="FieldWrapper">
            <div className="FieldHeading">{heading}</div>
            <div className="StaticBox">{value}</div>
        </div>
    );
}