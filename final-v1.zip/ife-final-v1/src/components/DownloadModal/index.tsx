import { useState } from 'react';
import {
    Dialog,
    Button,
    RadioGroup,
    Radio,
    Checkbox,
} from '@efi/efi-ui-components';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import './DownloadModal.css';

type ReportType = 'short' | 'full' | 'agm' | 'statutory';
type FileType = 'csv' | 'xls' | 'pdf';

interface DownloadModalProps {
    isOpen: boolean;
    language: Language;
    onClose: () => void;
    onDownload: (options: DownloadOptions) => void;
}

export interface DownloadOptions {
    reportType: ReportType;
    useFilteredVersion: boolean;
    fileType: FileType;
    downloadLanguage: 'fi' | 'en';
}

export function DownloadModal({ isOpen, language, onClose, onDownload }: DownloadModalProps) {
    const t = translations[language].downloadModal;
    const rt = translations[language].reportView;
    const rp = translations[language].reportPreview;

    const [reportType, setReportType] = useState<ReportType>('full');
    const [useFiltered, setUseFiltered] = useState(true);
    const [fileType, setFileType] = useState<FileType>('csv');
    const [dlLang, setDlLang] = useState<string>('fi');

    if (!isOpen) return null;

    const reportTypes: { key: ReportType; label: string; desc: string }[] = [
        { key: 'short', label: rp.short, desc: rt.shortDesc },
        { key: 'full', label: rp.full, desc: rt.fullDesc },
        { key: 'agm', label: rp.agm, desc: rt.agmDesc },
        { key: 'statutory', label: rp.statutory, desc: rt.statutoryDesc },
    ];

    const handleDownload = () => {
        onDownload({
            reportType,
            useFilteredVersion: useFiltered,
            fileType,
            downloadLanguage: dlLang as 'fi' | 'en',
        });
    };

    return (
        <div className="dl-modal-dialog">
        <Dialog closeLabel={t.cancel} onClose={onClose}>
            <Dialog.Title>{t.title}</Dialog.Title>

            <Dialog.Content>
                {/* Report type */}
                <section className="dl-modal__section">
                    <h3 className="dl-modal__label">{t.reportTypeTitle}</h3>
                    <RadioGroup
                        name="dlReportType"
                        value={reportType}
                        onValueChange={(_, val) => setReportType(val as ReportType)}
                    >
                        {reportTypes.map(({ key, label, desc }) => (
                            <Radio key={key} value={key}>
                                <Radio.Label>
                                    <strong>{label}</strong>
                                    <span className="dl-modal__radio-desc">{desc}</span>
                                </Radio.Label>
                            </Radio>
                        ))}
                    </RadioGroup>
                </section>

                <hr className="dl-modal__divider" />

                {/* Filter */}
                <section className="dl-modal__section dl-modal__filter-row">
                    <h3 className="dl-modal__label">{t.filterTitle}</h3>
                    <Checkbox
                        name="useFiltered"
                        value="filtered"
                        checked={useFiltered}
                        onChange={() => setUseFiltered(!useFiltered)}
                    >
                        <Checkbox.Label>{t.filterUserVersion}</Checkbox.Label>
                    </Checkbox>
                </section>

                <hr className="dl-modal__divider" />

                {/* File type */}
                <section className="dl-modal__section">
                    <h3 className="dl-modal__label">{t.fileTypeTitle}</h3>
                    <RadioGroup
                        name="dlFileType"
                        value={fileType}
                        onValueChange={(_, val) => setFileType(val as FileType)}
                    >
                        <div className="dl-modal__inline-radios">
                            <Radio value="csv"><Radio.Label>CSV</Radio.Label></Radio>
                            <Radio value="xls"><Radio.Label>XLS</Radio.Label></Radio>
                            <Radio value="pdf"><Radio.Label>PDF</Radio.Label></Radio>
                        </div>
                    </RadioGroup>
                </section>

                <hr className="dl-modal__divider" />

                {/* Language */}
                <section className="dl-modal__section">
                    <h3 className="dl-modal__label">{t.languageTitle}</h3>
                    <RadioGroup
                        name="dlLang"
                        value={dlLang}
                        onValueChange={(_, val) => setDlLang(val)}
                    >
                        <div className="dl-modal__inline-radios">
                            <Radio value="fi"><Radio.Label>Suomi</Radio.Label></Radio>
                            <Radio value="en"><Radio.Label>English</Radio.Label></Radio>
                        </div>
                    </RadioGroup>
                </section>
            </Dialog.Content>

            <Dialog.Buttons>
                <Button type="reset" variant="secondary" onClick={onClose}>
                    {t.cancel}
                </Button>
                <Button type="submit" onClick={handleDownload}>
                    {t.download}
                </Button>
            </Dialog.Buttons>
        </Dialog>
        </div>
    );
}
