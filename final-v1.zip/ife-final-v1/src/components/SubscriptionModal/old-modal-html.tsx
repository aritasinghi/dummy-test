import { useState } from 'react';
import {
    Dialog,
    Button,
    RadioGroup,
    Radio,
    CheckboxGroup,
    Checkbox,
    Input,
} from '@efi/efi-ui-components';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import { DatePicker } from '@/components/DatePicker';
import './SubscriptionModal.css';

type OrderType = 'one-time' | 'recurring';
type DateMode = 'latest' | 'end-of-day' | 'custom';
type Frequency = 'daily' | 'monthly' | 'monthly-last' | 'quarterly' | 'quarterly-last' | 'yearly';

interface SubscriptionModalProps {
    isOpen: boolean;
    reportTitle: string;
    onClose: () => void;
    onSubmit: (data: SubscriptionFormData) => void;
    language?: Language;
}

export interface SubscriptionFormData {
    orderType: OrderType;
    dateMode: DateMode;
    selectedDate?: Date;
    frequency: Frequency;
    dayOfMonth: number;
    selectedShares: string[];
    reference: string;
}

const SHARE_OPTIONS = [
    { value: 'euroflex-a-1', label: 'Euroflex A', isin: 'FI21049685930' },
    { value: 'euroflex-b-1', label: 'Euroflex B', isin: 'FI21049685931' },
    { value: 'euroflex-b-2', label: 'Euroflex B', isin: 'FI21049685931' },
    { value: 'euroflex-a-2', label: 'Euroflex A', isin: 'FI21049685930' },
    { value: 'euroflex-b-3', label: 'Euroflex B', isin: 'FI21049685931' },
    { value: 'euroflex-b-4', label: 'Euroflex B', isin: 'FI21049685931' },
];

export function SubscriptionModal({ isOpen, reportTitle, onClose, onSubmit, language = 'fi' }: SubscriptionModalProps) {
    const t = translations[language].subscription;
    const [orderType, setOrderType] = useState<OrderType>('one-time');
    const [dateMode, setDateMode] = useState<DateMode>('custom');
    const [selectedDate, setSelectedDate] = useState<Date | null>(new Date(2024, 1, 22));
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [frequency, setFrequency] = useState<Frequency>('monthly');
    const [dayOfMonth, setDayOfMonth] = useState('31');
    const [selectedShares, setSelectedShares] = useState<string[]>(SHARE_OPTIONS.map(s => s.value));
    const [reference, setReference] = useState('');

    if (!isOpen) return null;

    const dateLocale = language === 'fi' ? 'fi-FI' : language === 'sv' ? 'sv-SE' : 'en-GB';

    const handleSubmit = () => {
        onSubmit({
            orderType, dateMode, selectedDate: selectedDate ?? undefined,
            frequency, dayOfMonth: Number(dayOfMonth),
            selectedShares, reference,
        });
    };

    const getFrequencyInfo = () => {
        if (frequency.startsWith('monthly')) return t.frequencyInfoMonthly;
        if (frequency.startsWith('quarterly')) return t.frequencyInfoQuarterly;
        if (frequency === 'yearly') return t.frequencyInfoYearly;
        return t.frequencyInfoMonthly;
    };

    return (
        <>
            <div className="sub-modal-dialog">
                <Dialog
                    closeLabel={t.cancel}
                    onClose={onClose}
                    style={{ maxWidth: "auto" }}
                >
                    <Dialog.Title>{t.title}: {reportTitle}  </Dialog.Title>
                        {/* ── Order type toggle ── */}
                        <RadioGroup
                            name="orderType"
                            value={orderType}
                            onValueChange={(_, val) => setOrderType(val as OrderType)}
                        >
                            <div className="sub-modal__order-toggle">
                                <Radio value="one-time">
                                    <Radio.Label>{t.oneTime}</Radio.Label>
                                </Radio>
                                <Radio value="recurring">
                                    <Radio.Label>{t.recurring}</Radio.Label>
                                </Radio>
                            </div>
                        </RadioGroup>


                    <Dialog.Content>


                        <hr className="sub-modal__divider" />

                        {/* ══ ONE-TIME ══ */}
                        {orderType === 'one-time' && (
                            <section className="sub-modal__section">
                                <h3 className="sub-modal__section-title">{t.oneTimeTitle}</h3>
                                <div className="sub-modal__two-col">
                                    <div className="sub-modal__col-left">
                                        <h4 className="sub-modal__label">{t.reportDateTitle}</h4>
                                        <RadioGroup
                                            name="dateMode"
                                            value={dateMode}
                                            onValueChange={(_, val) => setDateMode(val as DateMode)}
                                        >
                                            <div className="sub-modal__date-modes">
                                                <div className="sub-modal__date-modes-col">
                                                    <Radio value="latest">
                                                        <Radio.Label>{t.dateLatest}</Radio.Label>
                                                    </Radio>
                                                    <Radio value="end-of-day">
                                                        <Radio.Label>{t.dateEndOfDay}</Radio.Label>
                                                    </Radio>
                                                </div>
                                                <div className="sub-modal__date-modes-col">
                                                    <Radio value="custom">
                                                        <Radio.Label>{t.dateSelectCustom}</Radio.Label>
                                                    </Radio>
                                                    {dateMode === 'custom' && (
                                                        <div className="sub-modal__date-input-wrap">
                                                            <button type="button" className="sub-modal__date-trigger" onClick={() => setShowDatePicker(true)}>
                                                                {selectedDate ? selectedDate.toLocaleDateString(dateLocale) : t.selectDateLabel}
                                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                                    <rect x="2" y="3" width="12" height="11" rx="1.5" stroke="currentColor" strokeWidth="1.2" />
                                                                    <path d="M2 6.5h12" stroke="currentColor" strokeWidth="1.2" />
                                                                    <path d="M5 1.5v3M11 1.5v3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
                                                                </svg>
                                                            </button>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        </RadioGroup>
                                    </div>
                                    <div className="sub-modal__info-box sub-modal__info-box--light">
                                        <h4 className="sub-modal__info-title">{t.dateInfoTitle}</h4>
                                        <p className="sub-modal__info-text">{t.dateInfoDesc}</p>
                                    </div>
                                </div>
                            </section>
                        )}

                        {/* ══ RECURRING ══ */}
                        {orderType === 'recurring' && (
                            <section className="sub-modal__section">
                                <h3 className="sub-modal__section-title">{t.recurringTitle}</h3>
                                <div className="sub-modal__two-col">
                                    <div className="sub-modal__col-left">
                                        <h4 className="sub-modal__label">{t.frequencyTitle}</h4>
                                        <RadioGroup
                                            name="frequency"
                                            value={frequency}
                                            onValueChange={(_, val) => setFrequency(val as Frequency)}
                                        >
                                            <div className="sub-modal__freq-grid">
                                                <Radio value="daily"><Radio.Label>{t.daily}</Radio.Label></Radio>
                                                <Radio value="monthly"><Radio.Label>{t.monthly}</Radio.Label></Radio>
                                                <Radio value="monthly-last"><Radio.Label>{t.monthlyLast}</Radio.Label></Radio>
                                                <Radio value="quarterly"><Radio.Label>{t.quarterly}</Radio.Label></Radio>
                                                <Radio value="quarterly-last"><Radio.Label>{t.quarterlyLast}</Radio.Label></Radio>
                                                <Radio value="yearly"><Radio.Label>{t.yearly}</Radio.Label></Radio>
                                            </div>
                                        </RadioGroup>

                                        {(frequency === 'monthly' || frequency === 'quarterly' || frequency === 'yearly') && (
                                            <Input type="number" value={dayOfMonth} onChange={(e) => setDayOfMonth(e.target.value)}>
                                                <Input.Label>{t.selectDay}</Input.Label>
                                            </Input>
                                        )}
                                    </div>
                                    <div className="sub-modal__info-stack">
                                        <div className="sub-modal__info-box sub-modal__info-box--light">
                                            <h4 className="sub-modal__info-title">{t.frequencyInfoTitle}</h4>
                                            <p className="sub-modal__info-text">{getFrequencyInfo()}</p>
                                        </div>
                                        <div className="sub-modal__info-box sub-modal__info-box--pink">
                                            <p className="sub-modal__info-text">{t.frequencyInfoMonthlyNote}</p>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        )}

                        <hr className="sub-modal__divider" />

                        {/* ── Shares ── */}
                        <section className="sub-modal__section">
                            <div className="sub-modal__two-col">
                                <div className="sub-modal__col-left">
                                    <h3 className="sub-modal__section-title">{t.sharesTitle}</h3>
                                    <p className="sub-modal__shares-type">{t.shareType}</p>
                                    <CheckboxGroup
                                        name="shares"
                                        value={selectedShares}
                                        onValueChange={(_, values) => setSelectedShares(values)}
                                    >
                                        <div className="sub-modal__shares-grid">
                                            {SHARE_OPTIONS.map((share) => (
                                                <Checkbox
                                                    key={share.value}
                                                    name="shares"              // ← REQUIRED
                                                    value={share.value}
                                                >
                                                    <Checkbox.Label>
                                                        <span className="sub-modal__checkbox-name">{share.label}</span>
                                                        <span className="sub-modal__checkbox-isin">{share.isin}</span>
                                                    </Checkbox.Label>
                                                </Checkbox>
                                            ))}
                                        </div>
                                    </CheckboxGroup>
                                </div>
                                <div className="sub-modal__info-box sub-modal__info-box--light">
                                    <h4 className="sub-modal__info-title">{t.shareSelectionTitle}</h4>
                                    <p className="sub-modal__info-text">{t.shareSelectionDesc}</p>
                                </div>
                            </div>
                        </section>

                        <hr className="sub-modal__divider" />

                        {/* ── Reference ── */}
                        <section className="sub-modal__section">
                            <div className="sub-modal__two-col">
                                <div className="sub-modal__col-left">
                                    <Input type="text" value={reference} onChange={(e) => setReference(e.target.value)}>
                                        <Input.Label>{t.referenceLabel}</Input.Label>
                                        <Input.Description>{t.referencePlaceholder}</Input.Description>
                                    </Input>
                                </div>
                                <div className="sub-modal__info-box sub-modal__info-box--light">
                                    <h4 className="sub-modal__info-title">{t.referenceInfoTitle}</h4>
                                    <p className="sub-modal__info-text">{t.referenceInfoDesc}</p>
                                </div>
                            </div>
                        </section>

                        <hr className="sub-modal__divider" />

                        {/* ── Price ── */}
                        <div className="sub-modal__price-row">
                            <p className="sub-modal__price-note">{t.priceNote}</p>
                            <p className="sub-modal__price-next">{t.priceNextView}</p>
                        </div>
                    </Dialog.Content>

                    <Dialog.Buttons>
                        <Button type="reset" variant="secondary" onClick={onClose}>
                            {t.cancel}
                        </Button>
                        <Button type="submit" onClick={handleSubmit}>
                            {t.submit}
                        </Button>
                    </Dialog.Buttons>
                </Dialog>
            </div>

            {/* DatePicker overlay — above the dialog */}
            <DatePicker
                isOpen={showDatePicker}
                lang={language}
                selectedDate={selectedDate ?? undefined}
                onSelect={(d) => { setSelectedDate(d); setShowDatePicker(false); }}
                onCancel={() => setShowDatePicker(false)}
            />
        </>
    );
}
