import { useState } from 'react';
import {
    Dialog,
    Button,
    RadioGroup,
    Radio,
    Input,
} from '@efi/efi-ui-components';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import { DatePicker } from '@/components/DatePicker';
import './SubscriptionModal.css';

// ─── Types ────────────────────────────────────────────────────────────────────

type OrderType = 'one-time' | 'recurring';
type DateMode = 'latest' | 'end-of-day' | 'custom';
type ReportTypeMode = 'full' | 'summary';
type Frequency = 'daily' | 'monthly' | 'monthly-last' | 'quarterly' | 'quarterly-last' | 'yearly';

export interface SubscriptionFormData {
    orderType: OrderType;
    dateMode: DateMode;
    selectedDate?: Date;
    reportTypeMode: ReportTypeMode;
    frequency: Frequency;
    dayOfMonth: number;
    selectedShares: string[];
    reference: string;
}

interface SubscriptionModalProps {
    isOpen: boolean;
    reportTitle: string;
    onClose: () => void;
    onSubmit: (data: SubscriptionFormData) => void;
    language?: Language;
}

// ─── Validation types ─────────────────────────────────────────────────────────

interface FormErrors {
    dateMode?: string;
    selectedDate?: string;
    selectedShares?: string;
    dayOfMonth?: string;
    reference?: string;
}

// ─── Share data ───────────────────────────────────────────────────────────────

const ACTIVE_SHARES = [
    { value: 'euroflex-a-1', label: 'Euroflex A', isin: 'FI21049685930' },
    { value: 'euroflex-b-1', label: 'Euroflex B', isin: 'FI21049685931' },
    { value: 'euroflex-c-1', label: 'Euroflex C', isin: 'FI21049685932' },
];

const EXPIRED_SHARES = [
    { value: 'euroflex-a-old', label: 'OLDEuroflex A (05/17)', isin: 'FI21049685930' },
    { value: 'euroflex-b-old', label: 'OLDEuroflex B (05/17)', isin: 'FI21049685931' },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function validate(
    orderType: OrderType,
    dateMode: DateMode,
    selectedDate: Date | null,
    selectedShares: string[],
    frequency: Frequency,
    dayOfMonth: string,
    reference: string,
): FormErrors {
    const errors: FormErrors = {};

    // Date validation (one-time only)
    if (orderType === 'one-time') {
        if (!dateMode) {
            errors.dateMode = 'Valitse raporttipäivä';
        }
        if (dateMode === 'custom' && !selectedDate) {
            errors.selectedDate = 'Valitse päivämäärä';
        }
        if (dateMode === 'custom' && selectedDate) {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const maxDate = new Date(today);
            maxDate.setFullYear(maxDate.getFullYear() + 1);
            if (selectedDate > maxDate) {
                errors.selectedDate = 'Päivämäärä ei voi olla yli vuosi tulevaisuudessa';
            }
        }
    }

    // Day of month validation (recurring)
    if (orderType === 'recurring') {
        if (['monthly', 'quarterly', 'yearly'].includes(frequency)) {
            const day = Number(dayOfMonth);
            if (!dayOfMonth || isNaN(day) || day < 1 || day > 31) {
                errors.dayOfMonth = 'Syötä päivä välillä 1–31';
            }
        }
    }

    // At least one share selected
    if (selectedShares.length === 0) {
        errors.selectedShares = 'Valitse vähintään yksi arvo-osuuslaji';
    }

    // Reference: alphanumeric only, max 20 chars
    if (reference && !/^[a-zA-Z0-9]{0,20}$/.test(reference)) {
        errors.reference = 'Viite saa sisältää vain kirjaimia ja numeroita (max 20)';
    }

    return errors;
}

// ─── Component ────────────────────────────────────────────────────────────────

export function SubscriptionModal({
    isOpen, reportTitle, onClose, onSubmit, language = 'fi'
}: SubscriptionModalProps) {
    const t = translations[language].subscription;

    // Form state
    const [orderType, setOrderType] = useState<OrderType>('one-time');
    const [dateMode, setDateMode] = useState<DateMode>('latest');
    const [selectedDate, setSelectedDate] = useState<Date | null>(null);
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [reportTypeMode, setReportTypeMode] = useState<ReportTypeMode>('full');
    const [frequency, setFrequency] = useState<Frequency>('monthly');
    const [dayOfMonth, setDayOfMonth] = useState('31');
    const [selectedShares, setSelectedShares] = useState<string[]>(ACTIVE_SHARES.map(s => s.value));
    const [showExpired, setShowExpired] = useState(false);
    const [selectedExpiredShares, setSelectedExpiredShares] = useState<string[]>([]);
    const [reference, setReference] = useState('');

    // Validation state
    const [errors, setErrors] = useState<FormErrors>({});
    const [submitted, setSubmitted] = useState(false);

    if (!isOpen) return null;

    const dateLocale = language === 'fi' ? 'fi-FI' : language === 'sv' ? 'sv-SE' : 'en-GB';

    const allSelectedShares = [
        ...selectedShares,
        ...(showExpired ? selectedExpiredShares : []),
    ];

    const toggleShare = (
        value: string,
        list: string[],
        setList: (v: string[]) => void
    ) => {
        const updated = list.includes(value)
            ? list.filter(v => v !== value)
            : [...list, value];
        setList(updated);
        // Clear share error if at least one selected
        if (submitted && updated.length > 0) {
            setErrors(e => ({ ...e, selectedShares: undefined }));
        }
    };

    const getFrequencyInfo = () => {
        if (frequency.startsWith('monthly')) return t.frequencyInfoMonthly;
        if (frequency.startsWith('quarterly')) return t.frequencyInfoQuarterly;
        if (frequency === 'yearly') return t.frequencyInfoYearly;
        return t.frequencyInfoMonthly;
    };

    const handleSubmit = () => {
        setSubmitted(true);
        const errs = validate(
            orderType, dateMode, selectedDate,
            allSelectedShares, frequency, dayOfMonth, reference
        );
        setErrors(errs);

        if (Object.keys(errs).length > 0) return;

        onSubmit({
            orderType,
            dateMode,
            selectedDate: selectedDate ?? undefined,
            reportTypeMode,
            frequency,
            dayOfMonth: Number(dayOfMonth),
            selectedShares: allSelectedShares,
            reference,
        });

        // Reset
        setOrderType('one-time');
        setDateMode('latest');
        setSelectedDate(null);
        setReportTypeMode('full');
        setFrequency('monthly');
        setDayOfMonth('31');
        setSelectedShares(ACTIVE_SHARES.map(s => s.value));
        setShowExpired(false);
        setSelectedExpiredShares([]);
        setReference('');
        setErrors({});
        setSubmitted(false);
    };

    const handleClose = () => {
        setErrors({});
        setSubmitted(false);
        onClose();
    };

    return (
        <>
            <div className="sub-modal-dialog">
                <Dialog closeLabel={t.cancel} onClose={handleClose} maxWidth="max-content">
                    <Dialog.Content>

                        {/* ── Title + order type toggle ── */}
                        <div className="sub-modal__title-row">
                            <h4 className="sub-modal__title">{t.title}: {reportTitle}</h4>
                            <RadioGroup
                                name="orderType"
                                value={orderType}
                                onValueChange={(_, val) => {
                                    setOrderType(val as OrderType);
                                    setErrors({});
                                    setSubmitted(false);
                                }}
                            >
                                <div className="sub-modal__order-toggle">
                                    <Radio value="one-time"><Radio.Label>{t.oneTime}</Radio.Label></Radio>
                                    <Radio value="recurring"><Radio.Label>{t.recurring}</Radio.Label></Radio>
                                </div>
                            </RadioGroup>
                        </div>

                        <hr className="sub-modal__divider" />

                        {/* ══════════════════════════════════════════════
                            ONE-TIME ORDER
                        ══════════════════════════════════════════════ */}
                        {orderType === 'one-time' && (
                            <>
                                {/* Status date */}
                                <section className="sub-modal__section">
                                    <h3 className="sub-modal__section-title">{t.oneTimeTitle}</h3>
                                    <div className="sub-modal__two-col">
                                        <div className="sub-modal__col-left">
                                            <h4 className="sub-modal__label">{t.reportDateTitle}</h4>
                                            {errors.dateMode && (
                                                <p className="sub-modal__error">{errors.dateMode}</p>
                                            )}
                                            <RadioGroup
                                                name="dateMode"
                                                value={dateMode}
                                                onValueChange={(_, val) => {
                                                    setDateMode(val as DateMode);
                                                    if (submitted) setErrors(e => ({ ...e, dateMode: undefined, selectedDate: undefined }));
                                                }}
                                            >
                                                <div className="sub-modal__date-modes">
                                                    <div className="sub-modal__date-modes-col">
                                                        <Radio value="latest">
                                                            <Radio.Label>{t.dateLatest}</Radio.Label>
                                                        </Radio>
                                                        <Radio value="end-of-day">
                                                            <Radio.Label>{t.dateEndOfDay}</Radio.Label>
                                                        </Radio>
                                                    </div>
                                                    <div className="sub-modal__date-modes-col">
                                                        <Radio value="custom">
                                                            <Radio.Label>{t.dateSelectCustom}</Radio.Label>
                                                        </Radio>
                                                        {/* Fixed-height placeholder — no layout shift */}
                                                        <div className="sub-modal__date-placeholder">
                                                            {dateMode === 'custom' ? (
                                                                <div>
                                                                    <button
                                                                        type="button"
                                                                        className={`sub-modal__date-trigger ${errors.selectedDate ? 'sub-modal__date-trigger--error' : ''}`}
                                                                        onClick={() => setShowDatePicker(true)}
                                                                    >
                                                                        <span className="sub-modal__date-label">{t.selectDateLabel}</span>
                                                                        <span className="sub-modal__date-value">
                                                                            {selectedDate
                                                                                ? selectedDate.toLocaleDateString(dateLocale)
                                                                                : <span className="sub-modal__date-placeholder-text">pp.kk.vvvv</span>
                                                                            }
                                                                        </span>
                                                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                                            <rect x="2" y="3" width="12" height="11" rx="1.5" stroke="currentColor" strokeWidth="1.2" />
                                                                            <path d="M2 6.5h12" stroke="currentColor" strokeWidth="1.2" />
                                                                            <path d="M5 1.5v3M11 1.5v3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
                                                                        </svg>
                                                                    </button>
                                                                    {errors.selectedDate && (
                                                                        <p className="sub-modal__error sub-modal__error--sm">{errors.selectedDate}</p>
                                                                    )}
                                                                </div>
                                                            ) : (
                                                                <div className="sub-modal__date-trigger sub-modal__date-trigger--ghost" aria-hidden="true" />
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                            </RadioGroup>
                                        </div>
                                        <div className="sub-modal__info-box sub-modal__info-box--light">
                                            <h4 className="sub-modal__info-title">{t.dateInfoTitle}</h4>
                                            <p className="sub-modal__info-text">{t.dateInfoDesc}</p>
                                        </div>
                                    </div>
                                </section>

                                <hr className="sub-modal__divider" />

                                {/* Raportin tyyppi — Täysi / Vain yhteenveto */}
                                <section className="sub-modal__section">
                                    <div className="sub-modal__two-col">
                                        <div className="sub-modal__col-left">
                                            <h4 className="sub-modal__label">Raportin tyyppi</h4>
                                            <RadioGroup
                                                name="reportTypeMode"
                                                value={reportTypeMode}
                                                onValueChange={(_, val) => setReportTypeMode(val as ReportTypeMode)}
                                            >
                                                <div className="sub-modal__freq-grid sub-modal__freq-grid--2col">
                                                    <Radio value="full">
                                                        <Radio.Label>Täysi raportti</Radio.Label>
                                                    </Radio>
                                                    <Radio value="summary">
                                                        <Radio.Label>Vain yhteenveto</Radio.Label>
                                                    </Radio>
                                                </div>
                                            </RadioGroup>
                                        </div>
                                        <div className="sub-modal__info-stack">
                                            <div className="sub-modal__info-box sub-modal__info-box--light">
                                                <h4 className="sub-modal__info-title">Täysi raportti</h4>
                                                <p className="sub-modal__info-text">Täysi raportti sisältää nimensä mukaisesti ...</p>
                                            </div>
                                            <div className="sub-modal__info-box sub-modal__info-box--light sub-modal__info-box--mt">
                                                <h4 className="sub-modal__info-title">Yhteenveto</h4>
                                                <p className="sub-modal__info-text">Yhteenveto sisältää ...</p>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </>
                        )}

                        {/* ══════════════════════════════════════════════
                            RECURRING ORDER
                        ══════════════════════════════════════════════ */}
                        {orderType === 'recurring' && (
                            <section className="sub-modal__section">
                                <h3 className="sub-modal__section-title">{t.recurringTitle}</h3>
                                <div className="sub-modal__two-col">
                                    <div className="sub-modal__col-left">
                                        <h4 className="sub-modal__label">{t.frequencyTitle}</h4>
                                        <RadioGroup
                                            name="frequency"
                                            value={frequency}
                                            onValueChange={(_, val) => {
                                                setFrequency(val as Frequency);
                                                if (submitted) setErrors(e => ({ ...e, dayOfMonth: undefined }));
                                            }}
                                        >
                                            <div className="sub-modal__freq-grid">
                                                <Radio value="daily"><Radio.Label>{t.daily}</Radio.Label></Radio>
                                                <Radio value="monthly"><Radio.Label>{t.monthly}</Radio.Label></Radio>
                                                <Radio value="monthly-last"><Radio.Label>{t.monthlyLast}</Radio.Label></Radio>
                                                <Radio value="quarterly"><Radio.Label>{t.quarterly}</Radio.Label></Radio>
                                                <Radio value="quarterly-last"><Radio.Label>{t.quarterlyLast}</Radio.Label></Radio>
                                                <Radio value="yearly"><Radio.Label>{t.yearly}</Radio.Label></Radio>
                                            </div>
                                        </RadioGroup>

                                        {['monthly', 'quarterly', 'yearly'].includes(frequency) && (
                                            <div className="sub-modal__day-select">
                                                <Input
                                                    style={{ width: '50%' }}
                                                    type="number"
                                                    value={dayOfMonth}
                                                    onChange={(e) => {
                                                        setDayOfMonth(e.target.value);
                                                        if (submitted) setErrors(er => ({ ...er, dayOfMonth: undefined }));
                                                    }}
                                                    invalid={!!errors.dayOfMonth}
                                                >
                                                    <Input.Label>{t.selectDay}</Input.Label>
                                                    {errors.dayOfMonth && (
                                                        <Input.ErrorMessage>{errors.dayOfMonth}</Input.ErrorMessage>
                                                    )}
                                                </Input>
                                            </div>
                                        )}
                                    </div>
                                    <div className="sub-modal__info-stack">
                                        <div className="sub-modal__info-box sub-modal__info-box--light">
                                            <h4 className="sub-modal__info-title">{t.frequencyInfoTitle}</h4>
                                            <p className="sub-modal__info-text">{getFrequencyInfo()}</p>
                                        </div>
                                        <div className="sub-modal__info-box sub-modal__info-box--pink sub-modal__info-box--mt">
                                            <p className="sub-modal__info-text">{t.frequencyInfoMonthlyNote}</p>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        )}

                        <hr className="sub-modal__divider" />

                        {/* ── Arvo-osuuslajit ja viite ── */}
                        <section className="sub-modal__section">
                            <div className="sub-modal__two-col">
                                <div className="sub-modal__col-left">
                                    <h3 className="sub-modal__section-title">{t.sharesTitle}</h3>
                                    <p className="sub-modal__shares-type">{t.shareType}</p>

                                    {errors.selectedShares && (
                                        <p className="sub-modal__error">{errors.selectedShares}</p>
                                    )}

                                    {/* Active shares */}
                                    <div className="sub-modal__shares-grid">
                                        {ACTIVE_SHARES.map((share) => (
                                            <label key={share.value} className="sub-modal__checkbox-option">
                                                <input
                                                    type="checkbox"
                                                    checked={selectedShares.includes(share.value)}
                                                    onChange={() => toggleShare(share.value, selectedShares, setSelectedShares)}
                                                    className="sub-modal__checkbox-input"
                                                />
                                                <span className="sub-modal__checkbox-text">
                                                    <span className="sub-modal__checkbox-name">{share.label}</span>
                                                    <span className="sub-modal__checkbox-isin">{share.isin}</span>
                                                </span>
                                            </label>
                                        ))}
                                    </div>

                                    {/* Show expired toggle */}
                                    <label className="sub-modal__expired-toggle">
                                        <input
                                            type="radio"
                                            className="sub-modal__radio-input"
                                            checked={showExpired}
                                            onChange={() => setShowExpired(v => !v)}
                                        />
                                        <span>Näytä myös päättyneet arvo-osuuslajit</span>
                                    </label>

                                    {/* Expired shares */}
                                    {showExpired && (
                                        <div className="sub-modal__expired-section">
                                            <p className="sub-modal__expired-label">Päättyneet arvo-osuudet</p>
                                            <div className="sub-modal__shares-grid">
                                                {EXPIRED_SHARES.map((share) => (
                                                    <label key={share.value} className="sub-modal__checkbox-option">
                                                        <input
                                                            type="checkbox"
                                                            checked={selectedExpiredShares.includes(share.value)}
                                                            onChange={() => toggleShare(share.value, selectedExpiredShares, setSelectedExpiredShares)}
                                                            className="sub-modal__checkbox-input"
                                                        />
                                                        <span className="sub-modal__checkbox-text">
                                                            <span className="sub-modal__checkbox-name">{share.label}</span>
                                                            <span className="sub-modal__checkbox-isin">{share.isin}</span>
                                                        </span>
                                                    </label>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </div>

                                <div className="sub-modal__info-stack">
                                    <div className="sub-modal__info-box sub-modal__info-box--light">
                                        <h4 className="sub-modal__info-title">{t.shareSelectionTitle}</h4>
                                        <p className="sub-modal__info-text">{t.shareSelectionDesc}</p>
                                    </div>
                                </div>
                            </div>
                        </section>

                        {/* ── Tilauksen viite ── */}
                        <section className="sub-modal__section">
                            <div className="sub-modal__two-col">
                                <div className="sub-modal__col-left">
                                    <Input
                                        type="text"
                                        value={reference}
                                        onChange={(e) => {
                                            setReference(e.target.value);
                                            if (submitted) setErrors(er => ({ ...er, reference: undefined }));
                                        }}
                                        invalid={!!errors.reference}
                                    >
                                        <Input.Label>{t.referenceLabel}</Input.Label>
                                        <Input.Description>{t.referencePlaceholder}</Input.Description>
                                        {errors.reference && (
                                            <Input.ErrorMessage>{errors.reference}</Input.ErrorMessage>
                                        )}
                                    </Input>
                                </div>
                                <div className="sub-modal__info-stack">
                                    <div className="sub-modal__info-box sub-modal__info-box--light">
                                        <h4 className="sub-modal__info-title">{t.referenceInfoTitle}</h4>
                                        <p className="sub-modal__info-text">{t.referenceInfoDesc}</p>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <hr className="sub-modal__divider" />

                        {/* ── Price + submit error summary ── */}
                        <div className="sub-modal__price-row">
                            <p className="sub-modal__price-note">{t.priceNote}</p>
                            <p className="sub-modal__price-next">{t.priceNextView}</p>
                        </div>

                        {/* Validation summary — shown after first submit attempt */}
                        {submitted && Object.keys(errors).length > 0 && (
                            <div className="sub-modal__error-summary">
                                <p className="sub-modal__error-summary-title">⚠ Tarkista seuraavat kentät:</p>
                                <ul>
                                    {Object.values(errors).map((msg, i) => (
                                        <li key={i}>{msg}</li>
                                    ))}
                                </ul>
                            </div>
                        )}

                    </Dialog.Content>

                    <Dialog.Buttons>
                        <Button type="reset" variant="secondary" onClick={handleClose}>
                            {t.cancel}
                        </Button>
                        <Button type="submit" onClick={handleSubmit}>
                            {t.submit}
                        </Button>
                    </Dialog.Buttons>
                </Dialog>
            </div>

            <DatePicker
                isOpen={showDatePicker}
                lang={language}
                selectedDate={selectedDate ?? undefined}
                onSelect={(d) => {
                    setSelectedDate(d);
                    setShowDatePicker(false);
                    if (submitted) setErrors(e => ({ ...e, selectedDate: undefined }));
                }}
                onCancel={() => setShowDatePicker(false)}
            />
        </>
    );
}
