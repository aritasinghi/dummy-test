import { SubscribedCard } from '@/components/Card';
import { AvailableReportCard } from '@/components/AvailableReportCard';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import { useReportTypes } from '@/hooks/useReports';
import { REPORT_TYPE_LABELS, REPORT_TYPE_DESCRIPTIONS } from '@/api/services/reportsService';
import './ReportsPage.css';
import  getRandomDate  from '@/Utils/helper';


interface ReportsPageProps {
    language: Language;
    onSubscribe?: (reportTypeId: number, reportTitle: string) => void;
    onShowPreview?: (reportTypeId: number, reportTitle: string) => void;
    onShowAllSubscribed?: (reportTypeId: number, reportTitle: string, count: number) => void;
    onShowLatest?: (reportTypeId: number, reportTitle: string) => void;
}

// Mock owner data for subscribed cards
const MOCK_OWNERS = [
    { name: 'Tulip Bank', percentage: 10 },
    { name: 'Flexis Bank', percentage: 9 },
    { name: 'S. Sunflower', percentage: 8 },
    { name: 'C. Coriander', percentage: 7 },
    { name: 'H. Hazel', percentage: 6 },
    { name: 'T. Tulip', percentage: 5 },
    { name: 'R. Rose', percentage: 4 },
];

// Subscribed types = report_group 1-3, Available = 4+
const SUBSCRIBED_GROUPS = [1, 2, 3];

export default function ReportsPage({ language, onSubscribe, onShowPreview, onShowAllSubscribed, onShowLatest }: ReportsPageProps) {
    const t = translations[language].reports;
    const { data: reportTypes, isLoading, error } = useReportTypes();

    if (isLoading) return <p>Loading...</p>;
    if (error) return <p>Error loading report types</p>;
    if (!reportTypes) return null;

    const lang = language as 'fi' | 'en' | 'sv';

    const subscribedTypes = reportTypes.filter(rt => SUBSCRIBED_GROUPS.includes(rt.report_group));
    const availableTypes = reportTypes.filter(rt => !SUBSCRIBED_GROUPS.includes(rt.report_group));

  /*  const getLabel = (reportName: string) =>
        REPORT_TYPE_LABELS[reportName]?.[lang] ?? reportName;*/
    const getLabel = (reportName: string) => {
        const translations = REPORT_TYPE_LABELS[reportName];

        // Always show English by default
        if (lang === 'en') {
            return translations?.en ?? reportName;
        }

        // If user selects FI or SV → use translation if available
        return translations?.[lang] ?? translations?.en ?? reportName;
    };

    const getDesc = (reportName: string) =>
        REPORT_TYPE_DESCRIPTIONS[reportName] ?? '';


    return (
        <div className="reports-page">
            {/* Subscribed report types — fetched from API */}
            <section className="reports-page__section">
                <h3 className="reports-page__section-title">{t.subscribedTitle}</h3>
                <div className="reports-page__grid">
                    {subscribedTypes.map((rt, idx) => (
                        <SubscribedCard
                            key={rt.report_type_id}
                            title={getLabel(rt.report_name)}
                            badge={idx === 1 ? '' : undefined}
                            data={MOCK_OWNERS}
                            lastReportDate={getRandomDate()}
                            subscribedCount={3}
                            showLatestLabel={t.showLatestReport}
                            showAllLabel={t.showAllSubscribed}
                            subscribeLabel={t.subscribeNew}
                            onShowLatest={() => onShowLatest?.(rt.report_type_id, getLabel(rt.report_name))}
                            onShowAll={() => onShowAllSubscribed?.(rt.report_type_id, getLabel(rt.report_name), 3)}
                            onSubscribe={() => onSubscribe?.(rt.report_type_id, getLabel(rt.report_name))}
                        />
                    ))}
                </div>
            </section>

            {/* Available report types — fetched from API */}
            <section className="reports-page__section">
                <h3 className="reports-page__section-title">{t.availableTitle}</h3>
                <div className="reports-page__grid">
                    {availableTypes.map((rt) => (
                        <AvailableReportCard
                            key={rt.report_type_id}
                            title={getLabel(rt.report_name)}
                            description={getDesc(rt.report_name)}
                            previewLabel={t.showPreview}
                            subscribeLabel={t.subscribe}
                            onPreview={() => onShowPreview?.(rt.report_type_id, getLabel(rt.report_name))}
                            onSubscribe={() => onSubscribe?.(rt.report_type_id, getLabel(rt.report_name))}
                        />
                    ))}
                </div>
            </section>
        </div>
    );
}
