import {useState} from 'react';
import {
    Banner,
    Container,
    Header,
    Main,
    ProfileMenu,
    LanguageSelector as RawLanguageSelector,
} from '@efi/efi-ui-components';
import {translations} from '@/locales';
import type {Language} from '@/locales';
import {useCreateOrder} from '@/hooks/useReports';
import { mapFormToOrderRequest } from '@/api/services/reportsService';
import {SubscriptionModal} from '@/components/SubscriptionModal';
import ReportsPage from './ReportsPage';
import ReportPreview from './ReportPreview';
import ReportView from './ReportView';
import type {SubscriptionFormData} from '@/components/SubscriptionModal';
import OrganisationPage from './OrganisationInfo/OrganisationPage.tsx';

const LanguageSelector = RawLanguageSelector as any;

type View =
    | { type: 'landing' }
    | { type: 'preview'; reportTypeId: number; reportTitle: string }
    | { type: 'reportView'; reportTypeId: number; reportTitle: string; reportDate: string };

export default function LandingPage() {
    const [language, setLanguage] = useState<Language>('fi');
    const [activeTab, setActiveTab] = useState<string>('reports');
    const [currentView, setCurrentView] = useState<View>({type: 'landing'});
    const [subscribeModal, setSubscribeModal] = useState<{ open: boolean; reportTypeId: number; title: string }>({
        open: false, reportTypeId: 0, title: ''
    });
    const [successMsg, setSuccessMsg] = useState<string | null>(null);

    const createOrder = useCreateOrder();
    const t = translations[language];

    const tabs = [
        {label: t.tabs.reports, path: 'reports'},
        {label: t.tabs.log, path: 'log'},
        {label: t.tabs.organization, path: 'organization'},
    ];

    const goBack = () => setCurrentView({type: 'landing'});

    const handleSubscribeClick = (reportTypeId: number, title: string) => {
        setSubscribeModal({open: true, reportTypeId, title});
    };

    const handleSubscribeSubmit = async (formData: SubscriptionFormData) => {
        try {
            const request = mapFormToOrderRequest(formData, subscribeModal.reportTypeId);
            const result = await createOrder.mutateAsync(request);
            setSubscribeModal({open: false, reportTypeId: 0, title: ''});
            setSuccessMsg(`Tilaus onnistui! Tilausnumero: ${result.reportOrderId}`);
            setTimeout(() => setSuccessMsg(null), 5000);
        } catch {
            alert('Tilauksen luonti epäonnistui.');
        }
    };

    const renderContent = () => {
        switch (currentView.type) {
            case 'preview':
                return (
                    <ReportPreview
                        reportTitle={currentView.reportTitle}
                        language={language}
                        onBack={goBack}
                        onSubscribe={() => handleSubscribeClick(currentView.reportTypeId, currentView.reportTitle)}
                    />
                );

            case 'reportView':
                return (
                    <ReportView
                        reportTitle={currentView.reportTitle}
                        reportDate={currentView.reportDate}
                        language={language}
                        onBack={goBack}
                        onSubscribe={() => handleSubscribeClick(currentView.reportTypeId, currentView.reportTitle)}
                        onDownload={() => console.log('Download clicked')}
                    />
                );

            default:
                return (
                    <>
                        <Banner appName="MyEuroclear">
                            <Banner.Title>{t.tabs[activeTab as keyof typeof t.tabs]}</Banner.Title>
                        </Banner>
                        <Container>
                            {successMsg && (
                                <div style={{
                                    background: '#e0f5e9', border: '1px solid #00B9A4',
                                    borderRadius: 8, padding: '0.75rem 1rem',
                                    marginBottom: '1rem', color: '#006b5a', fontWeight: 600
                                }}>✓ {successMsg}</div>
                            )}
                            {activeTab === 'reports' && (
                                <ReportsPage
                                    language={language}
                                    onSubscribe={handleSubscribeClick}
                                    onShowPreview={(id, title) => setCurrentView({
                                        type: 'preview', reportTypeId: id, reportTitle: title
                                    })}
                                    onShowAllSubscribed={(id, title) => setCurrentView({
                                        type: 'reportView', reportTypeId: id,
                                        reportTitle: title, reportDate: '01.11.2025'
                                    })}
                                    onShowLatest={(id, title) => setCurrentView({
                                        type: 'reportView', reportTypeId: id,
                                        reportTitle: title, reportDate: '01.11.2025'
                                    })}
                                />
                            )}
                            {activeTab === 'log' &&
                                <p style={{padding: '2rem', color: '#999'}}>Tapahtumaloki — tulossa pian</p>}
                            {activeTab === 'organization' && (
                                <OrganisationPage language={language}/>
                            )}
                        </Container>
                    </>
                );
        }
    };

    return (
        <>
            <Header
                skipToContentLabel={t.header.skipToContent}
                drawerProps={{buttonOpen: t.header.openMenu, buttonClose: t.header.closeMenu}}
            >
                <Header.AppName>{t.header.appName}</Header.AppName>
                <Header.SecondaryTitle>
                    <span style={{whiteSpace: 'nowrap'}}>{t.header.orgLabel}</span>
                </Header.SecondaryTitle>
                <Header.Actions>
                    <ProfileMenu aria-label={t.profileMenu.yourProfile}>
                        <LanguageSelector
                            defaultSelected={language}
                            onSelect={(_e: unknown, value?: string) => {
                                if (value) setLanguage(value as Language);
                            }}
                        >
                            <LanguageSelector.Option value="en" lang="en-GB">English</LanguageSelector.Option>
                            <LanguageSelector.Option value="fi" lang="fi-FI">Finnish</LanguageSelector.Option>
                        </LanguageSelector>
                    </ProfileMenu>
                </Header.Actions>
                <Header.Navigation aria-label="Main navigation">
                    {tabs.map(({label, path}) => (
                        <Header.NavigationItem
                            key={path}
                            href={`/${path}`}
                            onClick={(e: React.MouseEvent) => {
                                e.preventDefault();
                                setActiveTab(path);
                                goBack();
                            }}
                        >
                            {label}
                        </Header.NavigationItem>
                    ))}
                </Header.Navigation>
            </Header>

            <Main>{renderContent()}</Main>

            <SubscriptionModal
                isOpen={subscribeModal.open}
                reportTitle={subscribeModal.title}
                onClose={() => setSubscribeModal({open: false, reportTypeId: 0, title: ''})}
                onSubmit={handleSubscribeSubmit}
                language={language}
            />
        </>
    );
}
