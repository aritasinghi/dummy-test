import { useState } from 'react';
import {
    Banner,
    Button,
    Container,
    Chip,
    Table,
    TextLink,
} from '@efi/efi-ui-components';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import './ReportView.css';

// ─── Types ────────────────────────────────────────────────────────────────────

interface ReportViewProps {
    reportTitle: string;
    reportDate: string;
    language: Language;
    onBack: () => void;
    onSubscribe: () => void;
    onDownload?: () => void;
}

type ReportType = 'full' | 'agm' | 'statutory' | 'short';
type OwnerFlag = 'restricted' | 'joint' | 'nominee' | 'bank';

interface ShareRow {
    type: string;
    custodian?: string;
    amount: string;
    pct: string;
    votes: string;
    votePct: string;
    bold?: boolean;
}

interface OwnerRow {
    id: number;
    name: string;
    ssn: string;
    dob: string;
    asiakasrajoitus?: string;
    flags: OwnerFlag[];
    isCompany?: boolean;
    isBank?: boolean;
    city?: string;
    address: string;
    postAddress: string;
    country: string;
    shares: ShareRow[];
    sektori: string;
    maksu: string;
    vero: string;
    jointOwners?: { name: string; linkable?: boolean }[];
    isJointSubRow?: boolean;
    jointParent?: string;
}

// ─── Column config per report type ───────────────────────────────────────────

const COLUMN_CONFIG: Record<ReportType, {
    showAddress: boolean;
    showCity: boolean;
    showCustodian: boolean;
    showPct: boolean;
    showVotes: boolean;
    showVotePct: boolean;
    showSector: boolean;
    showPayment: boolean;
    showTax: boolean;
}> = {
    full: {
        showAddress: true, showCity: false, showCustodian: false,
        showPct: true, showVotes: true, showVotePct: true,
        showSector: true, showPayment: true, showTax: true,
    },
    agm: {
        showAddress: false, showCity: true, showCustodian: false,
        showPct: false, showVotes: false, showVotePct: false,
        showSector: false, showPayment: false, showTax: false,
    },
    statutory: {
        showAddress: true, showCity: false, showCustodian: true,
        showPct: false, showVotes: false, showVotePct: false,
        showSector: false, showPayment: true, showTax: true,
    },
    short: {
        showAddress: false, showCity: false, showCustodian: true,
        showPct: true, showVotes: false, showVotePct: false,
        showSector: false, showPayment: false, showTax: false,
    },
};

// ─── Sidebar descriptions per report type ────────────────────────────────────

const SIDEBAR_REPORT_TYPE_DESC: Record<ReportType, { title: string; desc: string }> = {
    full: {
        title: 'Raportin tyyppi',
        desc: 'Voit valita haluamasi raporttityypin neljästä vaihtoehdosta:\n\nTäysi: sisältää nimensä mukaisesti raportin kaiken tietosisällön lisätietoineen. Yhtiökokous: Yhtiökokouksessa saatavilla oleva osakasluettelo. Sisältää ainoastaan ne tiedot, joita edellytetään osakeyhtiölaissa. Liikkeeseenlaskijan osakasluettelo: Sisältää osakeyhtiölain mukaiset tiedot. Lyhyt: raportti sisältää ...',
    },
    agm: {
        title: 'Liikkeeseenlaskijan osakasluettelo - Yhtiökokous',
        desc: 'Raportin tyyppi\nYhtiökokouksessa saatavilla oleva osakasluettelo. Sisältää ainoastaan ne tiedot, joita edellytetään osakeyhtiölain 5 luvun 23 §:n 2 momentin mukaisesti.',
    },
    statutory: {
        title: 'Liikkeeseenlaskijan osakasluettelo - Liikkeeseenlaskijan osakasluettelo',
        desc: 'Raportin tyyppi\nRaportti sisältää osakeyhtiölain 3 luvun 15 §:n 2–4 momentin mukaiset tiedot.',
    },
    short: {
        title: 'Liikkeeseenlaskijan osakasluettelo - Lyhyt',
        desc: 'Raportin tyyppi\nRaportti sisältää omistajien tai hallintarekisteröinnin hoitajien nimet, osakkeiden lukumäärän osakelajeittain, osakkeiden kokonaismäärän kaikkien osakelajien osalta, osakelajikohtaisen prosenttiosuuden kaikista osakkeista, yhdistetyn prosenttiosuuden kaikista osakkeista sekä säilyttäjäyrityksen nimen.',
    },
};

// ─── Mock Data ────────────────────────────────────────────────────────────────

const SHARES_INFO = [
    { name: 'EUROFLEX A', isin: 'FI21049685930', abbr: 'EUROFLA' },
    { name: 'EUROFLEX B', isin: 'FI21049685931', abbr: 'EUROFLB' },
    { name: 'EUROFLEX C', isin: 'FI21049685932', abbr: 'EUROFLC' },
];

const SUMMARY_ROWS = [
    { aoLaji: 'EUROFLA', omistajien: '1 300', yhteis: '12', kaikkien: '1 006 970', osuus: '50,3 %', kokonaisAani: '2 000 000', osakas: '503 488', odotus: '5 000', hallinta: '10 000', yhteistili: '481 512', liikkeeseen: '1 000 000', bold: false },
    { aoLaji: 'EUROFLB', omistajien: '600', yhteis: '24', kaikkien: '285 369', osuus: '71,3 %', kokonaisAani: '400 000', osakas: '285 369', odotus: '4 800', hallinta: '18 995', yhteistili: '90 836', liikkeeseen: '400 000', bold: false },
    { aoLaji: 'Yhteensä', omistajien: '1 900', yhteis: '36', kaikkien: '1 292 339', osuus: '53,8 %', kokonaisAani: '2 400 000', osakas: '788 857', odotus: '9 800', hallinta: '28 995', yhteistili: '572 348', liikkeeseen: '1 400 000', bold: true },
];

const SHOW_DATA_OPTIONS = [
    'turvakiellossa olevat osoitetiedot',
    'Yksilöintitunnus',
    'Päättyneet arvo-osuuslajit',
    'Ylätason sektoritieto',
    'Tilinhoitaja',
];

const INITIAL_FILTER_CHIPS = [
    { label: 'Suorarekisteröidyt omistukset', count: 2379, active: true },
    { label: 'Hallintarekisteröidyt omistukset', count: 12, active: false },
    { label: 'Yritykset', count: 1112, active: true },
    { label: 'Rahoitus- ja vakuutuslaitokset', count: 23, active: false },
    { label: 'Kotitaloudet', count: 1856, active: true },
];

const OWNER_ROWS: OwnerRow[] = [
    {
        id: 1, name: 'Thomas-Peter Along-lastname', ssn: '120370-8902A', dob: '12.03.1970',
        flags: [], city: 'Espoo',
        address: 'Arvo-osuuskuja 212', postAddress: '00550 Espoo', country: 'Espoo, Suomi',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP', amount: '30 300', pct: '3,03000', votes: '60 900', votePct: '2,54000' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '600', pct: '0,15000', votes: '', votePct: '' },
            { type: 'Arvo-osuudet yhteensä', amount: '30 900', pct: '2,21000', votes: '60 900', votePct: '2,54000', bold: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 2, name: 'Clarck Confidential', ssn: '020377-02908', dob: '02.03.1977',
        flags: ['restricted'], city: '',
        address: 'Yhteyssoite: Jokitie 22 b', postAddress: '00100 Helsinki', country: 'Tai Ei osoitetta',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP', amount: '15', pct: '0,00005', votes: '', votePct: '' },
            { type: 'EUROFLEX A', custodian: 'Nordea', amount: '15', pct: '0,00005', votes: '', votePct: '' },
            { type: 'EUROFLEX B', custodian: 'OP', amount: '40', pct: '0,00004', votes: '100', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', amount: '70', pct: '0,00003', votes: '100', votePct: '0,00003', bold: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 3, name: 'D:Yritys OY Ab', ssn: 'T769765-S', dob: '', asiakasrajoitus: 'konkurssi',
        flags: [], isCompany: true, city: 'Helsinki',
        address: 'Arvopaperie 12', postAddress: '00100 Helsinki', country: 'Helsinki, Suomi',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP', amount: '30', pct: '0,00005', votes: '', votePct: '' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '40', pct: '0,00004', votes: '', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', amount: '70', pct: '0,00003', votes: '', votePct: '0,00003', bold: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 4, name: 'Thomas Elling', ssn: '200274-89020', dob: '20.02.1974',
        flags: [], city: 'Helsinki',
        address: 'Thomaksentie 12', postAddress: '00100 Helsinki', country: 'Helsinki / Suomi',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP', amount: '30', pct: '0,00005', votes: '', votePct: '' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '40', pct: '0,00004', votes: '160', votePct: '0,00003' },
            { type: 'EUROFLEX A', custodian: 'Third LTD', amount: '20', pct: '0,00003', votes: '', votePct: '' },
            { type: 'EUROFLEX B', custodian: '4TH LTD', amount: '20', pct: '0,00001', votes: '', votePct: '' },
            { type: 'Arvo-osuudet yhteensä', amount: '110', pct: '0,00003', votes: '160', votePct: '0,00003', bold: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 5, name: 'Thomas Elling', ssn: '200274-89020', dob: '20.02.1974', asiakasrajoitus: 'kuolinpesä',
        flags: ['joint'], city: 'Helsinki',
        address: 'Thomaksentie 12', postAddress: '00100 Helsinki', country: 'Helsinki / Suomi',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP', amount: '30', pct: '0,00005', votes: '', votePct: '' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '40', pct: '0,00004', votes: '603', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', amount: '70', pct: '0,00003', votes: '603', votePct: '0,00003', bold: true },
        ],
        jointOwners: [{ name: 'Tiina Ollila', linkable: false }, { name: 'Veijo Välisää', linkable: true }],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 6, name: 'William Elling', ssn: '180372-89020', dob: '18.03.1972',
        flags: [], city: 'Helsinki',
        address: 'Viljaminkuja 22 b 33', postAddress: '00100 Helsinki', country: 'Helsinki, Suomi',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP', amount: '30', pct: '0,00005', votes: '', votePct: '' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '40', pct: '0,00004', votes: '603', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', amount: '70', pct: '0,00003', votes: '603', votePct: '0,00003', bold: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 7, name: 'Elli Ollinen', ssn: '120378-1902B', dob: '12.03.1978',
        flags: ['joint'], isJointSubRow: true, jointParent: 'Thomas Elling', city: 'Helsinki',
        address: 'Elisenkuja 6 B', postAddress: '00100 Helsinki', country: 'Helsinki/Suomi',
        shares: [], sektori: '', maksu: '', vero: '',
    },
    {
        id: 8, name: 'Sakari Penttinen', ssn: '220368-3456A', dob: '23.03.1968',
        flags: [], city: 'Helsinki',
        address: 'Sakarianpolku 1 C', postAddress: '00100 Helsinki', country: 'Helsinki, Suomi',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP', amount: '30', pct: '0,00005', votes: '3', votePct: '0,00005' },
            { type: 'Arvo-osuudet yhteensä', amount: '30', pct: '0,00005', votes: '3', votePct: '0,00005', bold: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 9, name: 'SEC Custody Bank', ssn: '1169765-6', dob: '',
        flags: ['nominee'], isBank: true, city: 'Helsinki',
        address: 'Pankkiirinkatu 32', postAddress: '00100 Helsinki', country: 'Helsinki / Suomi',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP', amount: '120', pct: '0,00010', votes: '70', votePct: '0,00010' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '60', pct: '0,00010', votes: '', votePct: '' },
            { type: 'Arvo-osuudet yhteensä', amount: '180', pct: '0,00008', votes: '70', votePct: '0,00010', bold: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
];

// ─── Sub-components ───────────────────────────────────────────────────────────

function FlagIcon({ type }: { type: OwnerFlag }) {
    const icons: Record<OwnerFlag, { symbol: string; title: string }> = {
        restricted: { symbol: '🚫', title: 'Turvakielto' },
        joint: { symbol: '🔗', title: 'Yhteisomistus' },
        nominee: { symbol: '📋', title: 'Hallintarekisteröity omistus' },
        bank: { symbol: '🏦', title: 'Hallintarekisteröinnin hoitaja' },
    };
    return <span className="rv-flag" title={icons[type].title}>{icons[type].symbol}</span>;
}

function JointOwnerSection({ owners }: { owners: { name: string; linkable?: boolean }[] }) {
    return (
        <div className="rv__joint-section">
            <span>🔗</span>
            <span className="rv__joint-label">Yhteisomistus:</span>
            <div className="rv__joint-names">
                {owners.map((o, i) => (
                    <span key={i}>
                        {o.linkable ? <TextLink href="#">{o.name}</TextLink> : <span>{o.name}</span>}
                        {i < owners.length - 1 && ', '}
                    </span>
                ))}
            </div>
            <button type="button" className="rv__joint-toggle">Vai avattava? ›</button>
        </div>
    );
}

function OwnerTableRow({ row, cols }: { row: OwnerRow; cols: typeof COLUMN_CONFIG[ReportType] }) {
    if (row.isJointSubRow) {
        return (
            <Table.Row>
                <Table.BodyCell>
                    <div className="rv__name-cell">
                        <div className="rv__name-row">
                            <span>🔗</span>
                            <span className="rv__sub-label">Mukana yhteisomistuksessa</span>
                        </div>
                        <div className="rv__joint-parent">Oikeudenhaltija: <TextLink href="#">{row.jointParent}</TextLink></div>
                        <span className="rv__ssn-text">{row.ssn}</span>
                        {row.dob && <Table.SecondaryText>{row.dob}</Table.SecondaryText>}
                    </div>
                </Table.BodyCell>
                {cols.showAddress && (
                    <Table.BodyCell>
                        <span className="rv__cell-sm">{row.address}</span>
                        <Table.SecondaryText>{row.postAddress}</Table.SecondaryText>
                        <Table.SecondaryText>{row.country}</Table.SecondaryText>
                    </Table.BodyCell>
                )}
                {cols.showCity && <Table.BodyCell><span className="rv__cell-sm">{row.city}</span></Table.BodyCell>}
                <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>
                {cols.showCustodian && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>
                {cols.showPct && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.showVotes && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.showVotePct && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.showSector && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.showPayment && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.showTax && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
            </Table.Row>
        );
    }

    return (
        <Table.Row>
            {/* Name */}
            <Table.BodyCell>
                <div className="rv__name-cell">
                    <div className="rv__name-row">
                        {row.isBank && <span title="Pankki">🏦</span>}
                        {row.isCompany && !row.isBank && <span title="Yritys">🏢</span>}
                        <TextLink href="#">{row.name}</TextLink>
                        {row.flags.filter(f => f !== 'joint').map((f) => <FlagIcon key={f} type={f} />)}
                    </div>
                    <span className="rv__ssn-text">{row.ssn}</span>
                    {row.dob && <Table.SecondaryText>{row.dob}</Table.SecondaryText>}
                    {row.asiakasrajoitus && <span className="rv__restriction">Asiakasrajoitus: {row.asiakasrajoitus}</span>}
                    {row.jointOwners && <JointOwnerSection owners={row.jointOwners} />}
                </div>
            </Table.BodyCell>

            {/* Address */}
            {cols.showAddress && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.address}</span>
                    <Table.SecondaryText>{row.postAddress}</Table.SecondaryText>
                    <Table.SecondaryText>{row.country}</Table.SecondaryText>
                </Table.BodyCell>
            )}

            {/* City (AGM only) */}
            {cols.showCity && (
                <Table.BodyCell><span className="rv__cell-sm">{row.city}</span></Table.BodyCell>
            )}

            {/* Share types */}
            <Table.BodyCell>
                {row.shares.map((s, i) => (
                    <div key={i} className={`rv__cell-sm${s.bold ? ' rv__cell-bold' : ''}`}>{s.type}</div>
                ))}
            </Table.BodyCell>

            {/* Custodian (statutory/short) */}
            {cols.showCustodian && (
                <Table.BodyCell>
                    {row.shares.map((s, i) => (
                        <div key={i} className="rv__cell-sm">{s.bold ? '' : (s.custodian || '')}</div>
                    ))}
                </Table.BodyCell>
            )}

            {/* Amount */}
            <Table.BodyCell align="middle-right">
                {row.shares.map((s, i) => (
                    <div key={i} className={`rv__cell-sm${s.bold ? ' rv__cell-bold' : ''}`}>{s.amount}</div>
                ))}
            </Table.BodyCell>

            {/* % */}
            {cols.showPct && (
                <Table.BodyCell align="middle-right">
                    {row.shares.map((s, i) => (
                        <div key={i} className="rv__cell-sm">{s.pct}</div>
                    ))}
                </Table.BodyCell>
            )}

            {/* Votes */}
            {cols.showVotes && (
                <Table.BodyCell align="middle-right">
                    {row.shares.map((s, i) => (
                        <div key={i} className={`rv__cell-sm${s.bold ? ' rv__cell-bold' : ''}`}>{s.votes || ''}</div>
                    ))}
                </Table.BodyCell>
            )}

            {/* Vote % */}
            {cols.showVotePct && (
                <Table.BodyCell align="middle-right">
                    {row.shares.map((s, i) => (
                        <div key={i} className="rv__cell-sm">{s.votePct || ''}</div>
                    ))}
                </Table.BodyCell>
            )}

            {/* Sector */}
            {cols.showSector && (
                <Table.BodyCell><span className="rv__cell-sm">{row.sektori}</span></Table.BodyCell>
            )}

            {/* Payment */}
            {cols.showPayment && (
                <Table.BodyCell><span className="rv__cell-sm">{row.maksu}</span></Table.BodyCell>
            )}

            {/* Tax */}
            {cols.showTax && (
                <Table.BodyCell><span className="rv__cell-sm">{row.vero}</span></Table.BodyCell>
            )}
        </Table.Row>
    );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function ReportView({ reportTitle, reportDate, language, onBack, onSubscribe, onDownload }: ReportViewProps) {
    const t = translations[language].reportView;

    const [activeTab, setActiveTab] = useState<'report' | 'subscription'>('report');
    const [reportType, setReportType] = useState<ReportType>('full');
    const [showDataChecks, setShowDataChecks] = useState<Record<string, boolean>>(
        Object.fromEntries(SHOW_DATA_OPTIONS.map((o) => [o, true]))
    );
    const [filterChips, setFilterChips] = useState(INITIAL_FILTER_CHIPS);
    const [searchQuery, setSearchQuery] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const totalPages = 14;

    const cols = COLUMN_CONFIG[reportType];
    const sidebarDesc = SIDEBAR_REPORT_TYPE_DESC[reportType];

    const toggleShowData = (key: string) => setShowDataChecks((p) => ({ ...p, [key]: !p[key] }));
    const toggleChip = (label: string) => setFilterChips((prev) => prev.map((c) => c.label === label ? { ...c, active: !c.active } : c));

    const reportTypeOptions: { key: ReportType; label: string; desc: string }[] = [
        { key: 'full', label: 'Täysi', desc: 'Kaikki saatavilla olevat tiedot' },
        { key: 'agm', label: 'Yhtiökokous', desc: 'Osakasluettelo yhtiökokoukseen' },
        { key: 'statutory', label: 'Liikkeeseenlaskijan osakasluettelo', desc: 'Lakisääteiset tiedot' },
        { key: 'short', label: 'Lyhyt', desc: 'Omistajien nimet ja osakkeiden lukumäärä' },
    ];

    const filteredRows = OWNER_ROWS.filter((row) =>
        !searchQuery || row.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <>
            <Banner appName="MyEuroclear">
                <Banner.Title>{reportDate} {reportTitle}</Banner.Title>
            </Banner>

            <Container>
                <div className="rv">
                    {/* Header */}
                    <div className="rv__header">
                        <div className="rv__tabs">
                            <button type="button" className={`rv__tab ${activeTab === 'report' ? 'rv__tab--active' : ''}`} onClick={() => setActiveTab('report')}>{t.tabReport}</button>
                            <button type="button" className={`rv__tab ${activeTab === 'subscription' ? 'rv__tab--active' : ''}`} onClick={() => setActiveTab('subscription')}>{t.tabSubscriptionInfo}</button>
                        </div>
                        <button type="button" className="rv__download-btn" onClick={onDownload}>
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 2v8m0 0L5 7m3 3l3-3M3 12h10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                            {t.downloadFile}
                        </button>
                    </div>

                    {activeTab === 'report' && (
                        <>
                            {/* Summary Card */}
                            <section className="rv__summary-card">
                                <h2 className="rv__section-title">{t.summaryTitle}</h2>
                                <div className="rv__info-row">
                                    <div className="rv__info-block">
                                        <h4 className="rv__info-heading">{t.infoTitle}</h4>
                                        <p className="rv__info-line">{t.issuer}: <strong>Euroflex Oyj</strong></p>
                                        <p className="rv__info-line">{t.reportName}: <strong>Liikkeeseenlaskijan omistusraportti</strong></p>
                                        <p className="rv__info-line">{t.situationDate}: <strong>13.3.2026</strong></p>
                                    </div>
                                    <div className="rv__shares-block">
                                        <h4 className="rv__info-heading">Arvo-osuudet</h4>
                                        <div className="rv__shares-grid">
                                            {SHARES_INFO.map((s) => (
                                                <div key={s.isin} className="rv__share-col">
                                                    <p className="rv__info-line">{t.shareNameLabel}: <strong>{s.name}</strong></p>
                                                    <p className="rv__info-line">{t.isinLabel}: <strong>{s.isin}</strong></p>
                                                    <p className="rv__info-line">{t.abbreviationLabel}: <strong>{s.abbr}</strong></p>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                                <h3 className="rv__sub-title">Yhteenveto</h3>
                                <div className="rv__summary-table-wrap">
                                    <Table layout="fixed" hover striped>
                                        <Table.Head>
                                            <Table.Row>
                                                <Table.HeadCell column="ao" sortable style={{ width: '80px' }}>AO-LAJI</Table.HeadCell>
                                                <Table.HeadCell column="om" style={{ width: '90px' }}>OMISTAJIEN JA HALLINTA&shy;REKISTE&shy;RÖINNIN HOITAJIEN MÄÄRÄ</Table.HeadCell>
                                                <Table.HeadCell column="yh" style={{ width: '80px' }}>YHTEIS&shy;OMISTAJIEN MÄÄRÄ</Table.HeadCell>
                                                <Table.HeadCell column="kk" style={{ width: '110px' }}>KAIKKIEN ARVO-OSUUSTILEILLÄ OLEVIEN OSAKKEIDEN TUOTTAMA ÄÄNIMÄÄRÄ</Table.HeadCell>
                                                <Table.HeadCell column="os" style={{ width: '110px' }}>OSUUS KAIKKIEN LIIKKEELLE LASKETTUJEN OSAKKEIDEN TUOTTAMASTA KOKONAIS&shy;ÄÄNIMÄÄRÄSTÄ</Table.HeadCell>
                                                <Table.HeadCell column="ka" style={{ width: '90px' }}>KOKONAIS&shy;ÄÄNIMÄÄRÄ</Table.HeadCell>
                                                <Table.HeadCell column="ol" style={{ width: '90px' }}>OSAKAS&shy;LUETTELOLLA</Table.HeadCell>
                                                <Table.HeadCell column="od" style={{ width: '80px' }}>ODOTUS&shy;LUETTELOLLA</Table.HeadCell>
                                                <Table.HeadCell column="hr" style={{ width: '90px' }}>HALLINTA&shy;REKISTERÖIDYT</Table.HeadCell>
                                                <Table.HeadCell column="yt" style={{ width: '90px' }}>YHTEISTILLÄ</Table.HeadCell>
                                                <Table.HeadCell column="lm" style={{ width: '100px' }}>LIIKKEESEEN&shy;LASKETTU MÄÄRÄ</Table.HeadCell>
                                            </Table.Row>
                                        </Table.Head>
                                        <Table.Body>
                                            {SUMMARY_ROWS.map((row) => (
                                                <Table.Row key={row.aoLaji}>
                                                    <Table.BodyCell>{row.bold ? <strong>{row.aoLaji}</strong> : row.aoLaji}</Table.BodyCell>
                                                    <Table.BodyCell>{row.omistajien}</Table.BodyCell>
                                                    <Table.BodyCell>{row.yhteis}</Table.BodyCell>
                                                    <Table.BodyCell>{row.kaikkien}</Table.BodyCell>
                                                    <Table.BodyCell>{row.osuus}</Table.BodyCell>
                                                    <Table.BodyCell>{row.kokonaisAani}</Table.BodyCell>
                                                    <Table.BodyCell>{row.osakas}</Table.BodyCell>
                                                    <Table.BodyCell>{row.odotus}</Table.BodyCell>
                                                    <Table.BodyCell>{row.hallinta}</Table.BodyCell>
                                                    <Table.BodyCell>{row.yhteistili}</Table.BodyCell>
                                                    <Table.BodyCell>{row.liikkeeseen}</Table.BodyCell>
                                                </Table.Row>
                                            ))}
                                        </Table.Body>
                                    </Table>
                                </div>
                            </section>

                            {/* Filters layout */}
                            <div className="rv__filters-layout">
                                <div className="rv__filters-left">
                                    {/* Raportin tyyppi */}
                                    <section className="rv__filter-section">
                                        <h3 className="rv__filter-label">{t.reportTypeTitle} <span className="rv__info-icon">ⓘ</span></h3>
                                        <div className="rv__radio-group">
                                            {reportTypeOptions.map(({ key, label, desc }) => (
                                                <label key={key} className="rv__radio-option">
                                                    <input type="radio" name="reportType" checked={reportType === key} onChange={() => setReportType(key)} className="rv__radio-input" />
                                                    <span className="rv__radio-content">
                                                        <strong>{label}</strong>
                                                        <span className="rv__radio-desc">{desc}</span>
                                                    </span>
                                                </label>
                                            ))}
                                        </div>
                                    </section>

                                    {/* Näytä tiedot — only for full */}
                                    {reportType === 'full' && (
                                        <section className="rv__filter-section">
                                            <h3 className="rv__filter-label">{t.showDataTitle} <span className="rv__info-icon">ⓘ</span></h3>
                                            <div className="rv__checkbox-group">
                                                {SHOW_DATA_OPTIONS.map((opt) => (
                                                    <label key={opt} className="rv__checkbox-option">
                                                        <input type="checkbox" checked={showDataChecks[opt]} onChange={() => toggleShowData(opt)} className="rv__checkbox-input" />
                                                        <span className="rv__checkbox-label">{opt}</span>
                                                    </label>
                                                ))}
                                            </div>
                                        </section>
                                    )}

                                    {/* Suodatus */}
                                    <section className="rv__filter-section rv__filter-section--last">
                                        <h3 className="rv__filter-label">{t.filterTitle} <span className="rv__info-icon">ⓘ</span></h3>
                                        <div className="rv__chips-row">
                                            {filterChips.map((chip) => (
                                                <Chip key={chip.label} mode="selectable" size="medium" selected={chip.active} onClick={() => toggleChip(chip.label)}>
                                                    {chip.label}
                                                    <Chip.Counter>{chip.count}</Chip.Counter>
                                                </Chip>
                                            ))}
                                        </div>
                                    </section>
                                </div>

                                {/* Right sidebar — changes with report type */}
                                <div className="rv__filters-right">
                                    <div className="rv__sidebar-card">
                                        <section className="rv__sidebar-section">
                                            <h4 className="rv__sidebar-title">{sidebarDesc.title}</h4>
                                            <p className="rv__sidebar-text" style={{ whiteSpace: 'pre-line' }}>{sidebarDesc.desc}</p>
                                            {reportType === 'full' && (
                                                <>
                                                    <br />
                                                    <TextLink href="#">Käyttötarkoitus ja sisältö?</TextLink>
                                                </>
                                            )}
                                        </section>
                                        {reportType === 'full' && (
                                            <>
                                                <section className="rv__sidebar-section">
                                                    <h4 className="rv__sidebar-title">{t.showDataTitle}</h4>
                                                    <p className="rv__sidebar-text">Näytä tiedot -kohdassa voit vaikuttaa taulukossa näytettäviin sarakkeisiin. Esimerkiksi näytä ISIN-koodit -valinta joko tuo ISIN-koodi -sarakkeen näkyville tai piilottaa sen.</p>
                                                </section>
                                                <section className="rv__sidebar-section">
                                                    <h4 className="rv__sidebar-title">{t.filterTitle}</h4>
                                                    <p className="rv__sidebar-text">Suodatuksilla voi vaikuttaa taulukon sisältöön. Esim. Suorarekisteröidyt omistukset valinnan poisto suodattaa taulukkoa niin, etteivät suorarekisteröidyt omistukset ole taulukossa mukana.</p>
                                                </section>
                                                <section className="rv__sidebar-section rv__sidebar-section--last">
                                                    <h4 className="rv__sidebar-title">{t.fileDownloadTitle}</h4>
                                                    <p className="rv__sidebar-text">Tiedoston lataus ikkunassa voit vaikuttaa siihen, minkä raportin tyypin haluat ladata ja missä tiedostomuodossa.</p>
                                                </section>
                                            </>
                                        )}
                                    </div>
                                </div>
                            </div>

                            {/* Search row + legend */}
                            <div className="rv__search-row">
                                <div className="rv__search-left">
                                    <p className="rv__filter-summary">Suodatuksella: omistajia 224 kpl, osakkeita 2391 kpl</p>
                                    <div className="rv__search-box">
                                        <input type="text" placeholder={t.searchPlaceholder} value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="rv__search-input" />
                                        <span className="rv__search-icon">🔍</span>
                                    </div>
                                </div>
                                <div className="rv__legend">
                                    <span className="rv__legend-item">🚫 Turvakielto</span>
                                    <span className="rv__legend-item">🔗 Yhteisomistus</span>
                                    <span className="rv__legend-item">📋 Hallintarekisteröity omistus</span>
                                    <span className="rv__legend-item">🏦 Hallintarekisteröinnin hoitaja</span>
                                </div>
                            </div>

                            {/* Dynamic owner table */}
                            <div className="rv__table-wrap">
                                <Table layout="fixed" hover>
                                    <Table.Head>
                                        <Table.Row>
                                            <Table.HeadCell column="nimi" sortable style={{ width: '190px' }}>
                                                NIMI<Table.SecondaryText>YKSILÖINTITUNNUS</Table.SecondaryText>
                                                <Table.SecondaryText>SYNTYMÄAIKA</Table.SecondaryText>
                                                {cols.showAddress && <Table.SecondaryText>ASIAKASRAJOITUS</Table.SecondaryText>}
                                            </Table.HeadCell>
                                            {cols.showAddress && (
                                                <Table.HeadCell column="os" style={{ width: '160px' }}>
                                                    KATUOSOITE<Table.SecondaryText>POSTIOSOITE</Table.SecondaryText><Table.SecondaryText>KOTIKUNTA, MAA</Table.SecondaryText>
                                                </Table.HeadCell>
                                            )}
                                            {cols.showCity && (
                                                <Table.HeadCell column="ct" style={{ width: '100px' }}>KOTIKUNTA</Table.HeadCell>
                                            )}
                                            <Table.HeadCell column="av" style={{ width: '150px' }}>ARVO-OSUUDEN NIMI</Table.HeadCell>
                                            {cols.showCustodian && (
                                                <Table.HeadCell column="cu" style={{ width: '100px' }}>TILINHOITAJA</Table.HeadCell>
                                            )}
                                            <Table.HeadCell column="ma" align="right" style={{ width: '90px' }}>ARVO-OSUUKSIEN MÄÄRÄ</Table.HeadCell>
                                            {cols.showPct && (
                                                <Table.HeadCell column="op" align="right" style={{ width: '100px' }}>OSUUS ARVO-OSUUKSIEN KOKONAIS&shy;MÄÄRÄSTÄ %</Table.HeadCell>
                                            )}
                                            {cols.showVotes && (
                                                <Table.HeadCell column="an" align="right" style={{ width: '80px' }}>ÄÄNIMÄÄRÄ</Table.HeadCell>
                                            )}
                                            {cols.showVotePct && (
                                                <Table.HeadCell column="oa" align="right" style={{ width: '100px' }}>OSUUS KOKONAIS&shy;ÄÄNIMÄÄRÄSTÄ</Table.HeadCell>
                                            )}
                                            {cols.showSector && (
                                                <Table.HeadCell column="se" style={{ width: '140px' }}>SEKTORI</Table.HeadCell>
                                            )}
                                            {cols.showPayment && (
                                                <Table.HeadCell column="mk" style={{ width: '120px' }}>MAKSUTIEDOT</Table.HeadCell>
                                            )}
                                            {cols.showTax && (
                                                <Table.HeadCell column="ve" style={{ width: '80px' }}>VEROTUS&shy;TIEDOT</Table.HeadCell>
                                            )}
                                        </Table.Row>
                                    </Table.Head>
                                    <Table.Body>
                                        {filteredRows.map((row) => <OwnerTableRow key={row.id} row={row} cols={cols} />)}
                                    </Table.Body>
                                </Table>
                            </div>

                            {/* Pagination */}
                            <div className="rv__pagination">
                                <button type="button" className="rv__page-text" onClick={() => setCurrentPage(1)}>Ensimmäinen</button>
                                <button type="button" className="rv__page-btn" onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} disabled={currentPage === 1}>‹</button>
                                {[1, 2, 3].map((p) => (
                                    <button key={p} type="button" className={`rv__page-num ${currentPage === p ? 'rv__page-num--active' : ''}`} onClick={() => setCurrentPage(p)}>{String(p).padStart(2, '0')}</button>
                                ))}
                                <span className="rv__page-ellipsis">…</span>
                                <button type="button" className={`rv__page-num ${currentPage === totalPages ? 'rv__page-num--active' : ''}`} onClick={() => setCurrentPage(totalPages)}>{totalPages}</button>
                                <button type="button" className="rv__page-btn" onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages}>›</button>
                                <button type="button" className="rv__page-text" onClick={() => setCurrentPage(totalPages)}>Viimeinen</button>
                            </div>

                            {/* Actions */}
                            <div className="rv__actions">
                                <Button variant="secondary" onClick={onBack}>{t.back}</Button>
                                <Button variant="primary" onClick={onSubscribe}>{t.toSubscription}</Button>
                            </div>
                        </>
                    )}

                    {activeTab === 'subscription' && (
                        <div className="rv__subscription-tab"><p>Tilauksen tiedot — tulossa pian</p></div>
                    )}
                </div>
            </Container>
        </>
    );
}
