import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import "@efi/efi-ui-components/css/index.css";
import "@efi/efi-ui-components/css/theme-light.css";

import { AppProviders } from '@/providers';
import LandingPage from '@/pages/LandingPage';

const root = document.getElementById('root');
if (!root) throw new Error('Root element #root not found.');

createRoot(root).render(
    <StrictMode>
        <AppProviders theme="light">
            <LandingPage />
        </AppProviders>
    </StrictMode>,
);
