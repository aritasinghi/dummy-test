

export type OrgPageLanguage = 'en' | 'sv' |  'fi';


export interface OrganisationPageTranslations {
    generalInfo: string;
    address: string;

    name: string;
    businessId: string;
    lei: string;
    street: string;
    city: string;

    orgType: string;
    emailLanguage: string;
    finnish: string;
    english: string;

    postalCode: string;
    country: string;

    issuerType: string;
    joinedSystem: string;
    leftSystem: string;

    shareClasses: string;
    short: string;
    isin: string;
    type: string;
    votes: string;
    clause: string;
    status: string;

    contractInfo: string;
    activeContract: string;
    contractStart: string;
    contractEnd: string;
}

const en : OrganisationPageTranslations ={

    generalInfo: "General organisation information",
    address: "Address",

    name: "Name",
    businessId: "Business ID",
    lei: "LEI code",
    street: "Street address",
    city: "City",

    orgType: "Organisation type",
    emailLanguage: "Email language",
    finnish: "Finnish",
    english: "English",

    postalCode: "Postal code",
    country: "Country",

    issuerType: "Issuer type",
    joinedSystem: "Entered into book-entry system",
    leftSystem: "Removed from book-entry system",

    shareClasses: "Book-Entries",
    short: "Abbrevation",
    isin: "ISIN code",
    type: "Type",
    votes: "Votes / Share",
    clause: "Consent / Redemption clause",
    status: "Status",

    contractInfo: "Contract information",
    activeContract: "Active contract",
    contractStart: "Contract start date",
    contractEnd: "Contract end date"
};

const sv: OrganisationPageTranslations = {

    generalInfo: "Allmän organisationsinformation",
    address: "Adress",

    name: "Namn",
    businessId: "FO-nummer",
    lei: "LEI-kod",
    street: "Gatuadress",
    city: "Stad",

    orgType: "Organisationstyp",
    emailLanguage: "E‑postspråk",
    finnish: "Finska",
    english: "Engelska",

    postalCode: "Postnummer",
    country: "Land",

    issuerType: "Emittenttyp",
    joinedSystem: "Inträde i värdeandelssystemet",
    leftSystem: "Utträde ur värdeandelssystemet",

    shareClasses: "Värdeandelar",
    short: "Förkortning",
    isin: "ISIN‑kod",
    type: "Typ",
    votes: "Röster / Aktie",
    clause: "Samtyckes-/inlösenvillkor",
    status: "Status",

    contractInfo: "Avtalsinformation",
    activeContract: "Gällande avtal",
    contractStart: "Avtalets startdatum",
    contractEnd: "Avtalets slutdatum"
};

const fi : OrganisationPageTranslations ={

    generalInfo: "Organisaation yleiset tiedot",
    address: "Osoite",

    name: "Nimi",
    businessId: "Y-tunnus",
    lei: "LEI-tunnus",
    street: "Katuosoite",
    city: "Kaupunki",

    orgType: "Organisaation tyyppi",
    emailLanguage: "Sähköpostin kieli",
    finnish: "Suomi",
    english: "Englanti",

    postalCode: "Postinumero",
    country: "Maa",

    issuerType: "Liikkeeseenlaskijan tyyppi",
    joinedSystem: "Siirtynyt arvo-osuusjärjestelmään",
    leftSystem: "Poistunut arvo-osuusjärjestelmästä",

    shareClasses: "Arvo-osuudet",
    short: "Lyhenne",
    isin: "ISIN-koodi",
    type: "Laji",
    votes: "Ääniä / Osake",
    clause: "Suostumus-/lunastuslauseke",
    status: "Status",

    contractInfo: "Sopimustiedot",
    activeContract: "Voimassa oleva sopimus",
    contractStart: "Sopimuksen alkupäivä",
    contractEnd: "Sopimuksen loppupäivä"

};

export const translationsOrgPage: {
    sv: OrganisationPageTranslations;
    fi: OrganisationPageTranslations;
    en: OrganisationPageTranslations
} = { en, sv, fi };