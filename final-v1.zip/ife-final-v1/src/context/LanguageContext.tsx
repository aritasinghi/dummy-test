import { createContext, useContext, useState, useMemo } from 'react';
import type { ReactNode } from 'react';
import type { Language } from '@/locales';
import { translations } from '@/locales';

interface LanguageContextValue {
    language: Language;
    setLanguage: (lang: Language) => void;
    t: typeof translations['en'];
}

const LanguageContext = createContext<LanguageContextValue | undefined>(undefined);

export function useLanguage() {
    const ctx = useContext(LanguageContext);
    if (!ctx) throw new Error('useLanguage must be used within <LanguageProvider>');
    return ctx;
}

export function LanguageProvider({ defaultLanguage = 'en', children }: { defaultLanguage?: Language; children: ReactNode }) {
    const [language, setLanguage] = useState<Language>(defaultLanguage);
    const t = translations[language];
    const value = useMemo(() => ({ language, setLanguage, t }), [language, t]);
    return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}
