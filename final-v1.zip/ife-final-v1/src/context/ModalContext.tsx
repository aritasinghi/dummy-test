import { createContext, useContext, useState, useCallback, useMemo } from 'react';
import type { ReactNode } from 'react';

interface ModalState {
    subscription: { open: boolean; reportTitle: string };
    download: { open: boolean };
}

interface ModalContextValue {
    modals: ModalState;
    openSubscription: (reportTitle: string) => void;
    closeSubscription: () => void;
    openDownload: () => void;
    closeDownload: () => void;
}

const INITIAL: ModalState = {
    subscription: { open: false, reportTitle: '' },
    download: { open: false },
};

const ModalContext = createContext<ModalContextValue | undefined>(undefined);

export function useModals() {
    const ctx = useContext(ModalContext);
    if (!ctx) throw new Error('useModals must be used within <ModalProvider>');
    return ctx;
}

export function ModalProvider({ children }: { children: ReactNode }) {
    const [modals, setModals] = useState<ModalState>(INITIAL);

    const openSubscription = useCallback((reportTitle: string) => {
        setModals((p) => ({ ...p, subscription: { open: true, reportTitle } }));
    }, []);

    const closeSubscription = useCallback(() => {
        setModals((p) => ({ ...p, subscription: { open: false, reportTitle: '' } }));
    }, []);

    const openDownload = useCallback(() => {
        setModals((p) => ({ ...p, download: { open: true } }));
    }, []);

    const closeDownload = useCallback(() => {
        setModals((p) => ({ ...p, download: { open: false } }));
    }, []);

    const value = useMemo(() => ({
        modals, openSubscription, closeSubscription, openDownload, closeDownload,
    }), [modals, openSubscription, closeSubscription, openDownload, closeDownload]);

    return <ModalContext.Provider value={value}>{children}</ModalContext.Provider>;
}
