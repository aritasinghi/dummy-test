-- ============================================================
-- ALTER existing report_order table to add report_type_id
-- Run ONLY if your report_order table already exists WITHOUT report_type_id
-- ============================================================

-- Step 1: Add column (nullable first)
ALTER TABLE ife_app.report_order
    ADD COLUMN IF NOT EXISTS report_type_id INT;

-- Step 2: Set existing rows to type 2 (SHAREHOLDER_PUBLIC) as default
UPDATE ife_app.report_order SET report_type_id = 2 WHERE report_type_id IS NULL;

-- Step 3: Add FK constraint
ALTER TABLE ife_app.report_order
    ADD CONSTRAINT fk_report_order_type
    FOREIGN KEY (report_type_id)
    REFERENCES ife_app.report_type(report_type_id);

-- Step 4: Make NOT NULL
ALTER TABLE ife_app.report_order
    ALTER COLUMN report_type_id SET NOT NULL;

-- Step 5: Add missing report types
INSERT INTO ife_app.report_type (report_type, report_grouping) VALUES
    ('SECTOR_DISTRIBUTION', 6),
    ('OWNERSHIP_DISTRIBUTION', 7),
    ('TEMPORARY_SHAREHOLDER_LIST', 8)
ON CONFLICT (report_grouping) DO NOTHING;

-- Verify
SELECT * FROM ife_app.report_type ORDER BY report_type_id;
SELECT * FROM ife_app.report_order ORDER BY report_order_id;
