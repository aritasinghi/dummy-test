-- ============================================================
-- OIS Portal — Complete PostgreSQL Setup
-- Run against: postgres@localhost (as superuser/postgres)
-- ============================================================

-- ============================================================
-- STEP 1: SCHEMA & USER (skip if already exists)
-- ============================================================
CREATE SCHEMA IF NOT EXISTS ife_app;

DO $$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'ife_service') THEN
    CREATE ROLE ife_service;
  END IF;
END $$;

GRANT USAGE, CREATE ON SCHEMA ife_app TO ife_service;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA ife_app TO ife_service;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA ife_app TO ife_service;

DO $$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'ife_app_user') THEN
    CREATE USER ife_app_user WITH PASSWORD 'Test123!';
    GRANT ife_service TO ife_app_user;
    ALTER USER ife_app_user SET search_path TO ife_app, public;
  END IF;
END $$;


-- ============================================================
-- STEP 2: TABLES (drop + recreate for clean state)
-- ============================================================
DROP TABLE IF EXISTS ife_app.report_order_instrument CASCADE;
DROP TABLE IF EXISTS ife_app.report_order CASCADE;
DROP TABLE IF EXISTS ife_app.report_type CASCADE;

CREATE TABLE ife_app.report_type (
    report_type_id    SERIAL PRIMARY KEY,
    report_type       TEXT NOT NULL,
    report_grouping   INT UNIQUE NOT NULL
);

CREATE TABLE ife_app.report_order (
    report_order_id   SERIAL NOT NULL PRIMARY KEY,
    report_type_id    INT NOT NULL REFERENCES ife_app.report_type(report_type_id),
    organization_id   INT NOT NULL,
    user_id           VARCHAR(255) NOT NULL,
    report_date       TIMESTAMP NOT NULL,
    reference_code    VARCHAR(255) NULL,
    created_at        TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE ife_app.report_order_instrument (
    report_order_instrument_id  SERIAL NOT NULL PRIMARY KEY,
    report_order_id             INT NOT NULL REFERENCES ife_app.report_order(report_order_id),
    security_id                 INT NOT NULL
);

-- Grant permissions on new tables
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA ife_app TO ife_service;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA ife_app TO ife_service;


-- ============================================================
-- STEP 3: SEED REPORT TYPES (7 types)
-- ============================================================
-- Groups 1-3 = subscribed (shown as cards with data)
-- Groups 4-7 = available (shown as description cards)

INSERT INTO ife_app.report_type (report_type, report_grouping) VALUES
    ('SHAREHOLDER_LIST', 1),               -- Liikkeeseenlaskijan osakasluettelo
    ('SHAREHOLDER_PUBLIC', 2),              -- Julkinen osakasluettelo
    ('SHAREHOLDER_CUSTOM', 3),              -- Osakaspoiminta
    ('SHAREHOLDER_BIGGEST', 4),             -- Suurimmat omistajat
    ('SECTOR_DISTRIBUTION', 5),             -- Sektorijakauma
    ('OWNERSHIP_DISTRIBUTION', 6),          -- Omistusmääräjakauma
    ('TEMPORARY_SHAREHOLDER_LIST', 7);      -- Tilapäinen osakasluettelo


-- ============================================================
-- STEP 4: SEED REPORT ORDERS (9 orders — 3 per subscribed type)
-- ============================================================

-- Type 1: Liikkeeseenlaskijan osakasluettelo
INSERT INTO ife_app.report_order (report_type_id, organization_id, user_id, report_date, reference_code, created_at) VALUES
    (1, 1234567, 'demo_user', '2026-01-24 00:00:00', NULL,             '2024-01-01 08:20:00'),
    (1, 1234567, 'demo_user', '2025-11-01 00:00:00', NULL,             '2024-01-01 08:20:00'),
    (1, 1234567, 'demo_user', '2025-12-11 00:00:00', 'REF9876543210',  '2025-12-11 09:00:00');

-- Type 2: Julkinen osakasluettelo
INSERT INTO ife_app.report_order (report_type_id, organization_id, user_id, report_date, reference_code, created_at) VALUES
    (2, 1234567, 'demo_user', '2026-01-24 00:00:00', NULL, '2024-01-01 08:20:00'),
    (2, 1234567, 'demo_user', '2025-11-01 00:00:00', NULL, '2024-01-01 08:20:00'),
    (2, 1234567, 'demo_user', '2025-10-01 00:00:00', NULL, '2024-01-01 08:20:00');

-- Type 3: Osakaspoiminta
INSERT INTO ife_app.report_order (report_type_id, organization_id, user_id, report_date, reference_code, created_at) VALUES
    (3, 1234567, 'demo_user', '2026-01-24 00:00:00', NULL, '2024-06-15 10:30:00'),
    (3, 1234567, 'demo_user', '2025-11-01 00:00:00', NULL, '2024-06-15 10:30:00'),
    (3, 1234567, 'demo_user', '2025-10-01 00:00:00', NULL, '2024-06-15 10:30:00');


-- ============================================================
-- STEP 5: LINK ORDERS TO INSTRUMENTS
-- ============================================================
INSERT INTO ife_app.report_order_instrument (report_order_id, security_id)
SELECT report_order_id, 1 FROM ife_app.report_order;


-- ============================================================
-- VERIFICATION
-- ============================================================
SELECT '--- REPORT TYPES ---' AS info;
SELECT * FROM ife_app.report_type ORDER BY report_type_id;

SELECT '--- REPORT ORDERS ---' AS info;
SELECT ro.report_order_id, rt.report_type, ro.organization_id, ro.user_id,
       ro.report_date, ro.reference_code, ro.created_at
FROM ife_app.report_order ro
JOIN ife_app.report_type rt ON ro.report_type_id = rt.report_type_id
ORDER BY rt.report_type, ro.report_date DESC;

SELECT '--- INSTRUMENTS ---' AS info;
SELECT * FROM ife_app.report_order_instrument;

SELECT '--- COUNTS ---' AS info;
SELECT 'report_type' AS tbl, COUNT(*) FROM ife_app.report_type
UNION ALL SELECT 'report_order', COUNT(*) FROM ife_app.report_order
UNION ALL SELECT 'report_order_instrument', COUNT(*) FROM ife_app.report_order_instrument;
