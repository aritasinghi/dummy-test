import axios from 'axios';
import Env from '@/config/Env';

const apiClient = axios.create({
    baseURL: Env.API_SERVER_URL,
    timeout: 30_000,
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
});

export default apiClient;
