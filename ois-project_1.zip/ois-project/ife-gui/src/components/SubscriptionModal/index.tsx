import { useState } from 'react';
import { Dialog, Button, RadioGroup, Radio, CheckboxGroup, Checkbox, Input } from '@efi/efi-ui-components';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import './SubscriptionModal.css';

type OrderType = 'one-time' | 'recurring';

interface SubscriptionModalProps {
    isOpen: boolean;
    reportTitle: string;
    onClose: () => void;
    onSubmit: () => void;
    language?: Language;
}

const SHARES = [
    { value: 'a1', label: 'Euroflex A', isin: 'FI21049685930' },
    { value: 'b1', label: 'Euroflex B', isin: 'FI21049685931' },
    { value: 'b2', label: 'Euroflex B', isin: 'FI21049685931' },
    { value: 'a2', label: 'Euroflex A', isin: 'FI21049685930' },
    { value: 'b3', label: 'Euroflex B', isin: 'FI21049685931' },
    { value: 'b4', label: 'Euroflex B', isin: 'FI21049685931' },
];

export function SubscriptionModal({ isOpen, reportTitle, onClose, onSubmit, language = 'fi' }: SubscriptionModalProps) {
    const t = translations[language].subscription;
    const [orderType, setOrderType] = useState<OrderType>('one-time');
    const [dateMode, setDateMode] = useState('custom');
    const [frequency, setFrequency] = useState('monthly');
    const [dayOfMonth, setDayOfMonth] = useState('31');
    const [selectedShares, setSelectedShares] = useState(SHARES.map(s => s.value));
    const [reference, setReference] = useState('1234567890');

    if (!isOpen) return null;

    return (
        <div className="sub-modal-dialog">
            <Dialog closeLabel={t.cancel} onClose={onClose}>
                <Dialog.Title>{t.title}: {reportTitle}</Dialog.Title>
                <Dialog.Content>
                    {/* Order type toggle */}
                    <RadioGroup name="orderType" value={orderType} onValueChange={(_, v) => setOrderType(v as OrderType)}>
                        <div className="sub-modal__order-toggle">
                            <Radio value="one-time"><Radio.Label>{t.oneTime}</Radio.Label></Radio>
                            <Radio value="recurring"><Radio.Label>{t.recurring}</Radio.Label></Radio>
                        </div>
                    </RadioGroup>

                    <hr className="sub-modal__divider" />

                    {/* ONE-TIME */}
                    {orderType === 'one-time' && (
                        <section className="sub-modal__section">
                            <h3 className="sub-modal__section-title">{t.oneTimeTitle}</h3>
                            <div className="sub-modal__two-col">
                                <div className="sub-modal__col-left">
                                    <h4 className="sub-modal__label">{t.reportDateTitle}</h4>
                                    <RadioGroup name="dateMode" value={dateMode} onValueChange={(_, v) => setDateMode(v)}>
                                        <div className="sub-modal__date-modes">
                                            <div className="sub-modal__date-modes-col">
                                                <Radio value="latest"><Radio.Label>{t.dateLatest}</Radio.Label></Radio>
                                                <Radio value="end-of-day"><Radio.Label>{t.dateEndOfDay}</Radio.Label></Radio>
                                            </div>
                                            <div className="sub-modal__date-modes-col">
                                                <Radio value="custom"><Radio.Label>{t.dateSelectCustom}</Radio.Label></Radio>
                                                {dateMode === 'custom' && (
                                                    <div className="sub-modal__date-input-wrap">
                                                        <Input type="date" value="2024-02-22" onChange={() => {}}>
                                                            <Input.Label>{t.selectDateLabel}</Input.Label>
                                                        </Input>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </RadioGroup>
                                </div>
                                <div className="sub-modal__info-box sub-modal__info-box--light">
                                    <h4 className="sub-modal__info-title">{t.dateInfoTitle}</h4>
                                    <p className="sub-modal__info-text">{t.dateInfoDesc}</p>
                                </div>
                            </div>
                        </section>
                    )}

                    {/* RECURRING */}
                    {orderType === 'recurring' && (
                        <section className="sub-modal__section">
                            <h3 className="sub-modal__section-title">{t.recurringTitle}</h3>
                            <div className="sub-modal__two-col">
                                <div className="sub-modal__col-left">
                                    <h4 className="sub-modal__label">{t.frequencyTitle}</h4>
                                    <RadioGroup name="freq" value={frequency} onValueChange={(_, v) => setFrequency(v)}>
                                        <div className="sub-modal__freq-grid">
                                            <Radio value="daily"><Radio.Label>{t.daily}</Radio.Label></Radio>
                                            <Radio value="monthly"><Radio.Label>{t.monthly}</Radio.Label></Radio>
                                            <Radio value="monthly-last"><Radio.Label>{t.monthlyLast}</Radio.Label></Radio>
                                            <Radio value="quarterly"><Radio.Label>{t.quarterly}</Radio.Label></Radio>
                                            <Radio value="quarterly-last"><Radio.Label>{t.quarterlyLast}</Radio.Label></Radio>
                                            <Radio value="yearly"><Radio.Label>{t.yearly}</Radio.Label></Radio>
                                        </div>
                                    </RadioGroup>
                                    <Input type="number" value={dayOfMonth} onChange={(e) => setDayOfMonth(e.target.value)}>
                                        <Input.Label>{t.selectDay}</Input.Label>
                                    </Input>
                                </div>
                                <div className="sub-modal__info-stack">
                                    <div className="sub-modal__info-box sub-modal__info-box--light">
                                        <h4 className="sub-modal__info-title">{t.frequencyInfoTitle}</h4>
                                        <p className="sub-modal__info-text">{t.frequencyInfoMonthly}</p>
                                    </div>
                                    <div className="sub-modal__info-box sub-modal__info-box--pink">
                                        <p className="sub-modal__info-text">{t.frequencyInfoMonthlyNote}</p>
                                    </div>
                                </div>
                            </div>
                        </section>
                    )}

                    <hr className="sub-modal__divider" />

                    {/* Shares */}
                    <section className="sub-modal__section">
                        <div className="sub-modal__two-col">
                            <div className="sub-modal__col-left">
                                <h3 className="sub-modal__section-title">{t.sharesTitle}</h3>
                                <p className="sub-modal__shares-type">{t.shareType}</p>
                                <CheckboxGroup name="shares" value={selectedShares} onValueChange={(_, v) => setSelectedShares(v)}>
                                    <div className="sub-modal__shares-grid">
                                        {SHARES.map(s => (
                                            <Checkbox key={s.value} value={s.value}>
                                                <Checkbox.Label><span className="sub-modal__checkbox-name">{s.label}</span><span className="sub-modal__checkbox-isin">{s.isin}</span></Checkbox.Label>
                                            </Checkbox>
                                        ))}
                                    </div>
                                </CheckboxGroup>
                            </div>
                            <div className="sub-modal__info-box sub-modal__info-box--light">
                                <h4 className="sub-modal__info-title">{t.shareSelectionTitle}</h4>
                                <p className="sub-modal__info-text">{t.shareSelectionDesc}</p>
                            </div>
                        </div>
                    </section>

                    <hr className="sub-modal__divider" />

                    {/* Reference */}
                    <section className="sub-modal__section">
                        <div className="sub-modal__two-col">
                            <div className="sub-modal__col-left">
                                <Input type="text" value={reference} onChange={(e) => setReference(e.target.value)}>
                                    <Input.Label>{t.referenceLabel}</Input.Label>
                                </Input>
                            </div>
                            <div className="sub-modal__info-box sub-modal__info-box--light">
                                <h4 className="sub-modal__info-title">{t.referenceInfoTitle}</h4>
                                <p className="sub-modal__info-text">{t.referenceInfoDesc}</p>
                            </div>
                        </div>
                    </section>

                    <hr className="sub-modal__divider" />
                    <div className="sub-modal__price-row">
                        <p className="sub-modal__price-note">{t.priceNote}</p>
                        <p className="sub-modal__price-next">{t.priceNextView}</p>
                    </div>
                </Dialog.Content>
                <Dialog.Buttons>
                    <Button type="reset" variant="secondary" onClick={onClose}>{t.cancel}</Button>
                    <Button type="submit" onClick={onSubmit}>{t.submit}</Button>
                </Dialog.Buttons>
            </Dialog>
        </div>
    );
}
