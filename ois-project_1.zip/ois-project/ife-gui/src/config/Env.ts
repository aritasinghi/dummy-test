interface EnvConfig {
    API_SERVER_URL: string;
}

export default class Env {
    private static _config: EnvConfig | null = null;

    private static load(): EnvConfig {
        if (!Env._config) {
            const request = new XMLHttpRequest();
            request.open('GET', `${window.location.origin}/config/env.json`, false);
            request.send(null);
            if (request.status === 200) {
                Env._config = JSON.parse(request.response) as EnvConfig;
            } else {
                Env._config = { API_SERVER_URL: '/api' };
            }
        }
        return Env._config;
    }

    public static get API_SERVER_URL(): string { return Env.load().API_SERVER_URL; }
}
