# OIS Portal — Information Elements

## Structure
```
ois-project/
├── database/
│   ├── setup.sql           ← FRESH install (drops + creates everything)
│   └── alter-existing.sql  ← If tables already exist, adds report_type_id
└── ife-gui/                ← React frontend
```

## Database Setup

### Option A: Fresh install (recommended for demo)
Run `database/setup.sql` in IntelliJ Database console as postgres superuser.
This drops existing tables and creates everything clean.

### Option B: Existing tables
If your tables already exist but report_order is missing report_type_id,
run `database/alter-existing.sql` instead.

### Connection details:
- Host: localhost:5432
- Database: postgres
- Schema: ife_app
- User: ife_app_user / Test123!

## Frontend Setup

```bash
cd ife-gui
npm install
npm run dev
```

Opens at http://localhost:5173

### Requires:
- Backend running at http://localhost:8080
- API: GET /api/reports/reporttypes
- API: POST /api/reports/order/

### env.json (public/config/env.json):
```json
{ "API_SERVER_URL": "http://localhost:8080/api" }
```

## Pages
1. **Landing Page** — Report types from API, subscribed + available cards
2. **Report Preview** — Matrix table, example image, breadcrumb
3. **Subscription Modal** — One-time/recurring, shares, reference → POST to API

## Add example image
Save your Figma screenshot as: `ife-gui/public/images/report-example.png`
