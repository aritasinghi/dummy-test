-- ============================================================
-- OIS Portal — Schema Fix + Seed Data
-- Database: postgres@localhost / schema: ife_app
-- Run each section one at a time in IntelliJ Database console
-- ============================================================


-- ============================================================
-- STEP 1: ADD report_type_id TO report_order (missing FK)
-- ============================================================
ALTER TABLE ife_app.report_order
    ADD COLUMN IF NOT EXISTS report_type_id INT;

ALTER TABLE ife_app.report_order
    ADD CONSTRAINT fk_report_order_type
    FOREIGN KEY (report_type_id)
    REFERENCES ife_app.report_type(report_type_id);

-- Fix existing rows
UPDATE ife_app.report_order SET report_type_id = 2 WHERE report_type_id IS NULL;

ALTER TABLE ife_app.report_order ALTER COLUMN report_type_id SET NOT NULL;


-- ============================================================
-- STEP 2: ADD MISSING REPORT TYPES
-- Existing: 1=SHAREHOLDER_LIST, 2=SHAREHOLDER_PUBLIC,
--           3=SHAREHOLDER_CUSTOM, 4=SHAREHOLDER_BIGGEST, 5=SEQUENCE
-- Adding:   6=SECTOR_DISTRIBUTION, 7=OWNERSHIP_DISTRIBUTION,
--           8=TEMPORARY_SHAREHOLDER_LIST
-- ============================================================
INSERT INTO ife_app.report_type (report_type, report_grouping) VALUES
    ('SECTOR_DISTRIBUTION', 6),
    ('OWNERSHIP_DISTRIBUTION', 7),
    ('TEMPORARY_SHAREHOLDER_LIST', 8)
ON CONFLICT (report_grouping) DO NOTHING;


-- ============================================================
-- STEP 3: INSERT REPORT ORDERS (9 new, 3 per subscribed type)
-- ============================================================

-- Type 1: Liikkeeseenlaskijan osakasluettelo
INSERT INTO ife_app.report_order (report_type_id, organization_id, user_id, report_date, reference_code, created_at) VALUES
    (1, 1234567, 'demo_user', '2026-01-24 00:00:00', NULL, NOW()),
    (1, 1234567, 'demo_user', '2025-11-01 00:00:00', NULL, NOW()),
    (1, 1234567, 'demo_user', '2025-12-11 00:00:00', 'REF9876543210', NOW());

-- Type 2: Julkinen osakasluettelo
INSERT INTO ife_app.report_order (report_type_id, organization_id, user_id, report_date, reference_code, created_at) VALUES
    (2, 1234567, 'demo_user', '2026-01-24 00:00:00', NULL, NOW()),
    (2, 1234567, 'demo_user', '2025-11-01 00:00:00', NULL, NOW()),
    (2, 1234567, 'demo_user', '2025-10-01 00:00:00', NULL, NOW());

-- Type 3: Osakaspoiminta
INSERT INTO ife_app.report_order (report_type_id, organization_id, user_id, report_date, reference_code, created_at) VALUES
    (3, 1234567, 'demo_user', '2026-01-24 00:00:00', NULL, NOW()),
    (3, 1234567, 'demo_user', '2025-11-01 00:00:00', NULL, NOW()),
    (3, 1234567, 'demo_user', '2025-10-01 00:00:00', NULL, NOW());


-- ============================================================
-- STEP 4: LINK ORDERS TO INSTRUMENTS
-- ============================================================
INSERT INTO ife_app.report_order_instrument (report_order_id, security_id)
SELECT report_order_id, 1
FROM ife_app.report_order
WHERE user_id = 'demo_user'
  AND report_order_id NOT IN (SELECT report_order_id FROM ife_app.report_order_instrument);


-- ============================================================
-- VERIFY
-- ============================================================
SELECT 'report_type' AS tbl, COUNT(*) FROM ife_app.report_type
UNION ALL SELECT 'report_order', COUNT(*) FROM ife_app.report_order
UNION ALL SELECT 'report_order_instrument', COUNT(*) FROM ife_app.report_order_instrument;

-- Check data
SELECT ro.report_order_id, rt.report_type, ro.report_type_id,
       ro.organization_id, ro.report_date, ro.reference_code
FROM ife_app.report_order ro
JOIN ife_app.report_type rt ON ro.report_type_id = rt.report_type_id
ORDER BY rt.report_type, ro.report_date DESC;
