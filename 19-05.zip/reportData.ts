// ─── ReportView Mock Data ─────────────────────────────────────────────────────
// Field names match the API contract (reportApiTypes.ts).
// getMockOwners is also used as fallback when the API is unavailable.

import type { FilterKey } from '@/api/reportApiTypes';

export const SHOW_DATA_KEYS = ['address', 'isin', 'expired', 'sector', 'custodian'] as const;
export type ShowDataKey = (typeof SHOW_DATA_KEYS)[number];

// ── Share info ─────────────────────────────────────────────────────────────────

export const SHARES_INFO = [
    { name: 'EUROFLEX A', isin: 'FI21049685930', abbr: 'EUROFLA' },
    { name: 'EUROFLEX B', isin: 'FI21049685931', abbr: 'EUROFLB' },
    { name: 'EUROFLEX C', isin: 'FI21049685932', abbr: 'EUROFLC' },
];

// ── Summary rows ───────────────────────────────────────────────────────────────

export const SUMMARY_ROWS = [
    { shareClassCode:'EUROFLA', ownerCount:'1 300', jointOwnerCount:'12', votesConferred:'1 006 970', votesPercentage:'50.3 %', totalVotes:'2 000 000', inShareholderList:'503 488', inWaitingList:'5 000', nomineeRegistered:'10 000', inJointAccount:'481 512', issuedAmount:'1 000 000', isBold:false, isTotal:false },
    { shareClassCode:'EUROFLB', ownerCount:'600',   jointOwnerCount:'24', votesConferred:'285 369',   votesPercentage:'71.3 %', totalVotes:'400 000',   inShareholderList:'285 369', inWaitingList:'4 800', nomineeRegistered:'18 995', inJointAccount:'90 836',  issuedAmount:'400 000',   isBold:false, isTotal:false },
    { shareClassCode:'total',   ownerCount:'1 900', jointOwnerCount:'36', votesConferred:'1 292 339', votesPercentage:'53.8 %', totalVotes:'2 400 000', inShareholderList:'788 857', inWaitingList:'9 800', nomineeRegistered:'28 995', inJointAccount:'572 348', issuedAmount:'1 400 000', isBold:true,  isTotal:true  },
];

// ── Helpers ────────────────────────────────────────────────────────────────────

const SEC  = 'Public companies excl. housing companies';
const PAY  = 'FI1234567787788';
const TAX  = 'TBC';
const DATE = '31/12/2024';
const HKI  = 'Helsinki';
const ESP  = 'Espoo';

const e = (shareClassName: string, custodianName: string, numberOfEntries: string,
           percentageCombined: string, numberOfVotes: string, votingRightsPercentage: string) =>
    ({ shareClassName, custodianName, numberOfEntries, percentageCombined, numberOfVotes, votingRightsPercentage, isTotal: false });

const tot = (numberOfEntries: string, percentageCombined: string,
             numberOfVotes: string, votingRightsPercentage: string) =>
    ({ shareClassName: 'bookEntryTotal', custodianName: '', numberOfEntries, percentageCombined, numberOfVotes, votingRightsPercentage, isTotal: true });

// ── Owner rows (25 owners across 2 pages) ─────────────────────────────────────

export const OWNER_ROWS = [
    { id:1,  fullName:'Thomas-Peter Along-lastname', personalId:'120370-8902A', dateOfBirth:'12.03.1970',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:ESP, streetAddress:'Arvo-osuuskuja 212', postAddress:'00550 Espoo', residenceCountry:'Espoo, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','30 300','3,03000','60 900','2,54000'), e('EUROFLEX B','Nordea','600','0,15000','',''), tot('30 900','2,21000','60 900','2,54000')],
      jointOwners:[] },

    { id:2, fullName:'Clarck Confidential', personalId:'020377-02908', dateOfBirth:'02.03.1977',
      customerRestriction:null, isNonDisclosure:true, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:'', streetAddress:'Yhteyssoite: Jokitie 22 b', postAddress:'00100 Helsinki', residenceCountry:'Tai Ei osoitetta', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','15','0,00005','',''), e('EUROFLEX A','Nordea','15','0,00005','',''), e('EUROFLEX B','OP','40','0,00004','100','0,00003'), tot('70','0,00003','100','0,00003')],
      jointOwners:[] },

    { id:3, fullName:'D-Yritys OY Ab', personalId:'T769765-S', dateOfBirth:'',
      customerRestriction:'bankruptcy', isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:true, isJointSubRow:false, jointParentName:null,
      municipality:HKI, streetAddress:'Arvopaperitie 12', postAddress:'00100 Helsinki', residenceCountry:'Helsinki, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','30','0,00005','',''), e('EUROFLEX B','Nordea','40','0,00004','100','0,00003'), tot('70','0,00003','100','0,00003')],
      jointOwners:[] },

    { id:4, fullName:'Thomas Elling', personalId:'200274-89020', dateOfBirth:'20.02.1974',
      customerRestriction:'estate', isNonDisclosure:false, isJointOwner:true, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:HKI, streetAddress:'Thomaksentie 12', postAddress:'00100 Helsinki', residenceCountry:'Helsinki, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','30','0,00005','',''), e('EUROFLEX B','Nordea','40','0,00004','160','0,00003'), e('EUROFLEX A','Third LTD','20','0,00003','',''), e('EUROFLEX B','4TH LTD','20','0,00003','',''), tot('110','0,00003','160','0,00003')],
      jointOwners:[{name:'Tiina Ollila',isLinkable:false},{name:'Veijo Välisää',isLinkable:true}] },

    { id:5, fullName:'Thomas Elling', personalId:'200274-89020', dateOfBirth:'20.02.1974',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:true, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:HKI, streetAddress:'Thomaksentie 12', postAddress:'00100 Helsinki', residenceCountry:'Helsinki, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','30','0,00005','',''), e('EUROFLEX B','Nordea','40','0,00004','603','0,00003'), tot('70','0,00003','603','0,00003')],
      jointOwners:[{name:'Tiina Ollila',isLinkable:false},{name:'Veijo Välisää',isLinkable:true}] },

    { id:6, fullName:'William Elling', personalId:'180372-89020', dateOfBirth:'18.03.1972',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:HKI, streetAddress:'Viljaminkuja 22 b 33', postAddress:'00100 Helsinki', residenceCountry:'Helsinki, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','30','0,00005','',''), e('EUROFLEX B','Nordea','40','0,00004','603','0,00003'), tot('70','0,00003','603','0,00003')],
      jointOwners:[] },

    { id:7, fullName:'Elli Ollinen', personalId:'120378-1902B', dateOfBirth:'12.03.1978',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:true, jointParentName:'Thomas Elling',
      municipality:HKI, streetAddress:'Elisenkuja 6 B', postAddress:'00100 Helsinki', residenceCountry:'Helsinki, Finland', situationDate:null, sectorName:'', paymentInfo:'', taxInfo:'',
      bookEntries:[], jointOwners:[] },

    { id:8, fullName:'Sakari Penttinen', personalId:'220368-3456A', dateOfBirth:'23.03.1968',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:HKI, streetAddress:'Sakarianpolku 1 C', postAddress:'00100 Helsinki', residenceCountry:'Helsinki, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','30','0,00005','3','0,00005'), tot('30','0,00005','3','0,00005')],
      jointOwners:[] },

    { id:9, fullName:'SEC Custody Bank', personalId:'1169765-6', dateOfBirth:'',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:true, isCustodianBank:true, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:HKI, streetAddress:'Pankkiirinkatu 32', postAddress:'00100 Helsinki', residenceCountry:'Helsinki, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','120','0,00010','70','0,00010'), e('EUROFLEX B','Nordea','60','0,00010','',''), tot('180','0,00008','70','0,00010')],
      jointOwners:[] },

    { id:10, fullName:'Matti Virtanen', personalId:'050565-1234A', dateOfBirth:'05.05.1965',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:'Tampere', streetAddress:'Hämeenkatu 10', postAddress:'33100 Tampere', residenceCountry:'Tampere, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','500','0,05000','1000','0,04200'), e('EUROFLEX B','Nordea','200','0,05000','',''), e('EUROFLEX C','OP','100','0,01000','',''), tot('800','0,04000','1000','0,04200')],
      jointOwners:[] },

    { id:11, fullName:'Liisa Korhonen', personalId:'120780-5678B', dateOfBirth:'12.07.1980',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:'Turku', streetAddress:'Aurakatu 5', postAddress:'20100 Turku', residenceCountry:'Turku, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','Nordea','250','0,02500','500','0,02100'), tot('250','0,02500','500','0,02100')],
      jointOwners:[] },

    { id:12, fullName:'Kiinteisto Oy Kallio', personalId:'1234567-8', dateOfBirth:'',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:true, isJointSubRow:false, jointParentName:null,
      municipality:HKI, streetAddress:'Fleminginkatu 2', postAddress:'00530 Helsinki', residenceCountry:'Helsinki, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','1500','0,15000','3000','0,12500'), e('EUROFLEX B','Nordea','500','0,12500','',''), tot('2000','0,10000','3000','0,12500')],
      jointOwners:[] },

    { id:13, fullName:'Pekka Leinonen', personalId:'301275-9012C', dateOfBirth:'30.12.1975',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:'Oulu', streetAddress:'Kirkkokatu 8', postAddress:'90100 Oulu', residenceCountry:'Oulu, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','75','0,00750','150','0,00630'), tot('75','0,00750','150','0,00630')],
      jointOwners:[] },

    { id:14, fullName:'Antti Makinen', personalId:'150390-3456D', dateOfBirth:'15.03.1990',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:'Jyvaskyla', streetAddress:'Kauppakatu 15', postAddress:'40100 Jyvaskyla', residenceCountry:'Jyvaskyla, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX B','Nordea','120','0,03000','',''), tot('120','0,03000','','')],
      jointOwners:[] },

    { id:15, fullName:'Johanna Nieminen', personalId:'220488-7890E', dateOfBirth:'22.04.1988',
      customerRestriction:null, isNonDisclosure:true, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:'Lahti', streetAddress:'Aleksanterinkatu 12', postAddress:'15100 Lahti', residenceCountry:'Lahti, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','300','0,03000','600','0,02520'), e('EUROFLEX C','Nordea','100','0,01000','',''), tot('400','0,02000','600','0,02520')],
      jointOwners:[] },

    { id:16, fullName:'Elakevakuutus Oy', personalId:'9876543-2', dateOfBirth:'',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:true, isCompany:true, isJointSubRow:false, jointParentName:null,
      municipality:HKI, streetAddress:'Elakekatu 3', postAddress:'00180 Helsinki', residenceCountry:'Helsinki, Finland', situationDate:DATE, sectorName:'Financial and insurance institutions', paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','5000','0,50000','10000','0,42000'), e('EUROFLEX B','Nordea','2000','0,50000','',''), tot('7000','0,35000','10000','0,42000')],
      jointOwners:[] },

    { id:17, fullName:'Tuija Hakkarainen', personalId:'010172-4321F', dateOfBirth:'01.01.1972',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:true, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:'Kuopio', streetAddress:'Puijonkatu 7', postAddress:'70100 Kuopio', residenceCountry:'Kuopio, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','50','0,00500','100','0,00420'), tot('50','0,00500','100','0,00420')],
      jointOwners:[{name:'Harri Hakkarainen',isLinkable:false}] },

    { id:18, fullName:'Nordic Investors Ltd', personalId:'5555555-5', dateOfBirth:'',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:true, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:HKI, streetAddress:'Mannerheimintie 100', postAddress:'00250 Helsinki', residenceCountry:'Helsinki, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','800','0,08000','1600','0,06720'), e('EUROFLEX B','Nordea','400','0,10000','',''), tot('1200','0,06000','1600','0,06720')],
      jointOwners:[] },

    { id:19, fullName:'Kaarina Virtanen', personalId:'300555-8765G', dateOfBirth:'30.05.1955',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:'Pori', streetAddress:'Yrjonkatu 4', postAddress:'28100 Pori', residenceCountry:'Pori, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','Nordea','180','0,01800','360','0,01512'), tot('180','0,01800','360','0,01512')],
      jointOwners:[] },

    { id:20, fullName:'Investment Co Future', personalId:'7777777-7', dateOfBirth:'',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:true, isJointSubRow:false, jointParentName:null,
      municipality:'Tampere', streetAddress:'Nasilinnankatu 20', postAddress:'33210 Tampere', residenceCountry:'Tampere, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','1000','0,10000','2000','0,08400'), e('EUROFLEX A','Nordea','500','0,05000','',''), e('EUROFLEX B','Third LTD','300','0,07500','',''), tot('1800','0,09000','2000','0,08400')],
      jointOwners:[] },

    { id:21, fullName:'Eero Koivisto', personalId:'140268-2345H', dateOfBirth:'14.02.1968',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:'Lappeenranta', streetAddress:'Valtakatu 3', postAddress:'53100 Lappeenranta', residenceCountry:'Lappeenranta, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX C','OP','40','0,00400','',''), tot('40','0,00400','','')],
      jointOwners:[] },

    { id:22, fullName:'Riitta Saarinen', personalId:'250870-6789I', dateOfBirth:'25.08.1970',
      customerRestriction:'enforcement', isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:'Hameenlinna', streetAddress:'Raatihuoneenkatu 6', postAddress:'13100 Hameenlinna', residenceCountry:'Hameenlinna, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','90','0,00900','180','0,00756'), tot('90','0,00900','180','0,00756')],
      jointOwners:[] },

    { id:23, fullName:'Baltic Custody AS', personalId:'8888888-8', dateOfBirth:'',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:true, isCustodianBank:true, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:HKI, streetAddress:'Unioninkatu 22', postAddress:'00130 Helsinki', residenceCountry:'Helsinki, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','OP','2500','0,25000','5000','0,21000'), e('EUROFLEX B','Nordea','1000','0,25000','',''), tot('3500','0,17500','5000','0,21000')],
      jointOwners:[] },

    { id:24, fullName:'Timo Lehtonen', personalId:'060492-3456J', dateOfBirth:'06.04.1992',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:'Jyvaskyla', streetAddress:'Yliopistonkatu 12', postAddress:'40100 Jyvaskyla', residenceCountry:'Jyvaskyla, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX B','OP','60','0,01500','',''), tot('60','0,01500','','')],
      jointOwners:[] },

    { id:25, fullName:'Sirpa Lahteenmaki', personalId:'170383-5678K', dateOfBirth:'17.03.1983',
      customerRestriction:null, isNonDisclosure:false, isJointOwner:false, isNomineeRegistered:false, isCustodianBank:false, isCompany:false, isJointSubRow:false, jointParentName:null,
      municipality:'Turku', streetAddress:'Eerikinkatu 9', postAddress:'20100 Turku', residenceCountry:'Turku, Finland', situationDate:DATE, sectorName:SEC, paymentInfo:PAY, taxInfo:TAX,
      bookEntries:[e('EUROFLEX A','Nordea','110','0,01100','220','0,00924'), e('EUROFLEX C','OP','50','0,00500','',''), tot('160','0,00800','220','0,00924')],
      jointOwners:[] },
];

// ─── getMockOwners — client-side filter + pagination ──────────────────────────

export function getMockOwners(
    page:          number,
    pageSize:      number,
    search?:       string,
    activeFilters: FilterKey[] = [],
) {
    let rows = [...OWNER_ROWS];

    if (search) {
        const q = search.toLowerCase();
        rows = rows.filter(o => o.fullName.toLowerCase().includes(q));
    }

    if (activeFilters.length > 0) {
        rows = rows.filter(o => {
            const hasReg    = activeFilters.includes('directly') || activeFilters.includes('nominee');
            const hasSector = activeFilters.includes('companies') || activeFilters.includes('financial') || activeFilters.includes('households');
            const regOk     = !hasReg
                || (activeFilters.includes('directly') && !o.isNomineeRegistered && !o.isCustodianBank)
                || (activeFilters.includes('nominee')  && (o.isNomineeRegistered || o.isCustodianBank));
            const secOk     = !hasSector
                || (activeFilters.includes('companies')  && o.isCompany   && !o.isCustodianBank)
                || (activeFilters.includes('financial')  && o.isCustodianBank)
                || (activeFilters.includes('households') && !o.isCompany && !o.isCustodianBank && !o.isNomineeRegistered && !o.isJointSubRow);
            return regOk && secOk;
        });
    }

    const total      = rows.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    const safePage   = Math.max(1, Math.min(page, totalPages));
    const from       = (safePage - 1) * pageSize;

    return {
        owners:     rows.slice(from, from + pageSize),
        totalCount: total,
        totalPages,
        page:       safePage,
        pageSize,
    };
}
