// ─── API Contract Types ───────────────────────────────────────────────────────
// These match the backend JSON field names exactly.
// Used by: reportApi.ts, useReportData.ts

// ── Existing endpoints ─────────────────────────────────────────────────────

export type FilterKey = 'directly' | 'nominee' | 'companies' | 'financial' | 'households';

// GET /api/reports/reporttypes
// NOTE: named ReportTypeOption to avoid conflict with ReportType in types.ts
export interface ReportTypeOption {
    report_type_id: number;
    report_name:    string;
    report_group:   number;
}

// GET /api/reports/shareholder/{reportId}/filters
export interface ShareholderFilterCounts {
    directCount:    number;
    nomineeCount:   number;
    companyCount:   number;
    financialCount: number;
    householdCount: number;
    filteredOwners: number;
    filteredUnits:  number;
}

// GET /api/data/security/{securityId}
// GET /api/data/securities/issuer/{issuerId}
export interface Security {
    securityId:        number;
    securityName:      string;
    securityShortName: string;
    securityType:      number;
    clauseFlag:        number;
    isActive:          boolean;
}

// GET /api/reports/pricing/{reportOrderId}
export interface ReportPricing {
    reportOrderId: number;
    price:         number;
}

// POST /api/reports/order/
export interface ReportOrderRequest {
    reportTypeId:  number;
    businessCode:  string;
    userId:        string;
    reportDate:    string;
    instruments:   number[];
    referenceCode: string;
}

// ── Missing endpoints (to be built) ───────────────────────────────────────

// GET /api/reports/shareholder/{reportId}/metadata
export interface ReportMetadata {
    issuerId:      number;
    issuerName:    string;
    reportName:    string;
    situationDate: string;
    reportDate:    string;
}

// GET /api/reports/shareholder/{reportId}/owners response wrapper
export interface OwnersResponse {
    owners:     OwnerRow[];
    totalCount: number;
    totalPages: number;
    page:       number;
    pageSize:   number;
}

// One owner row — field names match backend DTO
export interface OwnerRow {
    id:                  number;
    fullName:            string;
    personalId:          string;
    dateOfBirth:         string | null;
    customerRestriction: string | null;
    isNonDisclosure:     boolean;
    isJointOwner:        boolean;
    isNomineeRegistered: boolean;
    isCustodianBank:     boolean;
    isCompany:           boolean;
    isJointSubRow:       boolean;
    jointParentName:     string | null;
    municipality:        string;
    streetAddress:       string;
    postAddress:         string;
    residenceCountry:    string;
    situationDate:       string | null;
    sectorName:          string;
    paymentInfo:         string;
    taxInfo:             string;
    bookEntries:         BookEntry[];
    jointOwners:         JointOwner[];
}

// One book-entry line within an owner row
// isTotal=true → last summary line (use t.totalSharesLabel, not shareClassName)
export interface BookEntry {
    shareClassName:         string;
    custodianName:          string;
    numberOfEntries:        string;
    percentageCombined:     string;
    numberOfVotes:          string;
    votingRightsPercentage: string;
    isTotal:                boolean;
}

export interface JointOwner {
    name:       string;
    isLinkable: boolean;
}

// GET /api/reports/shareholder/{reportId}/owners query params
export interface OwnersRequest {
    page:          number;
    pageSize:      number;
    search?:       string;
    activeFilters: FilterKey[];
}
