// ─── ReportView Types ─────────────────────────────────────────────────────────
// Single source of truth for all component types.
// OwnerRow, BookEntry, JointOwner are re-exported from the API contract
// so there is exactly ONE definition throughout the codebase.

// ── Re-export API types used by components ─────────────────────────────────
export type {
    OwnerRow,
    BookEntry,
    JointOwner,
    OwnersResponse,
    ShareholderFilterCounts,
    ReportMetadata,
    Security,
    FilterKey,
} from '@/api/reportApiTypes';

// ── UI-only types ──────────────────────────────────────────────────────────
// ReportType is the radio button value — different from the API ReportTypeOption
export type ReportType = 'statutory' | 'full' | 'agm' | 'short';
export type SortDir    = 'asc' | 'desc';
export type SortField  = 'name' | 'bookEntries' | 'votes';

// ── SummaryRow ─────────────────────────────────────────────────────────────
// Backend returns pre-formatted strings (e.g. "1 300", "50.3 %")
export interface SummaryRow {
    shareClassCode:    string;
    ownerCount:        string;
    jointOwnerCount:   string;
    votesConferred:    string;
    votesPercentage:   string;
    totalVotes:        string;
    inShareholderList: string;
    inWaitingList:     string;
    nomineeRegistered: string;
    inJointAccount:    string;
    issuedAmount:      string;
    isBold:            boolean;
    isTotal:           boolean;
}

// ── ShareInfo ──────────────────────────────────────────────────────────────
// Used in the report header cards
export interface ShareInfo {
    name: string;
    isin: string;
    abbr: string;
}

// ── ColVisibility ──────────────────────────────────────────────────────────
// Controls which columns are rendered in OwnerTable / OwnerTableRow
export type ColVisibility = {
    addr:      boolean; // Street address + post + country (statutory, full)
    city:      boolean; // Municipality only (AGM)
    custodian: boolean; // Depository participant (also toggled by showData.custodian)
    pct:       boolean; // % of book-entries combined (full, short)
    votes:     boolean; // Number of votes (full)
    votePct:   boolean; // % of total voting rights (full)
    date:      boolean; // Situation date (currently unused)
    sector:    boolean; // Sector (full — also toggled by showData.sector)
    payment:   boolean; // Payment info (statutory, full)
    tax:       boolean; // Tax info (statutory, full)
};

// ── SHOW_FILTERS_FOR ───────────────────────────────────────────────────────
// Whether the "Show details" + "Filtering" sections appear (Full only)
export const SHOW_FILTERS_FOR: Record<ReportType, boolean> = {
    statutory: false,
    full:      true,
    agm:       false,
    short:     false,
};

// ── COLS ───────────────────────────────────────────────────────────────────
// Column visibility per report type — no ghost columns, purely show/hide
//                    addr   city   cust   pct    votes  vpct   date   sector pay    tax
export const COLS: Record<ReportType, ColVisibility> = {
    statutory: { addr:true,  city:false, custodian:true,  pct:false, votes:false, votePct:false, date:false, sector:false, payment:true,  tax:true  },
    full:      { addr:true,  city:false, custodian:true,  pct:true,  votes:true,  votePct:true,  date:false, sector:true,  payment:true,  tax:true  },
    agm:       { addr:false, city:true,  custodian:false, pct:false, votes:false, votePct:false, date:false, sector:false, payment:false, tax:false },
    short:     { addr:false, city:false, custodian:true,  pct:true,  votes:false, votePct:false, date:false, sector:false, payment:false, tax:false },
};
