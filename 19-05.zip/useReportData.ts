// ─── useReportData ────────────────────────────────────────────────────────────
// Loads mock data immediately, fires real API calls in background.
// On API success → upgrades data. On failure → mock stays.

import { useState, useEffect, useCallback, useRef } from 'react';
import type { FilterKey, OwnersResponse, ShareholderFilterCounts, Security, ReportMetadata, OwnerRow } from '@/api/reportApiTypes';
import type { SummaryRow } from './types';
import { fetchReportMetadata, fetchSecuritiesByIssuer, fetchFilterCounts, fetchSummaryRows, fetchOwners } from '@/api/reportApi';
import { OWNER_ROWS, SUMMARY_ROWS, SHARES_INFO, getMockOwners } from './reportData';

const PAGE_SIZE = 13;
const DEBOUNCE  = 300;

export interface UseReportDataReturn {
    metadata:      ReportMetadata;
    summaryRows:   SummaryRow[];
    securities:    Security[];
    filterCounts:  ShareholderFilterCounts;
    metaLoading:   boolean;
    owners:        OwnerRow[];
    totalCount:    number;
    totalPages:    number;
    currentPage:   number;
    ownersLoading: boolean;
    setPage:       (p: number) => void;
    setSearch:     (s: string) => void;
    setFilters:    (f: FilterKey[]) => void;
    search:        string;
    activeFilters: FilterKey[];
}

// ── Mock defaults (shown immediately on first render) ──────────────────────

const MOCK_META: ReportMetadata = {
    issuerId: 800001,
    issuerName: 'Euroflex Oyj',
    reportName: 'Liikkeeseenlaskijan omistusraportti',
    situationDate: '13.3.2026',
    reportDate: '2026-01-11',
};

const MOCK_FILTER_COUNTS: ShareholderFilterCounts = {
    directCount: 2379, nomineeCount: 12, companyCount: 1112,
    financialCount: 23, householdCount: 1856,
    filteredOwners: OWNER_ROWS.length,
    filteredUnits:  OWNER_ROWS.reduce((s, r) => s + r.bookEntries.length, 0),
};

const MOCK_SECURITIES: Security[] = SHARES_INFO.map((s, i) => ({
    securityId: 900001 + i,
    securityName: s.name,
    securityShortName: s.abbr,
    securityType: 0,
    clauseFlag: 0,
    isActive: true,
}));

const firstPage = getMockOwners(1, PAGE_SIZE, undefined, []);

// ── Hook ───────────────────────────────────────────────────────────────────

export function useReportData(reportId: number): UseReportDataReturn {
    const [metadata,     setMetadata]     = useState<ReportMetadata>(MOCK_META);
    const [summaryRows,  setSummaryRows]  = useState<SummaryRow[]>(SUMMARY_ROWS);
    const [securities,   setSecurities]   = useState<Security[]>(MOCK_SECURITIES);
    const [filterCounts, setFilterCounts] = useState<ShareholderFilterCounts>(MOCK_FILTER_COUNTS);
    const [metaLoading,  setMetaLoading]  = useState(false);

    const [owners,        setOwners]       = useState<OwnerRow[]>(firstPage.owners as OwnerRow[]);
    const [totalCount,    setTotalCount]   = useState(firstPage.totalCount);
    const [totalPages,    setTotalPages]   = useState(firstPage.totalPages);
    const [currentPage,   setCurrentPage] = useState(1);
    const [ownersLoading, setOwnersLoading] = useState(false);

    const [search,          setSearchRaw]       = useState('');
    const [debouncedSearch, setDebouncedSearch] = useState('');
    const [activeFilters,   setActiveFilters]   = useState<FilterKey[]>([]);

    const isFirstEffect = useRef(true);

    const applyOwners = useCallback((res: OwnersResponse) => {
        setOwners(res.owners as OwnerRow[]);
        setTotalCount(res.totalCount);
        setTotalPages(res.totalPages);
    }, []);

    // Debounce search
    const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const setSearch = useCallback((val: string) => {
        setSearchRaw(val);
        if (debounceRef.current) clearTimeout(debounceRef.current);
        debounceRef.current = setTimeout(() => {
            setDebouncedSearch(val);
            setCurrentPage(1);
        }, DEBOUNCE);
    }, []);

    const setFilters = useCallback((f: FilterKey[]) => {
        setActiveFilters(f);
        setCurrentPage(1);
    }, []);

    const setPage = useCallback((p: number) => setCurrentPage(p), []);

    // Initial load — fire real APIs, silently fall back to mock on error
    useEffect(() => {
        if (!reportId) return;
        setMetaLoading(true);

        Promise.allSettled([
            fetchReportMetadata(reportId),
            fetchSummaryRows(reportId),
            fetchFilterCounts(reportId, []),
            fetchOwners(reportId, { page: 1, pageSize: PAGE_SIZE, activeFilters: [] }),
        ]).then(([metaRes, summaryRes, countsRes, ownersRes]) => {
            if (metaRes.status === 'fulfilled') {
                setMetadata(metaRes.value);
                if (metaRes.value.issuerId) {
                    fetchSecuritiesByIssuer(metaRes.value.issuerId)
                        .then(setSecurities)
                        .catch(() => {/* keep mock */});
                }
            }
            if (summaryRes.status === 'fulfilled') setSummaryRows(summaryRes.value as unknown as SummaryRow[]);
            if (countsRes.status  === 'fulfilled') setFilterCounts(countsRes.value);
            if (ownersRes.status  === 'fulfilled') applyOwners(ownersRes.value);
        }).finally(() => setMetaLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [reportId]);

    // Subsequent owner calls (pagination / search / filter)
    useEffect(() => {
        if (isFirstEffect.current) { isFirstEffect.current = false; return; }
        if (!reportId) return;

        setOwnersLoading(true);
        const ctrl = new AbortController();

        fetchOwners(reportId, {
            page: currentPage, pageSize: PAGE_SIZE,
            search: debouncedSearch || undefined,
            activeFilters,
        })
            .then(res => { if (!ctrl.signal.aborted) applyOwners(res); })
            .catch(() => {
                if (ctrl.signal.aborted) return;
                const mock = getMockOwners(currentPage, PAGE_SIZE, debouncedSearch, activeFilters);
                setOwners(mock.owners as OwnerRow[]);
                setTotalCount(mock.totalCount);
                setTotalPages(mock.totalPages);
            })
            .finally(() => { if (!ctrl.signal.aborted) setOwnersLoading(false); });

        return () => ctrl.abort();
    }, [reportId, currentPage, debouncedSearch, activeFilters, applyOwners]);

    return {
        metadata, summaryRows, securities, filterCounts, metaLoading,
        owners, totalCount, totalPages, currentPage, ownersLoading,
        setPage, setSearch, setFilters, search, activeFilters,
    };
}
