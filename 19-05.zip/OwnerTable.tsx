// ─── OwnerTable ───────────────────────────────────────────────────────────────
// Teal header background: ONLY columns 1-3 (name, address/city, book-entry-type)
// All other columns: white background
// showData.custodian and showData.sector control column visibility

import { Table } from '@efi/efi-ui-components';
import type { OwnerRow, ColVisibility, SortDir } from './types';
import type { Translations } from '@/locales';
import { OwnerTableRow } from './OwnerTableRow';

type T = Translations['reportView'];

interface Props {
    rows:     OwnerRow[];
    cols:     ColVisibility;
    t:        T;
    sortDir:  SortDir;
    onSort:   (dir: SortDir) => void;
}

export function OwnerTable({ rows, cols, t, sortDir, onSort }: Props) {
    return (
        <div className="rv__table-wrap">
            <Table layout="auto" hover>
                <Table.Head>
                    <Table.Row>

                        {/* ── Col 1: Name — PRIMARY (teal bg) ── */}
                        <Table.HeadCell
                            column="name"
                            sortable
                            sortDirection={sortDir}
                            className="rv__th rv__th--primary rv__th--sort"
                            onSort={(dir: SortDir) => onSort(dir)}
                        >
                            {t.colName}
                            <Table.SecondaryText>{t.colIdentCode}</Table.SecondaryText>
                            <Table.SecondaryText>{t.colDob}</Table.SecondaryText>
                            <Table.SecondaryText>{t.colCustomerRestrictions}</Table.SecondaryText>
                        </Table.HeadCell>

                        {/* ── Col 2a: Street address — PRIMARY (teal bg) ── */}
                        {cols.addr && (
                            <Table.HeadCell column="addr" className="rv__th rv__th--primary">
                                {t.colStreetAddress}
                                <Table.SecondaryText>{t.colPostAddress}</Table.SecondaryText>
                                <Table.SecondaryText>{t.colMunicipalityCountry}</Table.SecondaryText>
                            </Table.HeadCell>
                        )}

                        {/* ── Col 2b: Municipality only (AGM) — PRIMARY (teal bg) ── */}
                        {cols.city && (
                            <Table.HeadCell column="city" className="rv__th rv__th--primary">
                                {t.colMunicipality}
                            </Table.HeadCell>
                        )}

                        {/* ── Col 3: Book-entry type — PRIMARY (teal bg) ── */}
                        <Table.HeadCell column="type" className="rv__th rv__th--primary">
                            {t.colBookEntryType}
                        </Table.HeadCell>

                        {/* ── Col 4+: Data columns — WHITE background ── */}

                        {cols.custodian && (
                            <Table.HeadCell column="cust" className="rv__th rv__th--data">
                                {t.colDepositoryParticipant}
                            </Table.HeadCell>
                        )}

                        <Table.HeadCell column="amt" align="right" className="rv__th rv__th--data">
                            {t.colNumberOfBookEntries}
                        </Table.HeadCell>

                        {cols.pct && (
                            <Table.HeadCell column="pct" align="right" className="rv__th rv__th--data">
                                {t.colPctBookEntries}
                            </Table.HeadCell>
                        )}

                        {cols.votes && (
                            <Table.HeadCell column="votes" align="right" className="rv__th rv__th--data">
                                {t.colNumberOfVotes}
                            </Table.HeadCell>
                        )}

                        {cols.votePct && (
                            <Table.HeadCell column="vpct" align="right" className="rv__th rv__th--data">
                                {t.colPctVotingRights}
                            </Table.HeadCell>
                        )}

                        {cols.date && (
                            <Table.HeadCell column="date" className="rv__th rv__th--data">
                                {t.colSituationDate}
                            </Table.HeadCell>
                        )}

                        {cols.sector && (
                            <Table.HeadCell column="sec" className="rv__th rv__th--data">
                                {t.colSector}
                            </Table.HeadCell>
                        )}

                        {cols.payment && (
                            <Table.HeadCell column="pay" className="rv__th rv__th--data">
                                {t.colPaymentInfo}
                            </Table.HeadCell>
                        )}

                        {cols.tax && (
                            <Table.HeadCell column="tax" className="rv__th rv__th--data">
                                {t.colTaxInfo}
                            </Table.HeadCell>
                        )}

                    </Table.Row>
                </Table.Head>

                <Table.Body>
                    {(Array.isArray(rows) ? rows : []).map(row => (
                        <OwnerTableRow key={row.id} row={row} cols={cols} t={t} />
                    ))}
                </Table.Body>
            </Table>
        </div>
    );
}
