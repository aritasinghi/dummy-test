import { Table, TextLink } from '@efi/efi-ui-components';
import type { OwnerRow, ColVisibility } from './types';
import type { Translations } from '@/locales';

type T = Translations['reportView'];

interface Props {
    row:  OwnerRow;
    cols: ColVisibility;
    t:    T;
}

export function OwnerTableRow({ row, cols, t }: Props) {

    // ── Joint sub-row ──────────────────────────────────────────────────────────
    if (row.isJointSubRow) {
        return (
            <Table.Row className="rv__row--joint-sub">
                {/* Col 1 — always */}
                <Table.BodyCell>
                    <div className="rv__name-cell">
                        <div className="rv__name-row">
                            <span className="rv__flag">🔗</span>
                            <span className="rv__sub-label">{t.jointSubLabel}</span>
                        </div>
                        <div className="rv__joint-parent">
                            {t.jointParentLabel}: <TextLink href="#">{row.jointParentName}</TextLink>
                        </div>
                        <span className="rv__ssn-text">{row.personalId}</span>
                        {row.dateOfBirth && <span className="rv__ssn-text">{row.dateOfBirth}</span>}
                    </div>
                </Table.BodyCell>
                {/* Col 2a/2b — addr or city */}
                {cols.addr && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.city && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {/* Col 3 — book-entry type, always */}
                <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>
                {/* Col 4+ — data cols */}
                {cols.custodian && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>
                {cols.pct     && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.votes   && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.votePct && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.date    && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.sector  && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.payment && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.tax     && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
            </Table.Row>
        );
    }

    // ── Normal row ─────────────────────────────────────────────────────────────
    return (
        <Table.Row>

            {/* Col 1: Name / Personal ID / DOB / Restriction — always */}
            <Table.BodyCell>
                <div className="rv__name-cell">
                    <div className="rv__name-row">
                        {row.isCustodianBank && (
                            <span className="rv__flag" title={t.flagNomineeReg}>🏦</span>
                        )}
                        {row.isCompany && !row.isCustodianBank && (
                            <span className="rv__flag" title={t.flagNomineeReg}>🏢</span>
                        )}
                        <TextLink href="#"><strong>{row.fullName}</strong></TextLink>
                        {row.isNonDisclosure && (
                            <span className="rv__flag" title={t.flagNonDisclosure}>🚫</span>
                        )}
                        {row.isNomineeRegistered && !row.isCustodianBank && (
                            <span className="rv__flag" title={t.flagNominee}>📋</span>
                        )}
                    </div>
                    <span className="rv__ssn-text">{row.personalId}</span>
                    {row.dateOfBirth && (
                        <span className="rv__ssn-text">{row.dateOfBirth}</span>
                    )}
                    {row.customerRestriction && (
                        <span className="rv__restriction">
                            {t.customerRestriction}: <strong>{row.customerRestriction}</strong>
                        </span>
                    )}
                    {row.isJointOwner && row.jointOwners && row.jointOwners.length > 0 && (
                        <div className="rv__joint-section">
                            <span className="rv__joint-label">
                                {t.legendJointOwnership}:
                            </span>
                            {row.jointOwners.map((o, i) => (
                                <span key={i} className="rv__cell-sm">
                                    {o.isLinkable
                                        ? <TextLink href="#">{o.name}</TextLink>
                                        : o.name}
                                    {i < row.jointOwners!.length - 1 && ', '}
                                </span>
                            ))}
                        </div>
                    )}
                </div>
            </Table.BodyCell>

            {/* Col 2a: Street address (statutory, full) */}
            {cols.addr && (
                <Table.BodyCell>
                    <div className="rv__cell-sm">
                        {row.streetAddress}<br />
                        {row.postAddress}<br />
                        {row.residenceCountry}
                    </div>
                </Table.BodyCell>
            )}

            {/* Col 2b: Municipality only (AGM) */}
            {cols.city && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.municipality}</span>
                </Table.BodyCell>
            )}

            {/* Col 3: Book-entry type — always */}
            <Table.BodyCell>
                <div className="rv__shares-vertical">
                    {(row.bookEntries ?? []).map((s, i) => (
                        <div key={i} className={s.isTotal ? 'rv__cell-total' : 'rv__cell-sm'}>
                            {s.isTotal ? t.totalSharesLabel : s.shareClassName}
                        </div>
                    ))}
                </div>
            </Table.BodyCell>

            {/* Col 4: Custodian — controlled by cols.custodian */}
            {cols.custodian && (
                <Table.BodyCell>
                    <div className="rv__shares-vertical">
                        {(row.bookEntries ?? []).map((s, i) => (
                            <div key={i} className="rv__cell-sm">
                                {s.isTotal ? '' : (s.custodianName || '')}
                            </div>
                        ))}
                    </div>
                </Table.BodyCell>
            )}

            {/* Col 5: Number of book-entries — always */}
            <Table.BodyCell>
                <div className="rv__shares-vertical rv__shares-vertical--right">
                    {(row.bookEntries ?? []).map((s, i) => (
                        <div key={i} className={s.isTotal ? 'rv__cell-total' : 'rv__cell-sm'}>
                            {s.numberOfEntries}
                        </div>
                    ))}
                </div>
            </Table.BodyCell>

            {/* Col 6: % combined (full, short) — cols.pct */}
            {cols.pct && (
                <Table.BodyCell>
                    <div className="rv__shares-vertical rv__shares-vertical--right">
                        {(row.bookEntries ?? []).map((s, i) => (
                            <div key={i} className="rv__cell-sm">{s.percentageCombined}</div>
                        ))}
                    </div>
                </Table.BodyCell>
            )}

            {/* Col 7: Votes (full only) — cols.votes */}
            {cols.votes && (
                <Table.BodyCell>
                    <div className="rv__shares-vertical rv__shares-vertical--right">
                        {(row.bookEntries ?? []).map((s, i) => (
                            <div key={i} className={s.isTotal ? 'rv__cell-total' : 'rv__cell-sm'}>
                                {s.numberOfVotes || ''}
                            </div>
                        ))}
                    </div>
                </Table.BodyCell>
            )}

            {/* Col 8: Vote % (full only) — cols.votePct */}
            {cols.votePct && (
                <Table.BodyCell>
                    <div className="rv__shares-vertical rv__shares-vertical--right">
                        {(row.bookEntries ?? []).map((s, i) => (
                            <div key={i} className="rv__cell-sm">
                                {s.votingRightsPercentage || ''}
                            </div>
                        ))}
                    </div>
                </Table.BodyCell>
            )}

            {/* Col 9: Situation date — cols.date */}
            {cols.date && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.situationDate}</span>
                </Table.BodyCell>
            )}

            {/* Col 10: Sector — cols.sector (also controlled by showData.sector) */}
            {cols.sector && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.sectorName}</span>
                </Table.BodyCell>
            )}

            {/* Col 11: Payment info — cols.payment */}
            {cols.payment && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.paymentInfo}</span>
                </Table.BodyCell>
            )}

            {/* Col 12: Tax info — cols.tax */}
            {cols.tax && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.taxInfo}</span>
                </Table.BodyCell>
            )}

        </Table.Row>
    );
}
