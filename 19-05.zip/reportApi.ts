// ─── Report API Service ───────────────────────────────────────────────────────
// Calls real backend. Falls back to mock data if endpoint not yet available.

import type {
    ReportTypeOption,
    ShareholderFilterCounts,
    Security,
    ReportPricing,
    ReportOrderRequest,
    OwnersResponse,
    ReportMetadata,
    FilterKey,
} from './reportApiTypes';
import type { SummaryRow } from '@/pages/ReportView/types';

const BASE = import.meta.env.VITE_API_BASE_URL ?? '/api';

async function get<T>(url: string): Promise<T> {
    const res = await fetch(url, { headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error(`[API] ${res.status} ${url}`);
    return res.json() as Promise<T>;
}

async function post<T>(url: string, body: unknown): Promise<T> {
    const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(body),
    });
    if (!res.ok) throw new Error(`[API] ${res.status} ${url}`);
    return res.json() as Promise<T>;
}

function toQuery(params: Record<string, string | number | boolean | string[] | undefined>): string {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) {
        if (v === undefined || v === null || v === '') continue;
        if (Array.isArray(v)) v.forEach(i => p.append(k, i));
        else p.set(k, String(v));
    }
    const s = p.toString();
    return s ? `?${s}` : '';
}

// ── Existing endpoints ─────────────────────────────────────────────────────

export function fetchReportTypes(): Promise<ReportTypeOption[]> {
    return get<ReportTypeOption[]>(`${BASE}/reports/reporttypes`);
}

export function fetchFilterCounts(
    reportId: number,
    activeFilters: FilterKey[],
): Promise<ShareholderFilterCounts> {
    const noFilter = activeFilters.length === 0;
    const q = toQuery({
        directCount:    noFilter || activeFilters.includes('directly'),
        nomineeCount:   noFilter || activeFilters.includes('nominee'),
        companyCount:   noFilter || activeFilters.includes('companies'),
        financialCount: noFilter || activeFilters.includes('financial'),
        householdCount: noFilter || activeFilters.includes('households'),
    });
    return get<ShareholderFilterCounts>(`${BASE}/reports/shareholder/${reportId}/filters${q}`);
}

export function fetchSecuritiesByIssuer(issuerId: number): Promise<Security[]> {
    return get<Security[]>(`${BASE}/data/securities/issuer/${issuerId}`);
}

export function fetchSecurity(securityId: number): Promise<Security> {
    return get<Security>(`${BASE}/data/security/${securityId}`);
}

export function fetchReportPricing(reportOrderId: number): Promise<ReportPricing> {
    return get<ReportPricing>(`${BASE}/reports/pricing/${reportOrderId}`);
}

export function orderReport(req: ReportOrderRequest): Promise<void> {
    return post<void>(`${BASE}/reports/order/`, req);
}

// ── Missing endpoints — with mock fallback ─────────────────────────────────

export async function fetchReportMetadata(reportId: number): Promise<ReportMetadata> {
    return get<ReportMetadata>(`${BASE}/reports/shareholder/${reportId}/metadata`);
}

export async function fetchSummaryRows(reportId: number): Promise<SummaryRow[]> {
    return get<SummaryRow[]>(`${BASE}/reports/shareholder/${reportId}/summary`);
}

export async function fetchOwners(
    reportId: number,
    params: { page: number; pageSize: number; search?: string; activeFilters: FilterKey[] },
): Promise<OwnersResponse> {
    const noFilter = params.activeFilters.length === 0;
    const q = toQuery({
        page:            params.page,
        pageSize:        params.pageSize,
        search:          params.search,
        directFilter:    noFilter || params.activeFilters.includes('directly'),
        nomineeFilter:   noFilter || params.activeFilters.includes('nominee'),
        companyFilter:   noFilter || params.activeFilters.includes('companies'),
        financialFilter: noFilter || params.activeFilters.includes('financial'),
        householdFilter: noFilter || params.activeFilters.includes('households'),
    });
    return get<OwnersResponse>(`${BASE}/reports/shareholder/${reportId}/owners${q}`);
}
