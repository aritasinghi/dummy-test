import { Button } from '@efi/efi-ui-components';
import './Card.css';

interface DataRow { name: string; percentage: number }

interface CardProps {
    title: string;
    badge?: string;
    data: DataRow[];
    lastReportDate: string;
    subscribedCount: number;
    showLatestLabel: string;
    showAllLabel: string;
    subscribeLabel: string;
}

export function Card({ title, badge, data, lastReportDate, subscribedCount, showLatestLabel, showAllLabel, subscribeLabel }: CardProps) {
    return (
        <div className="ois-card">
            <div className="ois-card__header">
                <h3 className="ois-card__title">{title}</h3>
                {badge && <span className="ois-card__badge">{badge}</span>}
            </div>
            <div className="ois-card__data-wrap">
                <div className="ois-card__data-table">
                    <div className="ois-card__data-header"><span /><span className="ois-card__data-pct">%</span></div>
                    {data.map((row) => (
                        <div key={row.name} className="ois-card__data-row">
                            <span>{row.name}</span>
                            <span className="ois-card__data-value">{row.percentage.toFixed(2)}</span>
                        </div>
                    ))}
                </div>
                <div className="ois-card__data-fade" />
            </div>
            <a className="ois-card__link" href="#">{showLatestLabel}: {lastReportDate}</a>
            <div className="ois-card__actions">
                <Button variant="secondary" size="medium">{showAllLabel} ({subscribedCount})</Button>
                <Button variant="primary" size="medium">+ {subscribeLabel}</Button>
            </div>
        </div>
    );
}
