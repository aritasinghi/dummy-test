import { Button } from '@efi/efi-ui-components';
import './AvailableReportCard.css';

interface AvailableReportCardProps {
    title: string;
    description?: string;
    previewLabel: string;
    subscribeLabel: string;
}

export function AvailableReportCard({ title, description, previewLabel, subscribeLabel }: AvailableReportCardProps) {
    return (
        <div className="ois-avail-card">
            <div className="ois-avail-card__header">
                <span className="ois-avail-card__plus">+</span>
                <h3 className="ois-avail-card__title">{title}</h3>
            </div>
            {description && (
                <p className="ois-avail-card__desc">
                    {description.length > 120 ? description.slice(0, 120) + '...' : description}
                    {description.length > 120 && <button className="ois-avail-card__read-more" type="button">Lue lisää</button>}
                </p>
            )}
            <div className="ois-avail-card__actions">
                <Button variant="secondary" size="medium">{previewLabel}</Button>
                <Button variant="primary" size="medium">{subscribeLabel}</Button>
            </div>
        </div>
    );
}
