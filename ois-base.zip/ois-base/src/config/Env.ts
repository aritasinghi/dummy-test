export default class Env {
    static get appConfig(): AppConfig {
        if (!window.appConfig) {
            const request = new XMLHttpRequest();
            request.open('GET', `${window.location.origin}/config/env.json`, false);
            request.send(null);
            if (request.status === 200) {
                window.appConfig = JSON.parse(request.response);
            }
        }
        return window.appConfig;
    }

    public static get API_SERVER_URL() { return Env.appConfig.API_SERVER_URL; }
}
