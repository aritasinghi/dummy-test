interface AppConfig {
    API_SERVER_URL: string;
}

interface Window {
    appConfig: AppConfig;
}
