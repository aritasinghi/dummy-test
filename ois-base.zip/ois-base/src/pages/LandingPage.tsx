import { useState } from 'react';
import {
    Banner, Container, Header, Main,
    ProfileMenu, LanguageSelector,
} from '@efi/efi-ui-components';
import { translations } from '@/locales';
import type { Language } from '@/locales';
import ReportsPage from './ReportsPage';

export default function LandingPage() {
    const [language, setLanguage] = useState<Language>("fi");
    const [activeTab, setActiveTab] = useState<string>("reports");
    const t = translations[language];

    const tabs = [
        { label: t.tabs.reports, path: "reports" },
        { label: t.tabs.log, path: "log" },
        { label: t.tabs.organization, path: "organization" },
    ];

    const renderTabContent = () => {
        switch (activeTab) {
            case 'reports': return <ReportsPage language={language} />;
            case 'log': return <p style={{ padding: '2rem', color: '#999' }}>Event log — coming soon</p>;
            case 'organization': return <p style={{ padding: '2rem', color: '#999' }}>Organisation info — coming soon</p>;
            default: return null;
        }
    };

    return (
        <>
            <Header
                skipToContentLabel={t.header.skipToContent}
                drawerProps={{ buttonOpen: t.header.openMenu, buttonClose: t.header.closeMenu }}
            >
                <Header.AppName>{t.header.appName}</Header.AppName>
                <Header.SecondaryTitle>{t.header.orgLabel}</Header.SecondaryTitle>

                <Header.Actions>
                    <ProfileMenu aria-label={t.profileMenu.yourProfile}>
                        <ProfileMenu.Title>Justin Time</ProfileMenu.Title>
                        <ProfileMenu.InfoItem label={t.profileMenu.companyLabel}>
                            Wishing Well Investments
                        </ProfileMenu.InfoItem>
                        <ProfileMenu.InfoItem label={t.profileMenu.departmentLabel}>
                            Marketing and communications
                        </ProfileMenu.InfoItem>
                        <LanguageSelector
                            label={t.profileMenu.selectLanguage}
                            defaultSelected={language}
                            onSelect={(_e: unknown, value?: string) => {
                                if (value) setLanguage(value as Language);
                            }}
                        >
                            <LanguageSelector.Option value="en" lang="en-GB">English</LanguageSelector.Option>
                            <LanguageSelector.Option value="sv" lang="sv-SE">Svenska</LanguageSelector.Option>
                            <LanguageSelector.Option value="fi" lang="fi-FI">Suomi</LanguageSelector.Option>
                        </LanguageSelector>
                        <ProfileMenu.Item value="dashboard">{t.profileMenu.dashboard}</ProfileMenu.Item>
                        <ProfileMenu.Item value="profile">{t.profileMenu.profile}</ProfileMenu.Item>
                        <ProfileMenu.Item value="disabled" disabled>{t.profileMenu.notAvailable}</ProfileMenu.Item>
                        <ProfileMenu.Item value="logout">{t.profileMenu.logout}</ProfileMenu.Item>
                    </ProfileMenu>
                </Header.Actions>

                <Header.Navigation aria-label="Main navigation">
                    {tabs.map(({ label, path }) => (
                        <Header.NavigationItem
                            key={path}
                            href={`/${path}`}
                            active={activeTab === path}
                            onClick={(e: React.MouseEvent) => { e.preventDefault(); setActiveTab(path); }}
                        >
                            {label}
                        </Header.NavigationItem>
                    ))}
                </Header.Navigation>
            </Header>

            <Main>
                <Banner appName="MyEuroclear">
                    <Banner.Title>{t.tabs[activeTab as keyof typeof t.tabs]}</Banner.Title>
                </Banner>
                <Container>
                    {renderTabContent()}
                </Container>
            </Main>
        </>
    );
}
