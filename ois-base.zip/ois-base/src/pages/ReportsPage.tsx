import { Card } from '@/components/Card';
import { AvailableReportCard } from '@/components/AvailableReportCard';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import './ReportsPage.css';

interface ReportsPageProps { language: Language }

const SUBSCRIBED = [
    { id: '1', title: 'Liikkeeseenlaskijan osakasluettelo', badge: 'UUSI', data: [{ name: 'Tulip Bank', percentage: 10 }, { name: 'Flexis Bank', percentage: 9 }, { name: 'S. Sunflower', percentage: 8 }, { name: 'C. Coriander', percentage: 7 }, { name: 'H. Hazel', percentage: 6 }, { name: 'T. Tulip', percentage: 5 }], lastDate: '24.01.2026', count: 3 },
    { id: '2', title: 'Julkinen osakasluettelo', data: [{ name: 'Tulip Bank', percentage: 10 }, { name: 'Flexis Bank', percentage: 9 }, { name: 'S. Sunflower', percentage: 8 }, { name: 'C. Coriander', percentage: 7 }, { name: 'H. Hazel', percentage: 6 }, { name: 'T. Tulip', percentage: 5 }], lastDate: '01.01.2026', count: 2 },
    { id: '3', title: 'Kattava omistajapoiminta', data: [{ name: 'Tulip Bank', percentage: 10 }, { name: 'Flexis Bank', percentage: 9 }, { name: 'S. Sunflower', percentage: 8 }, { name: 'C. Coriander', percentage: 7 }, { name: 'H. Hazel', percentage: 6 }, { name: 'T. Tulip', percentage: 5 }], lastDate: '24.11.2025', count: 4 },
];

const AVAILABLE = [
    { id: '4', title: 'Suurimmat omistajat', desc: 'Raportti perustuu osakasluetteloon, mutta sisältää vain arvo-osuuksien suurimmat omistajat. Suurten omistajien lukumäärä on valittavissa tilauksen yhteydessä.' },
    { id: '5', title: 'Sektorijakauma', desc: 'Raportti perustuu Tilastokeskuksen sektoriluokitukseen ja kuvaa omistajien ja hallintarekisteröityjen säilyttäjien sektorijakaumaa.' },
    { id: '6', title: 'Omistusmääräjakauma', desc: 'Raportissa kuvataan omistusten jakauma osakkeenomistajien omistusten perusteella.' },
    { id: '7', title: 'Tilapäinen osakasluettelo', desc: 'Raportti sisältää liikkeeseenlaskijan osakasluetteloon merkityt suoraan rekisteröidyt omistajat yhtiökokouksen täsmäytyspäivältä.' },
];

export default function ReportsPage({ language }: ReportsPageProps) {
    const t = translations[language].reports;
    return (
        <div className="reports-page">
            <section className="reports-page__section">
                <h3 className="reports-page__section-title">{t.subscribedTitle}</h3>
                <div className="reports-page__grid">
                    {SUBSCRIBED.map((r) => (
                        <Card key={r.id} title={r.title} badge={r.badge} data={r.data} lastReportDate={r.lastDate} subscribedCount={r.count} showLatestLabel={t.showLatestReport} showAllLabel={t.showAllSubscribed} subscribeLabel={t.subscribeNew} />
                    ))}
                </div>
            </section>
            <section className="reports-page__section">
                <h3 className="reports-page__section-title">{t.availableTitle}</h3>
                <div className="reports-page__grid">
                    {AVAILABLE.map((r) => (
                        <AvailableReportCard key={r.id} title={r.title} description={r.desc} previewLabel={t.showPreview} subscribeLabel={t.subscribe} />
                    ))}
                </div>
            </section>
        </div>
    );
}
