import type { ReactNode } from 'react';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from '@/api/queryClient';
import { ThemeProvider } from '@efi/efi-ui-components';
import type { Theme } from '@efi/efi-ui-components';

interface AppProvidersProps {
    theme?: Theme;
    children: ReactNode;
}

export function AppProviders({ theme = 'light', children }: AppProvidersProps) {
    return (
        <QueryClientProvider client={queryClient}>
            <ThemeProvider theme={theme}>
                {children}
            </ThemeProvider>
        </QueryClientProvider>
    );
}
