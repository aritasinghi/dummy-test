export type Language = 'en' | 'sv' | 'fi';

export interface Translations {
    tabs: { reports: string; log: string; organization: string };
    header: { appName: string; orgLabel: string; skipToContent: string; openMenu: string; closeMenu: string };
    profileMenu: { yourProfile: string; companyLabel: string; departmentLabel: string; dashboard: string; profile: string; notAvailable: string; logout: string; selectLanguage: string };
    reports: { subscribedTitle: string; availableTitle: string; showLatestReport: string; showAllSubscribed: string; subscribeNew: string; showPreview: string; subscribe: string };
}

const en: Translations = {
    tabs: { reports: "Reports", log: "Event Log", organization: "Organization Info" },
    header: { appName: "Information Elements by Euroclear", orgLabel: "Organisation: Euroflex", skipToContent: "Skip to main content", openMenu: "Open menu", closeMenu: "Close menu" },
    profileMenu: { yourProfile: "Your profile", companyLabel: "Company", departmentLabel: "Department", dashboard: "Dashboard", profile: "Profile", notAvailable: "Not available", logout: "Logout", selectLanguage: "Select language" },
    reports: { subscribedTitle: "Subscribed report types", availableTitle: "Other available report types", showLatestReport: "Show latest report", showAllSubscribed: "SHOW ALL SUBSCRIBED REPORTS", subscribeNew: "SUBSCRIBE NEW REPORT", showPreview: "SHOW PREVIEW", subscribe: "SUBSCRIBE REPORT" },
};

const sv: Translations = {
    tabs: { reports: "Rapporter", log: "Händelselogg", organization: "Organisationsinfo" },
    header: { appName: "Information Elements by Euroclear", orgLabel: "Organisation: Euroflex", skipToContent: "Hoppa till huvudinnehåll", openMenu: "Öppna meny", closeMenu: "Stäng meny" },
    profileMenu: { yourProfile: "Din profil", companyLabel: "Företag", departmentLabel: "Avdelning", dashboard: "Instrumentpanel", profile: "Profil", notAvailable: "Inte tillgänglig", logout: "Logga ut", selectLanguage: "Välj språk" },
    reports: { subscribedTitle: "Prenumererade rapporttyper", availableTitle: "Andra tillgängliga rapporttyper", showLatestReport: "Visa senaste rapporten", showAllSubscribed: "VISA ALLA PRENUMERERADE RAPPORTER", subscribeNew: "PRENUMERERA NY RAPPORT", showPreview: "VISA FÖRHANDSGRANSKNING", subscribe: "PRENUMERERA RAPPORT" },
};

const fi: Translations = {
    tabs: { reports: "Raportit", log: "Tapahtumaloki", organization: "Organisaation tiedot" },
    header: { appName: "Information Elements by Euroclear", orgLabel: "Organisaatio: Euroflex", skipToContent: "Siirry pääsisältöön", openMenu: "Avaa valikko", closeMenu: "Sulje valikko" },
    profileMenu: { yourProfile: "Profiilisi", companyLabel: "Yritys", departmentLabel: "Osasto", dashboard: "Kojelauta", profile: "Profiili", notAvailable: "Ei saatavilla", logout: "Kirjaudu ulos", selectLanguage: "Valitse kieli" },
    reports: { subscribedTitle: "Tilatut raportityypit", availableTitle: "Muut saatavilla olevat raportityypit", showLatestReport: "Näytä viimeisin raportti", showAllSubscribed: "NÄYTÄ KAIKKI TILATUT RAPORTIT", subscribeNew: "TILAA UUSI RAPORTTI", showPreview: "NÄYTÄ ESIKATSELU", subscribe: "TILAA RAPORTTI" },
};

export const translations: Record<Language, Translations> = { en, sv, fi };
