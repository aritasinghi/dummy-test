export { translations } from './translations';
export type { Language, Translations } from './translations';
