import { useState } from 'react';
import {
    Banner,
    Button,
    Container,
    Chip,
    Table,
    TextLink,
    Pagination,
} from '@efi/efi-ui-components';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import './ReportView.css';

// ─── Types ───────────────────────────────────────────────────────────────────

interface ReportViewProps {
    reportTitle: string;
    reportDate: string;
    language: Language;
    onBack: () => void;
    onSubscribe: () => void;
    onDownload?: () => void;
}

type ReportType = 'full' | 'agm' | 'statutory' | 'short';
type OwnerFlag = 'restricted' | 'joint' | 'nominee' | 'bank';

interface ShareRow {
    type: string;
    custodian?: string;
    amount: string;
    pct: string;
    votes: string;
    votePct: string;
    bold?: boolean;
    isTotal?: boolean;
}

interface OwnerRow {
    id: number;
    name: string;
    ssn: string;
    dob: string;
    asiakasrajoitus?: string;
    flags: OwnerFlag[];
    isCompany?: boolean;
    isBank?: boolean;
    city?: string;
    address: string;
    postAddress: string;
    country: string;
    shares: ShareRow[];
    sektori: string;
    maksu: string;
    vero: string;
    situationDate?: string;
    jointOwners?: { name: string; linkable?: boolean }[];
    isJointSubRow?: boolean;
    jointParent?: string;
}

// ─── Column config per report type ───────────────────────────────────────────

const COLUMN_CONFIG: Record<ReportType, {
    showAddress: boolean; showCity: boolean; showCustodian: boolean;
    showPct: boolean; showVotes: boolean; showVotePct: boolean;
    showSector: boolean; showPayment: boolean; showTax: boolean;
    showDate: boolean;
}> = {
    full:      { showAddress: true,  showCity: false, showCustodian: true,  showPct: true,  showVotes: true,  showVotePct: true,  showSector: true,  showPayment: true,  showTax: true,  showDate: false },
    agm:       { showAddress: false, showCity: true,  showCustodian: false, showPct: false, showVotes: false, showVotePct: false, showSector: false, showPayment: false, showTax: false, showDate: false },
    statutory: { showAddress: true,  showCity: false, showCustodian: true,  showPct: false, showVotes: false, showVotePct: false, showSector: false, showPayment: true,  showTax: true,  showDate: true  },
    short:     { showAddress: false, showCity: false, showCustodian: true,  showPct: true,  showVotes: false, showVotePct: false, showSector: false, showPayment: false, showTax: false, showDate: false },
};

// ─── Sidebar descriptions ─────────────────────────────────────────────────────

const SIDEBAR_DESC: Record<ReportType, string> = {
    full:      'You can choose the report type you want from four options:\nFull: As the name suggests, includes the complete content of the report with additional details.\nGeneral Meeting: The shareholder register available at the General Meeting.\nIssuer\'s Shareholder List: Includes the information required under the Finnish Limited Liability Companies Act.\nShort: The report includes ...',
    agm:       'General Meeting: The shareholder register available at the General Meeting. Includes only the information required under the Finnish Limited Liability Companies Act.',
    statutory: "Issuer's Shareholder List: Includes the information required under the Finnish Limited Liability Companies Act.",
    short:     'Short: The report includes the names of shareholders or nominee registration custodians, the number of book-entries per book-entry type ...',
};

// ─── Mock Data ────────────────────────────────────────────────────────────────

const SHARES_INFO = [
    { name: 'EUROFLEX A', isin: 'FI21049685930', abbr: 'EUROFLA' },
    { name: 'EUROFLEX B', isin: 'FI21049685931', abbr: 'EUROFLB' },
    { name: 'EUROFLEX C', isin: 'FI21049685932', abbr: 'EUROFLC' },
];

const SUMMARY_ROWS = [
    { aoLaji: 'EUROFLA', omistajien: '1 300', yhteis: '12', kaikkien: '1 006 970', osuus: '50,3 %', kokonaisAani: '2 000 000', osakas: '503 488', odotus: '5 000', hallinta: '10 000', yhteistili: '481 512', liikkeeseen: '1 000 000', bold: false },
    { aoLaji: 'EUROFLB', omistajien: '600',   yhteis: '24', kaikkien: '285 369',   osuus: '71,3 %', kokonaisAani: '400 000',   osakas: '285 369', odotus: '4 800', hallinta: '18 995', yhteistili: '90 836',  liikkeeseen: '400 000',   bold: false },
    { aoLaji: 'Yhteensä',omistajien: '1 900', yhteis: '36', kaikkien: '1 292 339', osuus: '53,8 %', kokonaisAani: '2 400 000', osakas: '788 857', odotus: '9 800', hallinta: '28 995', yhteistili: '572 348', liikkeeseen: '1 400 000', bold: true  },
];

const SHOW_DATA_OPTIONS = [
    { key: 'address',   label: 'Address information subject to non-disclosure' },
    { key: 'isin',      label: 'Identification code' },
    { key: 'id',        label: 'Discontinued book-entry types' },
    { key: 'sector',    label: 'Sector information' },
    { key: 'custodian', label: 'Depository participant' },
];

const INITIAL_CHIPS = [
    { label: 'Directly-registered holdings', count: 2379, active: true },
    { label: 'Nominee-registered holdings',  count: 12,   active: false },
    { label: 'Companies',                    count: 1112, active: true },
    { label: 'Financial and insurance institutions', count: 23, active: false },
    { label: 'Households',                   count: 1856, active: true },
];

const OWNER_ROWS: OwnerRow[] = [
    {
        id: 1, name: 'Thomas-Peter Along-lastname', ssn: '120370-8902A', dob: '12.03.1970',
        flags: [], city: 'Espoo', address: 'Arvo-osuuskuja 212', postAddress: '00550 Espoo', country: 'Espoo, Finland',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',    amount: '30 300', pct: '3,03000', votes: '60 900', votePct: '2,54000' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '600',   pct: '0,15000', votes: '',       votePct: '' },
            { type: 'Arvo-osuudet yhteensä', amount: '30 900', pct: '2,21000', votes: '60 900', votePct: '2,54000', bold: true, isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 2, name: 'Clarck Confidential', ssn: '020377-02908', dob: '02.03.1977',
        flags: ['restricted'], city: '', address: 'Yhteyssoite: Jokitie 22 b', postAddress: '00100 Helsinki', country: 'Tai Ei osoitetta',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',    amount: '15',  pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX A', custodian: 'Nordea', amount: '15', pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX B', custodian: 'OP',    amount: '40',  pct: '0,00004', votes: '100', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', amount: '70', pct: '0,00003', votes: '100', votePct: '0,00003', bold: true, isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 3, name: 'D-Yritys OY Ab', ssn: 'T769765-S', dob: '', asiakasrajoitus: 'konkurssi',
        flags: [], isCompany: true, city: 'Helsinki', address: 'Arvopaperie 12', postAddress: '00100 Helsinki', country: 'Helsinki, Finland',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',    amount: '30', pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '40', pct: '0,00004', votes: '100', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', amount: '70', pct: '0,00003', votes: '100', votePct: '0,00003', bold: true, isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 4, name: 'Thomas Elling', ssn: '200274-89020', dob: '20.02.1974', asiakasrajoitus: 'kuolinpesä',
        flags: ['joint'], city: 'Helsinki', address: 'Thomaksentie 12', postAddress: '00100 Helsinki', country: 'Helsinki / Finland',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',    amount: '30', pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '40', pct: '0,00004', votes: '603', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', amount: '70', pct: '0,00003', votes: '603', votePct: '0,00003', bold: true, isTotal: true },
        ],
        jointOwners: [{ name: 'Tiina Ollila' }, { name: 'Veijo Välisää', linkable: true }],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 5, name: 'William Elling', ssn: '180372-89020', dob: '18.03.1972',
        flags: [], city: 'Helsinki', address: 'Viljaminkuja 22 b 33', postAddress: '00100 Helsinki', country: 'Helsinki, Finland',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',    amount: '30', pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '40', pct: '0,00004', votes: '603', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', amount: '70', pct: '0,00003', votes: '603', votePct: '0,00003', bold: true, isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 6, name: 'Elli Ollinen', ssn: '120378-1902B', dob: '12.03.1978',
        flags: ['joint'], isJointSubRow: true, jointParent: 'Thomas Elling',
        city: 'Helsinki', address: 'Elisenkuja 6 B', postAddress: '00100 Helsinki', country: 'Helsinki/Finland',
        shares: [], sektori: '', maksu: '', vero: '',
    },
    {
        id: 7, name: 'Sakari Penttinen', ssn: '220368-3456A', dob: '23.03.1968',
        flags: [], city: 'Helsinki', address: 'Sakarianpolku 1 C', postAddress: '00100 Helsinki', country: 'Helsinki, Finland',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP', amount: '30', pct: '0,00005', votes: '3', votePct: '0,00005' },
            { type: 'Arvo-osuudet yhteensä', amount: '30', pct: '0,00005', votes: '3', votePct: '0,00005', bold: true, isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 8, name: 'SEC Custody Bank', ssn: '1169765-6', dob: '',
        flags: ['nominee'], isBank: true, city: 'Helsinki',
        address: 'Pankkiirinkatu 32', postAddress: '00100 Helsinki', country: 'Helsinki / Finland',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',    amount: '120', pct: '0,00010', votes: '70', votePct: '0,00010' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '60',  pct: '0,00010', votes: '',   votePct: '' },
            { type: 'Arvo-osuudet yhteensä', amount: '180', pct: '0,00008', votes: '70', votePct: '0,00010', bold: true, isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
];

// ─── Sub-components ───────────────────────────────────────────────────────────

function FlagIcon({ type }: { type: OwnerFlag }) {
    const icons: Record<OwnerFlag, { symbol: string; title: string }> = {
        restricted: { symbol: '🚫', title: 'Non-disclosure' },
        joint:      { symbol: '🔗', title: 'Joint ownership' },
        nominee:    { symbol: '📋', title: 'Nominee-registered holding' },
        bank:       { symbol: '🏦', title: 'Nominee Registration Custodian' },
    };
    return <span className="rv-flag" title={icons[type].title}>{icons[type].symbol}</span>;
}

function JointSection({ owners }: { owners: { name: string; linkable?: boolean }[] }) {
    return (
        <div className="rv__joint-section">
            <span>🔗</span>
            <span className="rv__joint-label">Yhteisomistus:</span>
            <div className="rv__joint-names">
                {owners.map((o, i) => (
                    <span key={i}>
                        {o.linkable ? <TextLink href="#">{o.name}</TextLink> : <span>{o.name}</span>}
                        {i < owners.length - 1 && ', '}
                    </span>
                ))}
            </div>
            <button type="button" className="rv__joint-toggle">Vai avattava? ›</button>
        </div>
    );
}

function OwnerTableRow({ row, cols }: { row: OwnerRow; cols: typeof COLUMN_CONFIG[ReportType] }) {
    if (row.isJointSubRow) {
        return (
            <Table.Row>
                <Table.BodyCell>
                    <div className="rv__name-cell">
                        <div className="rv__name-row"><span>🔗</span><span className="rv__sub-label">Mukana yhteisomistuksessa</span></div>
                        <div className="rv__joint-parent">Oikeudenhaltija: <TextLink href="#">{row.jointParent}</TextLink></div>
                        <span className="rv__ssn-text">{row.ssn}</span>
                        {row.dob && <Table.SecondaryText>{row.dob}</Table.SecondaryText>}
                    </div>
                </Table.BodyCell>
                {cols.showAddress && <Table.BodyCell><span className="rv__cell-sm">{row.address}<br />{row.postAddress}<br />{row.country}</span></Table.BodyCell>}
                {cols.showCity && <Table.BodyCell><span className="rv__cell-sm">{row.city}</span></Table.BodyCell>}
                <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>
                {cols.showCustodian && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>
                {cols.showPct && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.showVotes && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.showVotePct && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.showDate && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.showSector && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.showPayment && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.showTax && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
            </Table.Row>
        );
    }

    return (
        <Table.Row>
            <Table.BodyCell>
                <div className="rv__name-cell">
                    <div className="rv__name-row">
                        {row.isBank && <span title="Bank">🏦</span>}
                        {row.isCompany && !row.isBank && <span title="Company">🏢</span>}
                        <TextLink href="#"><strong>{row.name}</strong></TextLink>
                        {row.flags.filter(f => f !== 'joint').map(f => <FlagIcon key={f} type={f} />)}
                    </div>
                    <span className="rv__ssn-text">{row.ssn}</span>
                    {row.dob && <Table.SecondaryText>{row.dob}</Table.SecondaryText>}
                    {row.asiakasrajoitus && <span className="rv__restriction">Customer restriction: {row.asiakasrajoitus}</span>}
                    {row.jointOwners && <JointSection owners={row.jointOwners} />}
                </div>
            </Table.BodyCell>
            {cols.showAddress && (
                <Table.BodyCell><span className="rv__cell-sm">{row.address}<br />{row.postAddress}<br />{row.country}</span></Table.BodyCell>
            )}
            {cols.showCity && <Table.BodyCell><span className="rv__cell-sm">{row.city}</span></Table.BodyCell>}
            <Table.BodyCell>
                {row.shares.map((s, i) => (
                    <div key={i} className={s.isTotal ? 'rv__cell-total' : 'rv__cell-sm'}>{s.type}</div>
                ))}
            </Table.BodyCell>
            {cols.showCustodian && (
                <Table.BodyCell>
                    {row.shares.map((s, i) => (
                        <div key={i} className="rv__cell-sm">{s.bold ? '' : (s.custodian || '')}</div>
                    ))}
                </Table.BodyCell>
            )}
            <Table.BodyCell align="middle-right">
                {row.shares.map((s, i) => (
                    <div key={i} className={s.isTotal ? 'rv__cell-total' : `rv__cell-sm${s.bold ? ' rv__cell-bold' : ''}`}>{s.amount}</div>
                ))}
            </Table.BodyCell>
            {cols.showPct && (
                <Table.BodyCell align="middle-right">
                    {row.shares.map((s, i) => <div key={i} className="rv__cell-sm">{s.pct}</div>)}
                </Table.BodyCell>
            )}
            {cols.showVotes && (
                <Table.BodyCell align="middle-right">
                    {row.shares.map((s, i) => <div key={i} className={`rv__cell-sm${s.bold ? ' rv__cell-bold' : ''}`}>{s.votes || ''}</div>)}
                </Table.BodyCell>
            )}
            {cols.showVotePct && (
                <Table.BodyCell align="middle-right">
                    {row.shares.map((s, i) => <div key={i} className="rv__cell-sm">{s.votePct || ''}</div>)}
                </Table.BodyCell>
            )}
            {cols.showDate && <Table.BodyCell><span className="rv__cell-sm">{row.situationDate}</span></Table.BodyCell>}
            {cols.showSector && <Table.BodyCell><span className="rv__cell-sm">{row.sektori}</span></Table.BodyCell>}
            {cols.showPayment && <Table.BodyCell><span className="rv__cell-sm">{row.maksu}</span></Table.BodyCell>}
            {cols.showTax && <Table.BodyCell><span className="rv__cell-sm">{row.vero}</span></Table.BodyCell>}
        </Table.Row>
    );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function ReportView({ reportTitle, reportDate, language, onBack, onSubscribe, onDownload }: ReportViewProps) {
    const t = translations[language].reportView;

    const [activeTab, setActiveTab] = useState<'report' | 'subscription'>('report');
    const [reportType, setReportType] = useState<ReportType>('full');
    const [showData, setShowData] = useState<Record<string, boolean>>(
        Object.fromEntries(SHOW_DATA_OPTIONS.map(o => [o.key, true]))
    );
    const [chips, setChips] = useState(INITIAL_CHIPS);
    const [search, setSearch] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const totalPages = 14;

    const cols = COLUMN_CONFIG[reportType];

    const toggleChip = (label: string) =>
        setChips(prev => prev.map(c => c.label === label ? { ...c, active: !c.active } : c));

    const reportTypeOptions = [
        { key: 'full' as ReportType,      title: 'Full',                        desc: 'All available information' },
        { key: 'agm' as ReportType,       title: 'General meeting',             desc: 'Shareholder register for the general meeting' },
        { key: 'statutory' as ReportType, title: "Issuer's shareholder list",   desc: 'Statutory information' },
        { key: 'short' as ReportType,     title: 'Short',                       desc: 'Names of shareholders and number of shares' },
    ];

    const filteredRows = OWNER_ROWS.filter(row =>
        !search || row.name.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <>
            {/* ── Banner with efi Banner.Tabs + Banner.Actions ── */}
            <Banner appName="MyEuroclear" sticky={true}>
                <Banner.Title>{reportDate} {reportTitle}</Banner.Title>
                <Banner.Actions>
                    <button type="button" className="rv__download-btn" onClick={onDownload}>
                        {/* ico_download — 24x24 from efi icon library */}
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 3v12m0 0l-4-4m4 4l4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                            <path d="M20 16v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                            <path d="M7 10.5C5.5 10.5 3 11.5 3 14.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                            <path d="M17 10.5C18.5 10.5 21 11.5 21 14.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                        {t.downloadFile}
                        {/* ico_sm_dropdown chevron */}
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                    </button>
                </Banner.Actions>
                <Banner.Tabs
                    value={activeTab}
                    onValueChange={(val: string) => setActiveTab(val as 'report' | 'subscription')}
                >
                    <Banner.Tab value="report">{t.tabReport}</Banner.Tab>
                    <Banner.Tab value="subscription">{t.tabSubscriptionInfo}</Banner.Tab>
                </Banner.Tabs>
            </Banner>

            <Container>
                <div className="rv">

                    {activeTab === 'report' && (
                        <>
                            {/* ── Summary Card ── */}
                            <section className="rv__summary-card">
                                <h2 className="rv__section-title">{t.summaryTitle}</h2>
                                <div className="rv__info-row">
                                    <div className="rv__info-block">
                                        <h4 className="rv__info-heading">{t.infoTitle}</h4>
                                        <p className="rv__info-line">{t.issuer}: <strong>Euroflex Oyj</strong></p>
                                        <p className="rv__info-line">{t.reportName}: <strong>Liikkeeseenlaskijan omistusraportti</strong></p>
                                        <p className="rv__info-line">{t.situationDate}: <strong>13.3.2026</strong></p>
                                    </div>
                                    <div className="rv__shares-block">
                                        <h4 className="rv__info-heading">Arvo-osuudet</h4>
                                        <div className="rv__shares-grid">
                                            {SHARES_INFO.map(s => (
                                                <div key={s.isin} className="rv__share-col">
                                                    <p className="rv__info-line">{t.shareNameLabel}: <strong>{s.name}</strong></p>
                                                    <p className="rv__info-line">{t.isinLabel}: <strong>{s.isin}</strong></p>
                                                    <p className="rv__info-line">{t.abbreviationLabel}: <strong>{s.abbr}</strong></p>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                <h3 className="rv__sub-title">Yhteenveto</h3>
                                <div className="rv__summary-table-wrap">
                                    <Table layout="fixed" hover striped>
                                        <Table.Head>
                                            <Table.Row>
                                                <Table.HeadCell column="ao" sortable style={{ width: '7%' }}>BOOK-ENTRY TYPE</Table.HeadCell>
                                                <Table.HeadCell column="om" style={{ width: '9%' }}>NUMBER OF OWNERS AND NOMINEE-REGISTRATION CUSTODIANS</Table.HeadCell>
                                                <Table.HeadCell column="yh" style={{ width: '7%' }}>NUMBER OF JOINT OWNERS</Table.HeadCell>
                                                <Table.HeadCell column="kk" style={{ width: '10%' }}>NUMBER OF VOTES CONFERRED BY ALL THE BOOK-ENTRIES IN BOOK-ENTRY ACCOUNTS</Table.HeadCell>
                                                <Table.HeadCell column="os" style={{ width: '11%' }}>PERCENTAGE OF VOTES CONFERRED BY ALL THE BOOK-ENTRIES IN BOOK-ENTRY ACCOUNTS</Table.HeadCell>
                                                <Table.HeadCell column="ka" style={{ width: '9%' }}>TOTAL NUMBER OF VOTES</Table.HeadCell>
                                                <Table.HeadCell column="ol" style={{ width: '9%' }}>IN THE SHAREHOLDER LIST</Table.HeadCell>
                                                <Table.HeadCell column="od" style={{ width: '7%' }}>IN THE WAITING LIST</Table.HeadCell>
                                                <Table.HeadCell column="hr" style={{ width: '8%' }}>NOMINEE-REGISTERED</Table.HeadCell>
                                                <Table.HeadCell column="yt" style={{ width: '8%' }}>IN THE JOINT ACCOUNT</Table.HeadCell>
                                                <Table.HeadCell column="lm" style={{ width: '10%' }}>ISSUED AMOUNT</Table.HeadCell>
                                            </Table.Row>
                                        </Table.Head>
                                        <Table.Body>
                                            {SUMMARY_ROWS.map(row => (
                                                <Table.Row key={row.aoLaji}>
                                                    <Table.BodyCell>{row.bold ? <strong>{row.aoLaji}</strong> : row.aoLaji}</Table.BodyCell>
                                                    <Table.BodyCell>{row.omistajien}</Table.BodyCell>
                                                    <Table.BodyCell>{row.yhteis}</Table.BodyCell>
                                                    <Table.BodyCell>{row.kaikkien}</Table.BodyCell>
                                                    <Table.BodyCell>{row.osuus}</Table.BodyCell>
                                                    <Table.BodyCell>{row.kokonaisAani}</Table.BodyCell>
                                                    <Table.BodyCell>{row.osakas}</Table.BodyCell>
                                                    <Table.BodyCell>{row.odotus}</Table.BodyCell>
                                                    <Table.BodyCell>{row.hallinta}</Table.BodyCell>
                                                    <Table.BodyCell>{row.yhteistili}</Table.BodyCell>
                                                    <Table.BodyCell>{row.liikkeeseen}</Table.BodyCell>
                                                </Table.Row>
                                            ))}
                                        </Table.Body>
                                    </Table>
                                </div>
                            </section>

                            {/* ════════════════════════════════════════
                                FILTERS + SIDEBAR — aligned grid
                            ════════════════════════════════════════ */}
                            <div className="rv__content-layout">
                                {/* LEFT — filter sections */}
                                <div className="rv__filters-left">

                                    {/* Report type */}
                                    <section className="rv__filter-section">
                                        <h3 className="rv__filter-label">
                                            Report type <span className="rv__info-icon">ⓘ</span>
                                        </h3>
                                        <div className="rv__radio-row">
                                            {reportTypeOptions.map(({ key, title, desc }) => (
                                                <label key={key} className="rv__radio-option">
                                                    <input
                                                        type="radio"
                                                        name="reportType"
                                                        checked={reportType === key}
                                                        onChange={() => setReportType(key)}
                                                        className="rv__radio-input"
                                                    />
                                                    <span className="rv__radio-content">
                                                        <span className="rv__radio-title">{title}</span>
                                                        <span className="rv__radio-desc">{desc}</span>
                                                    </span>
                                                </label>
                                            ))}
                                        </div>
                                    </section>

                                    {/* Show data */}
                                    <section className="rv__filter-section">
                                        <h3 className="rv__filter-label">
                                            Show data <span className="rv__info-icon">ⓘ</span>
                                        </h3>
                                        <div className="rv__checkbox-row">
                                            {SHOW_DATA_OPTIONS.map(opt => (
                                                <label key={opt.key} className="rv__checkbox-option">
                                                    <input
                                                        type="checkbox"
                                                        checked={showData[opt.key]}
                                                        onChange={() => setShowData(p => ({ ...p, [opt.key]: !p[opt.key] }))}
                                                        className="rv__checkbox-input"
                                                    />
                                                    <span className="rv__checkbox-label">{opt.label}</span>
                                                </label>
                                            ))}
                                        </div>
                                    </section>

                                    {/* Filtering */}
                                    <section className="rv__filter-section rv__filter-section--last">
                                        <h3 className="rv__filter-label">
                                            Filtering <span className="rv__info-icon">ⓘ</span>
                                        </h3>
                                        <div className="rv__chips-row">
                                            {chips.map(chip => (
                                                <Chip
                                                    key={chip.label}
                                                    mode="selectable"
                                                    size="medium"
                                                    selected={chip.active}
                                                    onClick={() => toggleChip(chip.label)}
                                                >
                                                    {chip.label}
                                                    <Chip.Counter>{chip.count}</Chip.Counter>
                                                </Chip>
                                            ))}
                                        </div>
                                    </section>
                                </div>

                                {/* RIGHT — sidebar, same height as filter sections */}
                                <div className="rv__sidebar">
                                    <section className="rv__sidebar-section">
                                        <h4 className="rv__sidebar-title">Report type</h4>
                                        <p className="rv__sidebar-text" style={{ whiteSpace: 'pre-line' }}>{SIDEBAR_DESC[reportType]}</p>
                                    </section>
                                    <section className="rv__sidebar-section">
                                        <h4 className="rv__sidebar-title">Show data</h4>
                                        <p className="rv__sidebar-text">In the Show details section, you can control which columns are displayed in the table. For example, selecting Show ISIN codes will either display the ISIN code column or hide it.</p>
                                    </section>
                                    <section className="rv__sidebar-section">
                                        <h4 className="rv__sidebar-title">Filtering</h4>
                                        <p className="rv__sidebar-text">Filters allow you to control the content shown in the table. Clearing the Directly registered holdings option filters the table so that directly registered holdings are excluded.</p>
                                    </section>
                                    <section className="rv__sidebar-section rv__sidebar-section--last">
                                        <h4 className="rv__sidebar-title">Download as file</h4>
                                        <p className="rv__sidebar-text">In the file download window, you can choose which report type you want to download and in which file format.</p>
                                    </section>
                                </div>
                            </div>

                            {/* ── Search row ── */}
                            <div className="rv__search-layout">
                                <div className="rv__search-left">
                                    <p className="rv__filter-summary">With filtered: owners 224 kpl, holdings 2391 kpl</p>
                                </div>
                                <div className="rv__search-box">
                                    <input
                                        type="text"
                                        placeholder="Search owner by name"
                                        value={search}
                                        onChange={e => setSearch(e.target.value)}
                                        className="rv__search-input"
                                    />
                                    <span className="rv__search-icon">🔍</span>
                                </div>
                            </div>

                            {/* Legend */}
                            <div className="rv__legend-row">
                                <span className="rv__legend-item">🚫 Non-disclosure</span>
                                <span className="rv__legend-item">🔗 Joint ownership</span>
                                <span className="rv__legend-item">📋 Nominee-registered holding</span>
                                <span className="rv__legend-item">🏦 Nominee Registration Custodians</span>
                            </div>

                            {/* ── Owner Table — no scroll, fixed width ── */}
                            <div className="rv__table-wrap">
                                <Table layout="fixed" hover>
                                    <Table.Head>
                                        <Table.Row>
                                            {/* First col — teal sort col */}
                                            <Table.HeadCell column="name" sortable style={{ width: '14%' }} className="rv__col--sort">
                                                NAME
                                                <Table.SecondaryText>IDENTIFICATION CODE</Table.SecondaryText>
                                                <Table.SecondaryText>DATE OF BIRTH</Table.SecondaryText>
                                                {cols.showAddress && <Table.SecondaryText>CUSTOMER RESTRICTIONS</Table.SecondaryText>}
                                            </Table.HeadCell>
                                            {cols.showAddress && (
                                                <Table.HeadCell column="addr" style={{ width: '12%' }}>
                                                    STREET ADDRESS
                                                    <Table.SecondaryText>POST ADDRESS</Table.SecondaryText>
                                                    <Table.SecondaryText>MUNICIPALITY OF RESIDENCE, COUNTRY</Table.SecondaryText>
                                                </Table.HeadCell>
                                            )}
                                            {cols.showCity && <Table.HeadCell column="city" style={{ width: '8%' }}>MUNICIPALITY</Table.HeadCell>}
                                            <Table.HeadCell column="type" style={{ width: '13%' }}>NAME OF THE BOOK-ENTRY TYPE</Table.HeadCell>
                                            {cols.showCustodian && <Table.HeadCell column="cust" style={{ width: '7%' }}>DEPOSITORY PARTICIPANT</Table.HeadCell>}
                                            <Table.HeadCell column="amt" align="right" style={{ width: '7%' }}>NUMBER OF BOOK-ENTRIES</Table.HeadCell>
                                            {cols.showPct && <Table.HeadCell column="pct" align="right" style={{ width: '8%' }}>PERCENTAGE OF BOOK-ENTRIES COMBINED</Table.HeadCell>}
                                            {cols.showVotes && <Table.HeadCell column="votes" align="right" style={{ width: '7%' }}>NUMBER OF VOTES</Table.HeadCell>}
                                            {cols.showVotePct && <Table.HeadCell column="vpct" align="right" style={{ width: '8%' }}>PERCENTAGE OF TOTAL VOTING RIGHTS</Table.HeadCell>}
                                            {cols.showDate && <Table.HeadCell column="date" sortable style={{ width: '7%' }}>SITUATION DATE</Table.HeadCell>}
                                            {cols.showSector && <Table.HeadCell column="sec" style={{ width: '9%' }}>SECTOR / LANGUAGE</Table.HeadCell>}
                                            {cols.showPayment && <Table.HeadCell column="pay" style={{ width: '9%' }}>PAYMENT INFORMATION</Table.HeadCell>}
                                            {cols.showTax && <Table.HeadCell column="tax" style={{ width: '7%' }}>TAX INFORMATION</Table.HeadCell>}
                                        </Table.Row>
                                    </Table.Head>
                                    <Table.Body>
                                        {filteredRows.map(row => (
                                            <OwnerTableRow key={row.id} row={row} cols={cols} />
                                        ))}
                                    </Table.Body>
                                </Table>
                            </div>

                            {/* ── Pagination — efi library component ── */}
                            <div className="rv__pagination">
                                <Pagination
                                    currentPage={currentPage}
                                    totalPages={totalPages}
                                    onPageChange={(page: number) => setCurrentPage(page)}
                                    firstLabel="First"
                                    lastLabel="Last"
                                    previousLabel="‹"
                                    nextLabel="›"
                                />
                            </div>

                            {/* ── Actions ── */}
                            <div className="rv__actions">
                                <Button variant="secondary" onClick={onBack}>BACK</Button>
                                <Button variant="primary" onClick={onSubscribe}>TO REPORT SUBSCRIPTION →</Button>
                            </div>
                        </>
                    )}

                    {activeTab === 'subscription' && (
                        <div className="rv__subscription-tab">
                            <p>Subscription info — coming soon</p>
                        </div>
                    )}
                </div>
            </Container>
        </>
    );
}
