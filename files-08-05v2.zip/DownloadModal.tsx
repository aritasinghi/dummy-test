import { useState } from 'react';
import { Dialog, Button, RadioGroup, Radio } from '@efi/efi-ui-components';
import type { Language } from '@/locales';
import type { ReportType } from '@/pages/ReportView/types';
import './DownloadModal.css';

type FileType    = 'csv' | 'xml' | 'pdf' | 'json';
type DownloadLang = 'fi' | 'en';

export interface DownloadOptions {
    reportType:         ReportType;
    useFilteredVersion: boolean;
    fileType:           FileType;
    downloadLang:       DownloadLang;
}

interface Props {
    isOpen:            boolean;
    language:          Language;
    currentReportType: ReportType;
    onClose:           () => void;
    onDownload:        (opts: DownloadOptions) => void;
}

const T: Record<string, Record<string, string>> = {
    fi: { title:'Lataa tiedostona', reportTypeTitle:'Raportin tyyppi',
          short:'Lyhyt', shortDesc:'Omistajien nimet ja osakkeiden lukumäärä',
          full:'Täysi',  fullDesc:'Kaikki saatavilla olevat tiedot',
          agm:'Yhtiökokous', agmDesc:'Osakasluettelo yhtiökokoukseen',
          stat:'Lakisääteinen', statDesc:'Lakisääteiset tiedot',
          filterTitle:'Suodatus', filterCheck:'Lataa käyttäjän suodattama versio',
          fileTypeTitle:'Tiedostotyyppi',
          langTitle:'Kieli', langFi:'Suomi', langEn:'Englanti',
          cancel:'PERUUTA', download:'LATAA' },
    en: { title:'Download as file', reportTypeTitle:'Report type',
          short:'Short', shortDesc:'Names of shareholders and number of shares',
          full:'Full',   fullDesc:'All available information',
          agm:'General meeting', agmDesc:'Shareholder register for general meeting',
          stat:"Issuer's shareholder list", statDesc:'Statutory information',
          filterTitle:'Filtering', filterCheck:'Download user-filtered version',
          fileTypeTitle:'File type',
          langTitle:'Language', langFi:'Finnish', langEn:'English',
          cancel:'CANCEL', download:'DOWNLOAD' },
    sv: { title:'Ladda ner som fil', reportTypeTitle:'Rapporttyp',
          short:'Kort', shortDesc:'Ägarnas namn och antal aktier',
          full:'Fullständig', fullDesc:'All tillgänglig information',
          agm:'Bolagsstämma', agmDesc:'Aktieägarregister för bolagsstämman',
          stat:'Lagstadgad', statDesc:'Lagstadgad information',
          filterTitle:'Filtrering', filterCheck:'Ladda ner användarfiltrerad version',
          fileTypeTitle:'Filtyp',
          langTitle:'Språk', langFi:'Finska', langEn:'Engelska',
          cancel:'AVBRYT', download:'LADDA NER' },
};

export function DownloadModal({ isOpen, language, currentReportType, onClose, onDownload }: Props) {
    const t = T[language] ?? T.fi;

    const [reportType,         setReportType]         = useState<ReportType>(currentReportType);
    const [useFilteredVersion, setUseFilteredVersion] = useState(true);
    const [fileType,           setFileType]           = useState<FileType>('csv');
    const [downloadLang,       setDownloadLang]       = useState<DownloadLang>(language === 'sv' ? 'fi' : language as DownloadLang);

    if (!isOpen) return null;

    const options = [
        { value: 'short'    as ReportType, label: t.short, desc: t.shortDesc },
        { value: 'full'     as ReportType, label: t.full,  desc: t.fullDesc  },
        { value: 'agm'      as ReportType, label: t.agm,   desc: t.agmDesc   },
        { value: 'statutory'as ReportType, label: t.stat,  desc: t.statDesc  },
    ];

    return (
        <div className="dl-modal">
            <Dialog closeLabel={t.cancel} onClose={onClose}>
                <Dialog.Content>
                    <div className="dl-modal__inner">

                        <h3 className="dl-modal__title">{t.title}</h3>
                        <hr className="dl-modal__divider" />

                        {/* Report type */}
                        <section className="dl-modal__section">
                            <h4 className="dl-modal__label">{t.reportTypeTitle}</h4>
                            <RadioGroup name="dlReportType" value={reportType}
                                onValueChange={(_, v) => setReportType(v as ReportType)}>
                                <div className="dl-modal__radio-list">
                                    {options.map(o => (
                                        <Radio key={o.value} value={o.value}>
                                            <Radio.Label>
                                                <span className="dl-modal__opt-title">{o.label}</span>
                                                <span className="dl-modal__opt-desc">{o.desc}</span>
                                            </Radio.Label>
                                        </Radio>
                                    ))}
                                </div>
                            </RadioGroup>
                        </section>

                        <hr className="dl-modal__divider" />

                        {/* Suodatus */}
                        <section className="dl-modal__section">
                            <h4 className="dl-modal__label">{t.filterTitle}</h4>
                            <label className="dl-modal__checkbox-row">
                                <input type="checkbox" className="dl-modal__checkbox"
                                    checked={useFilteredVersion}
                                    onChange={() => setUseFilteredVersion(v => !v)} />
                                <span className="dl-modal__checkbox-label">{t.filterCheck}</span>
                            </label>
                        </section>

                        <hr className="dl-modal__divider" />

                        {/* File type */}
                        <section className="dl-modal__section">
                            <h4 className="dl-modal__label">{t.fileTypeTitle}</h4>
                            <RadioGroup name="dlFileType" value={fileType}
                                onValueChange={(_, v) => setFileType(v as FileType)}>
                                <div className="dl-modal__radio-row">
                                    {(['csv','xml','pdf','json'] as FileType[]).map(ft => (
                                        <Radio key={ft} value={ft}>
                                            <Radio.Label>{ft.toUpperCase()}{ft === 'pdf' ? '-A' : ft === 'json' ? '?' : ''}</Radio.Label>
                                        </Radio>
                                    ))}
                                </div>
                            </RadioGroup>
                        </section>

                        <hr className="dl-modal__divider" />

                        {/* Language */}
                        <section className="dl-modal__section">
                            <h4 className="dl-modal__label">{t.langTitle}</h4>
                            <RadioGroup name="dlLang" value={downloadLang}
                                onValueChange={(_, v) => setDownloadLang(v as DownloadLang)}>
                                <div className="dl-modal__radio-row">
                                    <Radio value="fi"><Radio.Label>{t.langFi}</Radio.Label></Radio>
                                    <Radio value="en"><Radio.Label>{t.langEn}</Radio.Label></Radio>
                                </div>
                            </RadioGroup>
                        </section>

                    </div>
                </Dialog.Content>
                <Dialog.Buttons>
                    <Button variant="secondary" onClick={onClose}>{t.cancel}</Button>
                    <Button onClick={() => { onDownload({ reportType, useFilteredVersion, fileType, downloadLang }); }}>
                        {t.download}
                    </Button>
                </Dialog.Buttons>
            </Dialog>
        </div>
    );
}
