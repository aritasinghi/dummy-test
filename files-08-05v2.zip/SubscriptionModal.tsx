import { useState } from 'react';
import {
    Dialog, Button, RadioGroup, Radio, Input,
} from '@efi/efi-ui-components';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import { DatePicker } from '@/components/DatePicker';
import './SubscriptionModal.css';

// ─── Types ────────────────────────────────────────────────────────────────────

type OrderType      = 'one-time' | 'recurring';
type DateMode       = 'latest' | 'end-of-day' | 'custom';
type ReportTypeMode = 'full' | 'summary';
type Frequency      = 'daily' | 'monthly' | 'monthly-last' | 'quarterly' | 'quarterly-last' | 'yearly';

export interface SubscriptionFormData {
    orderType:      OrderType;
    dateMode:       DateMode;
    selectedDate?:  Date;
    reportTypeMode: ReportTypeMode;
    frequency:      Frequency;
    dayOfMonth:     number;
    selectedShares: string[];
    reference:      string;
}

interface SubscriptionModalProps {
    isOpen:      boolean;
    reportTitle: string;
    onClose:     () => void;
    onSubmit:    (data: SubscriptionFormData) => Promise<void>;
    language?:   Language;
}

interface FormErrors {
    dateMode?:      string;
    selectedDate?:  string;
    selectedShares?: string;
    dayOfMonth?:    string;
    reference?:     string;
}

// ─── Share class data ─────────────────────────────────────────────────────────

const ACTIVE_SHARES = [
    { value: 'euroflex-a-1', label: 'Euroflex A', isin: 'FI21049685930' },
    { value: 'euroflex-b-1', label: 'Euroflex B', isin: 'FI21049685931' },
    { value: 'euroflex-c-1', label: 'Euroflex C', isin: 'FI21049685932' },
];

const EXPIRED_SHARES = [
    { value: 'euroflex-a-old', label: 'OLDEuroflex A (05/17)', isin: 'FI21049685930' },
    { value: 'euroflex-b-old', label: 'OLDEuroflex B (05/17)', isin: 'FI21049685931' },
];

// ─── Validation ───────────────────────────────────────────────────────────────

function validate(
    orderType:      OrderType,
    dateMode:       DateMode,
    selectedDate:   Date | null,
    selectedShares: string[],
    frequency:      Frequency,
    dayOfMonth:     string,
    reference:      string,
    t:              { validationRequired: string; validationDateRequired: string;
                     validationDateFuture: string; validationShareRequired: string;
                     validationDayRange: string; validationReferenceFormat: string; }
): FormErrors {
    const errors: FormErrors = {};

    // Custom date validation
    if (orderType === 'one-time' && dateMode === 'custom') {
        if (!selectedDate) {
            errors.selectedDate = t.validationDateRequired;
        } else {
            const maxDate = new Date();
            maxDate.setFullYear(maxDate.getFullYear() + 1);
            if (selectedDate > maxDate) {
                errors.selectedDate = t.validationDateFuture;
            }
        }
    }

    // Day of month for recurring
    if (orderType === 'recurring' && ['monthly', 'quarterly', 'yearly'].includes(frequency)) {
        const day = Number(dayOfMonth);
        if (!dayOfMonth || isNaN(day) || day < 1 || day > 31) {
            errors.dayOfMonth = t.validationDayRange;
        }
    }

    // At least one share
    if (selectedShares.length === 0) {
        errors.selectedShares = t.validationShareRequired;
    }

    // Reference: alphanumeric + spaces, max 35 chars
    if (reference && !/^[a-zA-Z0-9\s\-]{0,35}$/.test(reference)) {
        errors.reference = t.validationReferenceFormat;
    }

    return errors;
}

// ─── Component ────────────────────────────────────────────────────────────────

export function SubscriptionModal({
    isOpen, reportTitle, onClose, onSubmit, language = 'fi',
}: SubscriptionModalProps) {
    const t  = translations[language].subscription;
    const rv = translations[language].reportView;

    // ── Form state ────────────────────────────────────────────────────────────
    const [orderType,            setOrderType]           = useState<OrderType>('one-time');
    const [dateMode,             setDateMode]            = useState<DateMode>('latest');
    const [selectedDate,         setSelectedDate]        = useState<Date | null>(null);
    const [showDatePicker,       setShowDatePicker]      = useState(false);
    const [reportTypeMode,       setReportTypeMode]      = useState<ReportTypeMode>('full');
    const [frequency,            setFrequency]           = useState<Frequency>('monthly');
    const [dayOfMonth,           setDayOfMonth]          = useState('31');
    const [selectedShares,       setSelectedShares]      = useState<string[]>(ACTIVE_SHARES.map(s => s.value));
    const [showExpired,          setShowExpired]         = useState(false);
    const [selectedExpiredShares,setSelectedExpiredShares] = useState<string[]>([]);
    const [reference,            setReference]           = useState('');

    // ── Submission state ──────────────────────────────────────────────────────
    const [errors,    setErrors]    = useState<FormErrors>({});
    const [submitted, setSubmitted] = useState(false);
    const [loading,   setLoading]   = useState(false);
    const [apiError,  setApiError]  = useState<string | null>(null);

    if (!isOpen) return null;

    const dateLocale = language === 'fi' ? 'fi-FI' : language === 'sv' ? 'sv-SE' : 'en-GB';

    const allSelectedShares = [
        ...selectedShares,
        ...(showExpired ? selectedExpiredShares : []),
    ];

    const toggleShare = (value: string, list: string[], setList: (v: string[]) => void) => {
        const updated = list.includes(value)
            ? list.filter(v => v !== value)
            : [...list, value];
        setList(updated);
        if (submitted && updated.length > 0) {
            setErrors(e => ({ ...e, selectedShares: undefined }));
        }
    };

    const validationT = {
        validationRequired:       t.validationRequired      ?? 'This field is required',
        validationDateRequired:   t.validationDateRequired  ?? 'Select a date',
        validationDateFuture:     t.validationDateFuture    ?? 'Date cannot be more than 1 year in the future',
        validationShareRequired:  t.validationShareRequired ?? 'Select at least one share class',
        validationDayRange:       t.validationDayRange      ?? 'Enter a day between 1–31',
        validationReferenceFormat:t.validationReferenceFormat ?? 'Reference may only contain letters, numbers, spaces and dashes (max 35)',
    };

    const getFrequencyInfo = () => {
        if (frequency.startsWith('monthly'))   return t.frequencyInfoMonthly;
        if (frequency.startsWith('quarterly')) return t.frequencyInfoQuarterly;
        if (frequency === 'yearly')            return t.frequencyInfoYearly;
        return t.frequencyInfoMonthly;
    };

    // ── Submit ────────────────────────────────────────────────────────────────
    const handleSubmit = async () => {
        setSubmitted(true);
        setApiError(null);

        const errs = validate(
            orderType, dateMode, selectedDate,
            allSelectedShares, frequency, dayOfMonth, reference,
            validationT,
        );
        setErrors(errs);

        if (Object.keys(errs).length > 0) {
            // Scroll to first error
            document.querySelector('.sub-modal__error')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
            return;
        }

        setLoading(true);
        try {
            await onSubmit({
                orderType,
                dateMode,
                selectedDate: selectedDate ?? undefined,
                reportTypeMode,
                frequency,
                dayOfMonth: Number(dayOfMonth),
                selectedShares: allSelectedShares,
                reference,
            });
            // Reset on success (parent closes the modal)
            resetForm();
        } catch (err: unknown) {
            setApiError(err instanceof Error ? err.message : t.apiError ?? 'Order failed. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    const resetForm = () => {
        setOrderType('one-time');
        setDateMode('latest');
        setSelectedDate(null);
        setReportTypeMode('full');
        setFrequency('monthly');
        setDayOfMonth('31');
        setSelectedShares(ACTIVE_SHARES.map(s => s.value));
        setShowExpired(false);
        setSelectedExpiredShares([]);
        setReference('');
        setErrors({});
        setSubmitted(false);
        setApiError(null);
    };

    const handleClose = () => {
        resetForm();
        onClose();
    };

    // ── Render ────────────────────────────────────────────────────────────────
    return (
        <>
            <div className="sub-modal-dialog">
                <Dialog closeLabel={t.cancel} onClose={handleClose} maxWidth="max-content">
                    <Dialog.Content>

                    <div className="sub-modal__inner">

                        {/* ── Title + order type tabs ── */}
                        <div className="sub-modal__title-row">
                            <h4 className="sub-modal__title">{t.title}: {reportTitle}</h4>
                            <RadioGroup
                                name="orderType"
                                value={orderType}
                                onValueChange={(_, val) => {
                                    setOrderType(val as OrderType);
                                    setErrors({});
                                    setSubmitted(false);
                                    setApiError(null);
                                }}
                            >
                                <div className="sub-modal__order-toggle">
                                    <Radio value="one-time"><Radio.Label>{t.oneTime}</Radio.Label></Radio>
                                    <Radio value="recurring"><Radio.Label>{t.recurring}</Radio.Label></Radio>
                                </div>
                            </RadioGroup>
                        </div>

                        <hr className="sub-modal__divider" />

                        {/* ══════════════════════════════════
                            ONE-TIME ORDER
                        ══════════════════════════════════ */}
                        {orderType === 'one-time' && (
                            <>
                                {/* Situation date section */}
                                <section className="sub-modal__section">
                                    <h3 className="sub-modal__section-title">{t.oneTimeTitle}</h3>
                                    <div className="sub-modal__two-col">
                                        <div className="sub-modal__col-left">
                                            <h4 className="sub-modal__label">{t.reportDateTitle}</h4>
                                            <RadioGroup
                                                name="dateMode"
                                                value={dateMode}
                                                onValueChange={(_, val) => {
                                                    setDateMode(val as DateMode);
                                                    if (submitted) setErrors(e => ({ ...e, dateMode: undefined, selectedDate: undefined }));
                                                }}
                                            >
                                                <div className="sub-modal__date-modes">
                                                    <div className="sub-modal__date-modes-col">
                                                        <Radio value="latest">
                                                            <Radio.Label>{t.dateLatest}</Radio.Label>
                                                        </Radio>
                                                        <Radio value="end-of-day">
                                                            <Radio.Label>{t.dateEndOfDay}</Radio.Label>
                                                        </Radio>
                                                    </div>
                                                    <div className="sub-modal__date-modes-col">
                                                        <Radio value="custom">
                                                            <Radio.Label>{t.dateSelectCustom}</Radio.Label>
                                                        </Radio>
                                                        {/* Date picker trigger — fixed height to prevent layout shift */}
                                                        <div className="sub-modal__date-placeholder">
                                                            {dateMode === 'custom' ? (
                                                                <div>
                                                                    <button
                                                                        type="button"
                                                                        className={`sub-modal__date-trigger${errors.selectedDate ? ' sub-modal__date-trigger--error' : ''}`}
                                                                        onClick={() => setShowDatePicker(true)}
                                                                    >
                                                                        <span className="sub-modal__date-label">{t.selectDateLabel}</span>
                                                                        <span className="sub-modal__date-value">
                                                                            {selectedDate
                                                                                ? selectedDate.toLocaleDateString(dateLocale)
                                                                                : <span className="sub-modal__date-placeholder-text">pp.kk.vvvv</span>
                                                                            }
                                                                        </span>
                                                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                                            <rect x="2" y="3" width="12" height="11" rx="1.5" stroke="currentColor" strokeWidth="1.2"/>
                                                                            <path d="M2 6.5h12" stroke="currentColor" strokeWidth="1.2"/>
                                                                            <path d="M5 1.5v3M11 1.5v3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
                                                                        </svg>
                                                                    </button>
                                                                    {errors.selectedDate && (
                                                                        <p className="sub-modal__error sub-modal__error--sm">⚠ {errors.selectedDate}</p>
                                                                    )}
                                                                </div>
                                                            ) : (
                                                                <div className="sub-modal__date-trigger sub-modal__date-trigger--ghost" aria-hidden="true" />
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                            </RadioGroup>
                                        </div>
                                        <div className="sub-modal__info-stack">
                                            <div className="sub-modal__info-box sub-modal__info-box--light">
                                                <h4 className="sub-modal__info-title">{t.dateInfoTitle}</h4>
                                                <p className="sub-modal__info-text">{t.dateInfoDesc}</p>
                                            </div>
                                        </div>
                                    </div>
                                </section>

                                <hr className="sub-modal__divider" />

                                {/* Report type: Full / Summary only */}
                                <section className="sub-modal__section">
                                    <div className="sub-modal__two-col">
                                        <div className="sub-modal__col-left">
                                            <h4 className="sub-modal__label">{rv.reportTypeTitle}</h4>
                                            <RadioGroup
                                                name="reportTypeMode"
                                                value={reportTypeMode}
                                                onValueChange={(_, val) => setReportTypeMode(val as ReportTypeMode)}
                                            >
                                                <div className="sub-modal__freq-grid sub-modal__freq-grid--2col">
                                                    <Radio value="full">
                                                        <Radio.Label>{t.reportTypeFull}</Radio.Label>
                                                    </Radio>
                                                    <Radio value="summary">
                                                        <Radio.Label>{t.reportTypeSummary}</Radio.Label>
                                                    </Radio>
                                                </div>
                                            </RadioGroup>
                                        </div>
                                        <div className="sub-modal__info-stack">
                                            <div className="sub-modal__info-box sub-modal__info-box--light">
                                                <h4 className="sub-modal__info-title">{t.reportTypeFull}</h4>
                                                <p className="sub-modal__info-text">{t.reportTypeFullDesc}</p>
                                            </div>
                                            <div className="sub-modal__info-box sub-modal__info-box--light">
                                                <h4 className="sub-modal__info-title">{t.reportTypeSummary}</h4>
                                                <p className="sub-modal__info-text">{t.reportTypeSummaryDesc}</p>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </>
                        )}

                        {/* ══════════════════════════════════
                            RECURRING ORDER
                        ══════════════════════════════════ */}
                        {orderType === 'recurring' && (
                            <section className="sub-modal__section">
                                <h3 className="sub-modal__section-title">{t.recurringTitle}</h3>
                                <div className="sub-modal__two-col">
                                    <div className="sub-modal__col-left">
                                        <h4 className="sub-modal__label">{t.frequencyTitle}</h4>
                                        <RadioGroup
                                            name="frequency"
                                            value={frequency}
                                            onValueChange={(_, val) => {
                                                setFrequency(val as Frequency);
                                                if (submitted) setErrors(e => ({ ...e, dayOfMonth: undefined }));
                                            }}
                                        >
                                            <div className="sub-modal__freq-grid">
                                                <Radio value="daily"><Radio.Label>{t.daily}</Radio.Label></Radio>
                                                <Radio value="monthly"><Radio.Label>{t.monthly}</Radio.Label></Radio>
                                                <Radio value="monthly-last"><Radio.Label>{t.monthlyLast}</Radio.Label></Radio>
                                                <Radio value="quarterly"><Radio.Label>{t.quarterly}</Radio.Label></Radio>
                                                <Radio value="quarterly-last"><Radio.Label>{t.quarterlyLast}</Radio.Label></Radio>
                                                <Radio value="yearly"><Radio.Label>{t.yearly}</Radio.Label></Radio>
                                            </div>
                                        </RadioGroup>

                                        {/* Day picker for monthly/quarterly/yearly */}
                                        {['monthly', 'quarterly', 'yearly'].includes(frequency) && (
                                            <div className="sub-modal__day-select">
                                                <Input
                                                    style={{ width: '130px' }}
                                                    type="number"
                                                    value={dayOfMonth}
                                                    onChange={e => {
                                                        setDayOfMonth(e.target.value);
                                                        if (submitted) setErrors(er => ({ ...er, dayOfMonth: undefined }));
                                                    }}
                                                    invalid={!!errors.dayOfMonth}
                                                >
                                                    <Input.Label>{t.selectDay}</Input.Label>
                                                    {errors.dayOfMonth && (
                                                        <Input.ErrorMessage>{errors.dayOfMonth}</Input.ErrorMessage>
                                                    )}
                                                </Input>
                                            </div>
                                        )}
                                    </div>

                                    <div className="sub-modal__info-stack">
                                        <div className="sub-modal__info-box sub-modal__info-box--light">
                                            <h4 className="sub-modal__info-title">{t.frequencyInfoTitle}</h4>
                                            <p className="sub-modal__info-text">{getFrequencyInfo()}</p>
                                        </div>
                                        <div className="sub-modal__info-box sub-modal__info-box--pink">
                                            <p className="sub-modal__info-text">{t.frequencyInfoMonthlyNote}</p>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        )}

                        <hr className="sub-modal__divider" />

                        {/* ── Share classes + reference ── */}
                        <section className="sub-modal__section">
                            <div className="sub-modal__two-col">
                                <div className="sub-modal__col-left">
                                    <h3 className="sub-modal__section-title">{t.sharesTitle}</h3>
                                    <p className="sub-modal__shares-type">{t.shareType}</p>

                                    {errors.selectedShares && (
                                        <p className="sub-modal__error">⚠ {errors.selectedShares}</p>
                                    )}

                                    {/* Active share classes */}
                                    <div className="sub-modal__shares-grid">
                                        {ACTIVE_SHARES.map(share => (
                                            <label key={share.value} className="sub-modal__checkbox-option">
                                                <input
                                                    type="checkbox"
                                                    checked={selectedShares.includes(share.value)}
                                                    onChange={() => toggleShare(share.value, selectedShares, setSelectedShares)}
                                                    className="sub-modal__checkbox-input"
                                                />
                                                <span className="sub-modal__checkbox-text">
                                                    <span className="sub-modal__checkbox-name">{share.label}</span>
                                                    <span className="sub-modal__checkbox-isin">{share.isin}</span>
                                                </span>
                                            </label>
                                        ))}
                                    </div>

                                    {/* Expired toggle — CHECKBOX (not radio) */}
                                    <label className="sub-modal__expired-toggle">
                                        <input
                                            type="checkbox"
                                            className="sub-modal__checkbox-input"
                                            checked={showExpired}
                                            onChange={() => {
                                                setShowExpired(v => !v);
                                                if (!showExpired) setSelectedExpiredShares([]);
                                            }}
                                        />
                                        <span>{t.showExpiredLabel ?? 'Näytä myös päättyneet arvo-osuuslajit'}</span>
                                    </label>

                                    {/* Expired share classes */}
                                    {showExpired && (
                                        <div className="sub-modal__expired-section">
                                            <p className="sub-modal__expired-label">{t.expiredSharesLabel ?? 'Päättyneet arvo-osuudet'}</p>
                                            <div className="sub-modal__shares-grid">
                                                {EXPIRED_SHARES.map(share => (
                                                    <label key={share.value} className="sub-modal__checkbox-option">
                                                        <input
                                                            type="checkbox"
                                                            checked={selectedExpiredShares.includes(share.value)}
                                                            onChange={() => toggleShare(share.value, selectedExpiredShares, setSelectedExpiredShares)}
                                                            className="sub-modal__checkbox-input"
                                                        />
                                                        <span className="sub-modal__checkbox-text">
                                                            <span className="sub-modal__checkbox-name">{share.label}</span>
                                                            <span className="sub-modal__checkbox-isin">{share.isin}</span>
                                                        </span>
                                                    </label>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </div>

                                <div className="sub-modal__info-stack">
                                    <div className="sub-modal__info-box sub-modal__info-box--light">
                                        <h4 className="sub-modal__info-title">{t.shareSelectionTitle}</h4>
                                        <p className="sub-modal__info-text">{t.shareSelectionDesc}</p>
                                    </div>
                                </div>
                            </div>
                        </section>

                        {/* ── Tilauksen viite ── */}
                        <section className="sub-modal__section">
                            <div className="sub-modal__two-col">
                                <div className="sub-modal__col-left">
                                    <Input
                                        type="text"
                                        value={reference}
                                        onChange={e => {
                                            setReference(e.target.value);
                                            if (submitted) setErrors(er => ({ ...er, reference: undefined }));
                                        }}
                                        invalid={!!errors.reference}
                                    >
                                        <Input.Label>{t.referenceLabel}</Input.Label>
                                        <Input.Description>{t.referencePlaceholder}</Input.Description>
                                        {errors.reference && (
                                            <Input.ErrorMessage>{errors.reference}</Input.ErrorMessage>
                                        )}
                                    </Input>
                                </div>
                                <div className="sub-modal__info-stack">
                                    <div className="sub-modal__info-box sub-modal__info-box--light">
                                        <h4 className="sub-modal__info-title">{t.referenceInfoTitle}</h4>
                                        <p className="sub-modal__info-text">{t.referenceInfoDesc}</p>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <hr className="sub-modal__divider" />

                        {/* ── Price + API error ── */}
                        <div className="sub-modal__price-row">
                            <p className="sub-modal__price-note">{t.priceNote}</p>
                            <p className="sub-modal__price-next">{t.priceNextView}</p>
                        </div>

                        {/* API error banner */}
                        {apiError && (
                            <div className="sub-modal__api-error">
                                <span>⚠</span> {apiError}
                            </div>
                        )}

                        {/* Validation summary — only after first submit attempt */}
                        {submitted && Object.keys(errors).length > 0 && (
                            <div className="sub-modal__error-summary">
                                <p className="sub-modal__error-summary-title">⚠ {t.validationSummaryTitle ?? 'Tarkista seuraavat kentät:'}</p>
                                <ul>
                                    {Object.values(errors).map((msg, i) => (
                                        <li key={i}>{msg}</li>
                                    ))}
                                </ul>
                            </div>
                        )}

                    </div>{/* end sub-modal__inner */}
                    </Dialog.Content>

                    <Dialog.Buttons>
                        <Button type="reset" variant="secondary" onClick={handleClose} disabled={loading}>
                            {t.cancel}
                        </Button>
                        <Button type="submit" onClick={handleSubmit} disabled={loading}>
                            {loading ? (t.submitting ?? 'Lähetetään...') : t.submit}
                        </Button>
                    </Dialog.Buttons>
                </Dialog>
            </div>

            <DatePicker
                isOpen={showDatePicker}
                lang={language}
                selectedDate={selectedDate ?? undefined}
                onSelect={d => {
                    setSelectedDate(d);
                    setShowDatePicker(false);
                    if (submitted) setErrors(e => ({ ...e, selectedDate: undefined }));
                }}
                onCancel={() => setShowDatePicker(false)}
            />
        </>
    );
}
