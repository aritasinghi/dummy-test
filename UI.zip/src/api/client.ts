import axios from 'axios';
import type { AxiosError, AxiosRequestConfig, InternalAxiosRequestConfig } from 'axios';

/**
 * Centralized API client.
 *
 * - Base URL from VITE_API_BASE_URL env variable
 * - Request interceptor for auth token injection
 * - Response interceptor for error normalization
 * - Typed helper methods (get, post, put, patch, delete)
 */

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface ApiErrorResponse {
    status: number;
    message: string;
    code?: string;
    details?: unknown;
}

// ---------------------------------------------------------------------------
// Axios instance
// ---------------------------------------------------------------------------

const apiClient = axios.create({
    baseURL: import.meta.env.VITE_API_BASE_URL || '/api',
    timeout: 30_000,
    headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
    },
});

// ---------------------------------------------------------------------------
// Request interceptor
// ---------------------------------------------------------------------------

apiClient.interceptors.request.use(
    (config: InternalAxiosRequestConfig) => {
        // TODO: Attach auth token from OpenAM/SSO session
        // const token = getAuthToken();
        // if (token) {
        //     config.headers.Authorization = `Bearer ${token}`;
        // }
        return config;
    },
    (error: AxiosError) => Promise.reject(error),
);

// ---------------------------------------------------------------------------
// Response interceptor
// ---------------------------------------------------------------------------

apiClient.interceptors.response.use(
    (response) => response,
    (error: AxiosError<ApiErrorResponse>) => {
        const status = error.response?.status;

        const apiError: ApiErrorResponse = {
            status: status ?? 0,
            message:
                error.response?.data?.message ??
                error.message ??
                'An unexpected error occurred',
            code: error.response?.data?.code ?? error.code,
            details: error.response?.data?.details,
        };

        switch (status) {
            case 401:
                console.warn('[API] Unauthorized — redirecting to login');
                // TODO: redirect to OpenAM login
                break;
            case 403:
                console.warn('[API] Forbidden — insufficient permissions');
                break;
            case 500:
            case 502:
            case 503:
                console.error('[API] Server error:', apiError.message);
                break;
        }

        return Promise.reject(apiError);
    },
);

// ---------------------------------------------------------------------------
// Typed request helpers
// ---------------------------------------------------------------------------

export const api = {
    get: <T>(url: string, config?: AxiosRequestConfig) =>
        apiClient.get<T>(url, config).then((res) => res.data),

    post: <T>(url: string, data?: unknown, config?: AxiosRequestConfig) =>
        apiClient.post<T>(url, data, config).then((res) => res.data),

    put: <T>(url: string, data?: unknown, config?: AxiosRequestConfig) =>
        apiClient.put<T>(url, data, config).then((res) => res.data),

    patch: <T>(url: string, data?: unknown, config?: AxiosRequestConfig) =>
        apiClient.patch<T>(url, data, config).then((res) => res.data),

    delete: <T>(url: string, config?: AxiosRequestConfig) =>
        apiClient.delete<T>(url, config).then((res) => res.data),
};

export default apiClient;
