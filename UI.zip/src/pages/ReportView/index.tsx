import { useState } from 'react';
import { Button } from '@efi/efi-ui-components';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import './ReportView.css';

interface ReportViewProps {
    reportTitle: string;
    reportDate: string;
    language: Language;
    onBack: () => void;
    onSubscribe: () => void;
    onDownload?: () => void;
}

type ReportType = 'full' | 'agm' | 'statutory' | 'short';

const SUMMARY_DATA = [
    { aoLaji: 'A', omistajien: '1,423', yhteis: '12', kaikkien: '29,000', osuus: '64%', kokonaisAani: '29,300', kokonaisOsake: '99,998', osakas: '94,667', odotus: '5,331', hallinta: '1028,22', yhteistili: '64', osuusLiik: '44%' },
    { aoLaji: 'B', omistajien: '620', yhteis: '24', kaikkien: '20,000', osuus: '24%', kokonaisAani: '22,400', kokonaisOsake: '33,886', osakas: '32,768', odotus: '1,118', hallinta: '643,33', yhteistili: '82', osuusLiik: '22%' },
    { aoLaji: 'Yhteensä', omistajien: '2,391', yhteis: '39', kaikkien: '49,908', osuus: '100%', kokonaisAani: '51,802', kokonaisOsake: '156,767', osakas: '148,102', odotus: '8,665', hallinta: '1 782,77', yhteistili: '257', osuusLiik: '100%' },
];

const SHARES_INFO = [
    { name: 'EUROFLEX A', isin: 'FI21049685930', abbr: 'EUROFLA' },
    { name: 'EUROFLEX B', isin: 'FI21049685931', abbr: 'EUROFLB' },
    { name: 'EUROFLEX C', isin: 'FI21049685932', abbr: 'EUROFLC' },
];

const SHOW_DATA_OPTIONS = ['turvakiellossa olevat osoitetiedot', 'ISIN-koodit', 'Yksilöintitunnus', 'Päättyneet arvo-osuuslajit', 'Ylätason sektoritieto', 'Tilinhoitaja'];

const FILTER_CHIPS = [
    { label: 'Suorarekisteröidyt omistukset', count: 2379, active: true },
    { label: 'Hallintarekisteröidyt omistukset', count: 12, active: false },
    { label: 'Yritykset', count: 1112, active: true },
    { label: 'Rahoitus- ja vakuutuslaitokset', count: 23, active: false },
    { label: 'Kotitaloudet', count: 1856, active: true },
];

const OWNER_ROWS = [
    { name: 'Thomas-Peter Long-lastname', id: '120370-8902A', dob: '20.02.1904', address: 'Arvopaperitie 12\n00100 Helsinki\nHelsinki, Suomi', shares: 'EUROFLEX A, EUROFLEXA, FI21049685930\nEUROFLEX B, EUROFLEXB, FI21049685931\nArvo-osuudet yhteensä', amounts: '30300\n40\n70', pct: '0,00005\n0,00004\n0,0 0003', votes: '603\n600\n1203', votePct: '0,00005\n0,00004\n0,00009', tilinhoitaja: '', tilanne: '31/12/2024', sektori: 'Julkiset yritykset\npl. asuntoyhteisö /\nsuomi', maksu: 'FI12345677787788', vero: 'TBC' },
    { name: 'Clarck Confidential', id: '020377-0290B', dob: '20.02.1904', address: 'Yhteyssosite:\nJokitie 22 b\n00100 Helsinki', shares: 'EUROFLEX A, EUROFLEXA, FI21049685930\nEUROFLEX B, EUROFLEXB, FI21049685931\nArvo-osuudet yhteensä', amounts: '30\n40\n70', pct: '0,00005\n0,00004\n0,00003', votes: '3\n600\n603', votePct: '0,00005\n0,00004\n0,00003', tilinhoitaja: 'Nimi?\nMuut tiedot?', tilanne: '31/12/2024', sektori: 'Julkiset yritykset\npl. asuntoyhteisö /\nsuomi', maksu: 'FI12345677787788', vero: 'TBC' },
    { name: 'Yritys OY Ab', id: '7769765-5', dob: '20.02.1904', address: 'Arvopaperitie 12\n00100 Helsinki\nHelsinki, Suomi', shares: 'EUROFLEX A, EUROFLEXA, FI21049685930\nEUROFLEX B, EUROFLEXB, FI21049685931\nArvo-osuudet yhteensä', amounts: '30\n40\n70', pct: '0,00005\n0,00004\n0,00003', votes: '3\n600\n603', votePct: '0,00005\n0,00004\n0,00003', tilinhoitaja: 'Nimi?\nMuut tiedot?', tilanne: '31/12/2024', sektori: 'Julkiset yritykset\npl. asuntoyhteisö /\nsuomi', maksu: 'FI12345677787788', vero: 'TBC' },
];

export default function ReportView({ reportTitle, reportDate, language, onBack, onSubscribe, onDownload }: ReportViewProps) {
    const t = translations[language].reportView;
    const rp = translations[language].reportPreview;
    const [activeTab, setActiveTab] = useState<'report' | 'subscription'>('report');
    const [reportType, setReportType] = useState<ReportType>('full');
    const [showDataChecks, setShowDataChecks] = useState<Record<string, boolean>>(Object.fromEntries(SHOW_DATA_OPTIONS.map((o) => [o, true])));
    const [searchQuery, setSearchQuery] = useState('');
    const [currentPage, setCurrentPage] = useState(1);

    const toggleShowData = (key: string) => setShowDataChecks((p) => ({ ...p, [key]: !p[key] }));

    const reportTypes: { key: ReportType; label: string; desc: string }[] = [
        { key: 'full', label: rp.full, desc: t.fullDesc },
        { key: 'agm', label: rp.agm, desc: t.agmDesc },
        { key: 'statutory', label: rp.statutory, desc: t.statutoryDesc },
        { key: 'short', label: rp.short, desc: t.shortDesc },
    ];

    return (
        <div className="report-view">
            {/* Header */}
            <div className="report-view__header">
                <div>
                    <h1 className="report-view__title">{reportDate} {reportTitle}</h1>
                    <div className="report-view__tabs">
                        <button className={`report-view__tab ${activeTab === 'report' ? 'report-view__tab--active' : ''}`} onClick={() => setActiveTab('report')} type="button">{t.tabReport}</button>
                        <button className={`report-view__tab ${activeTab === 'subscription' ? 'report-view__tab--active' : ''}`} onClick={() => setActiveTab('subscription')} type="button">{t.tabSubscriptionInfo}</button>
                    </div>
                </div>
                <button className="report-view__download-btn" type="button" onClick={onDownload}>
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 2v8m0 0L5 7m3 3l3-3M3 12h10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                    {t.downloadFile}
                </button>
            </div>

            {/* ════════════════════════════════════════════════════════════
               RAPORTIN YHTEENVETO — with Tiedot + Arvo-osuudet above table
               ════════════════════════════════════════════════════════════ */}
            <div className="report-view__summary-card">
                <h2 className="report-view__section-title">{t.summaryTitle}</h2>

                {/* Tiedot + Arvo-osuudet info row */}
                <div className="report-view__info-row">
                    <div className="report-view__info-block">
                        <h4 className="report-view__info-heading">{t.infoTitle}</h4>
                        <p className="report-view__info-line">{t.issuer}: <strong>Euroflex Oyj</strong></p>
                        <p className="report-view__info-line">{t.reportName}: <strong>Liikkeeseenlaskijan omistusraportti</strong></p>
                        <p className="report-view__info-line">{t.orderDate}?</p>
                        <p className="report-view__info-line">{t.situationDate}: <strong>13.3.2026</strong></p>
                    </div>
                    <div className="report-view__info-block report-view__info-block--shares">
                        <h4 className="report-view__info-heading">Arvo-osuudet</h4>
                        <div className="report-view__shares-info">
                            {SHARES_INFO.map((s) => (
                                <div key={s.isin} className="report-view__share-col">
                                    <p className="report-view__info-line">{t.shareNameLabel}: <strong>{s.name}</strong></p>
                                    <p className="report-view__info-line">{t.isinLabel}: <strong>{s.isin}</strong></p>
                                    <p className="report-view__info-line">{t.abbreviationLabel}: <strong>{s.abbr}</strong></p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Yhteenveto subtitle */}
                <h3 className="report-view__sub-title">Yhteenveto</h3>

                {/* Summary table */}
                <table className="report-view__summary-table">
                    <thead><tr>
                        <th className="report-view__th--sortable">AO-LAJI <span className="report-view__sort-icon">↓</span></th>
                        <th>OMISTAJIEN MÄÄRÄ</th>
                        <th>YHTEIS&shy;OMISTAJIEN MÄÄRÄ</th>
                        <th>KAIKKIEN ARVO-OSUUSTILEILLÄ OLEVIEN OSAKKEIDEN TUOTTAMA ÄÄNIMÄÄRÄ</th>
                        <th>OSUUS KAIKKIEN ARVO-OSUUSTILEILLÄ OLEVIEN OSAKKEIDEN TUOTTAMASTA KOKONAIS&shy;ÄÄNIMÄÄRÄSTÄ</th>
                        <th>KOKONAIS- ÄÄNIMÄÄRÄ</th>
                        <th>KOKONAIS- OSAKEMÄÄRÄ</th>
                        <th>OSAKAS- LUETTELOLLA</th>
                        <th>ODOTUS- LUETTELOLLA</th>
                        <th>HALLINTA- REKISTERÖIDYT</th>
                        <th>YHTEISTILILLÄ</th>
                        <th>OSUUS LIIKKEESEEN- LASKETUSTA MÄÄRÄSTÄ</th>
                    </tr></thead>
                    <tbody>
                        {SUMMARY_DATA.map((row) => (
                            <tr key={row.aoLaji}>
                                <td className="report-view__cell--bold">{row.aoLaji}</td>
                                <td>{row.omistajien}</td><td>{row.yhteis}</td><td>{row.kaikkien}</td><td>{row.osuus}</td>
                                <td>{row.kokonaisAani}</td><td>{row.kokonaisOsake}</td><td>{row.osakas}</td><td>{row.odotus}</td>
                                <td>{row.hallinta}</td><td>{row.yhteistili}</td><td>{row.osuusLiik}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            <div className="report-view__body">
                <div className="report-view__main">
                    {/* Report type — INLINE with sidebar */}
                    <section className="report-view__section">
                        <div className="report-view__inline-row">
                            <div className="report-view__inline-left">
                                <h3 className="report-view__label">{t.reportTypeTitle} <span className="report-view__info-icon">ⓘ</span></h3>
                                <div className="report-view__type-row">
                                    {reportTypes.map(({ key, label, desc }) => (
                                        <label key={key} className="report-view__type-option">
                                            <input type="radio" name="reportType" checked={reportType === key} onChange={() => setReportType(key)} />
                                            <span><strong>{label}</strong><br/><span className="report-view__type-desc">{desc}</span></span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                            <div className="report-view__inline-right">
                                <h4 className="report-view__sidebar-title">{reportTitle}</h4>
                                <p className="report-view__sidebar-text">{translations[language].reportPreview.whatIsThisDesc?.slice(0, 200)}...</p>
                                <h4 className="report-view__sidebar-title" style={{ marginTop: '1rem' }}>{t.reportTypeTitle}</h4>
                                <p className="report-view__sidebar-text">{rp.full}... {rp.agm}... {rp.statutory}... {rp.short}...</p>
                            </div>
                        </div>
                    </section>

                    {/* Show data — INLINE with sidebar */}
                    <section className="report-view__section">
                        <div className="report-view__inline-row">
                            <div className="report-view__inline-left">
                                <h3 className="report-view__label">{t.showDataTitle} <span className="report-view__info-icon">ⓘ</span></h3>
                                <div className="report-view__show-data-row">
                                    {SHOW_DATA_OPTIONS.map((opt) => (
                                        <label key={opt} className="report-view__checkbox">
                                            <input type="checkbox" checked={showDataChecks[opt]} onChange={() => toggleShowData(opt)} />
                                            <span>{opt}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                            <div className="report-view__inline-right">
                                <h4 className="report-view__sidebar-title">{t.showDataTitle}</h4>
                                <p className="report-view__sidebar-text">{t.fileDownloadDesc?.slice(0, 200)}...</p>
                            </div>
                        </div>
                    </section>

                    {/* Filters — INLINE with sidebar */}
                    <section className="report-view__section">
                        <div className="report-view__inline-row">
                            <div className="report-view__inline-left">
                                <h3 className="report-view__label">{t.filterTitle} <span className="report-view__info-icon">ⓘ</span></h3>
                                <div className="report-view__filter-chips">
                                    {FILTER_CHIPS.map((chip) => (
                                        <button key={chip.label} type="button" className={`report-view__chip ${chip.active ? 'report-view__chip--active' : ''}`}>
                                            {chip.label} <span className="report-view__chip-count">{chip.count}</span>
                                        </button>
                                    ))}
                                </div>
                            </div>
                            <div className="report-view__inline-right">
                                <h4 className="report-view__sidebar-title">{t.filterTitle}</h4>
                                <p className="report-view__sidebar-text">{t.fileDownloadDesc?.slice(0, 150)}...</p>
                                <h4 className="report-view__sidebar-title" style={{ marginTop: '1rem' }}>{t.fileDownloadTitle}</h4>
                                <p className="report-view__sidebar-text">{t.fileDownloadDesc?.slice(0, 150)}...</p>
                            </div>
                        </div>
                    </section>

                    {/* Search — SEPARATE ROW */}
                    <section className="report-view__section">
                        <div className="report-view__filter-summary-row">
                            <p className="report-view__filter-summary">
                                {t.filteredSummary.replace('{owners}', '224').replace('{shares}', '2391')}
                            </p>
                            <div className="report-view__search">
                                <input type="text" placeholder={t.searchPlaceholder} value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="report-view__search-input" />
                                <span className="report-view__search-icon">🔍</span>
                            </div>
                        </div>
                    </section>

                    {/* Data table */}
                    <section className="report-view__section">
                        <table className="report-view__data-table">
                            <thead><tr>
                                <th>NIMI<br/>YKSILÖINTI&shy;TUNNUS<br/>SYNTYMÄAIKA</th>
                                <th>KATUOSOITE<br/>POSTIOSOITE<br/>KOTIKUNTA, MAA</th>
                                <th>ARVO-OSUUDEN NIMI, LYHENNE, ISIN</th>
                                <th>MÄÄRÄ</th>
                                <th>OSUUS OSAKKEIDEN KOKONAIS&shy;MÄÄRÄSTÄ</th>
                                <th>ÄÄNI-MÄÄRÄ</th>
                                <th>OSUUS KOKONAIS- ÄÄNI&shy;MÄÄRÄSTÄ</th>
                                <th>TILIN&shy;HOITAJA</th>
                                <th className="report-view__th--sortable">TILANNE&shy;PÄIVÄ <span className="report-view__sort-icon">↓</span></th>
                                <th>SEKTORI / KIELI</th>
                                <th>MAKSU&shy;TIEDOT</th>
                                <th>VEROTUS-TIEDOT</th>
                            </tr></thead>
                            <tbody>
                                {OWNER_ROWS.map((row, i) => (
                                    <tr key={i}>
                                        <td><strong>{row.name}</strong><br/>{row.id}<br/>{row.dob}</td>
                                        <td className="report-view__cell--pre">{row.address}</td>
                                        <td className="report-view__cell--pre report-view__cell--sm">{row.shares}</td>
                                        <td className="report-view__cell--pre report-view__cell--num">{row.amounts}</td>
                                        <td className="report-view__cell--pre report-view__cell--num">{row.pct}</td>
                                        <td className="report-view__cell--pre report-view__cell--num">{row.votes}</td>
                                        <td className="report-view__cell--pre report-view__cell--num">{row.votePct}</td>
                                        <td className="report-view__cell--pre report-view__cell--sm">{row.tilinhoitaja || '-'}</td>
                                        <td>{row.tilanne}</td>
                                        <td className="report-view__cell--pre report-view__cell--sm">{row.sektori}</td>
                                        <td className="report-view__cell--sm">{row.maksu}</td>
                                        <td>{row.vero}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </section>

                    {/* Pagination */}
                    <div className="report-view__pagination">
                        <span>{t.first}</span>
                        <button className="report-view__page-btn" type="button">‹</button>
                        {[1, 2, 3].map((p) => (
                            <button key={p} type="button" className={`report-view__page-num ${currentPage === p ? 'report-view__page-num--active' : ''}`} onClick={() => setCurrentPage(p)}>{String(p).padStart(2, '0')}</button>
                        ))}
                        <span>...</span>
                        <button className="report-view__page-num" type="button" onClick={() => setCurrentPage(14)}>14</button>
                        <button className="report-view__page-btn" type="button">›</button>
                        <span>{t.last}</span>
                    </div>

                    <div className="report-view__actions">
                        <Button variant="secondary" onClick={onBack}>{t.back}</Button>
                        <Button variant="primary" onClick={onSubscribe}>{t.toSubscription}</Button>
                    </div>
                </div>
            </div>
        </div>
    );
}
