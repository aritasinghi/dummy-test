/**
 * Application environment configuration.
 * All env vars must be prefixed with VITE_ to be exposed to the client.
 */
export const Env = {
    API_BASE_URL: import.meta.env.VITE_API_BASE_URL || '/api',
    APP_ENV: import.meta.env.VITE_APP_ENV || 'development',
    // TODO: Add OIDC config for OpenAM
    // OIDC_AUTHORITY: import.meta.env.VITE_OIDC_AUTHORITY || '',
    // OIDC_CLIENT_ID: import.meta.env.VITE_OIDC_CLIENT_ID || '',
    // OIDC_REDIRECT_URI: import.meta.env.VITE_OIDC_REDIRECT_URI || '',
} as const;
