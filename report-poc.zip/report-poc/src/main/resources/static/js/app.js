const statusFilter = document.getElementById("statusFilter");
const ordersBody = document.getElementById("ordersBody");
const downloadCsv = document.getElementById("downloadCsv");
const downloadExcel = document.getElementById("downloadExcel");
const downloadPdf = document.getElementById("downloadPdf");

function statusBadge(status) {
    const cls = "status-" + status.toLowerCase();
    return `<span class="status-badge ${cls}">${status}</span>`;
}

async function loadOrders() {
    const status = statusFilter.value;
    const url = "/api/report-orders" + (status ? `?status=${status}` : "");

    ordersBody.innerHTML = `<tr><td colspan="10" class="loading">Loading&hellip;</td></tr>`;

    try {
        const res = await fetch(url);
        const orders = await res.json();

        if (!orders.length) {
            ordersBody.innerHTML = `<tr><td colspan="10" class="loading">No orders found</td></tr>`;
            return;
        }

        ordersBody.innerHTML = orders.map(o => `
            <tr>
                <td>${o.orderId}</td>
                <td>${o.issuerName}</td>
                <td>${o.isin}</td>
                <td>${o.currency}</td>
                <td>${Number(o.nominalValue).toLocaleString()}</td>
                <td>${Number(o.totalIssued).toLocaleString()}</td>
                <td>${Number(o.bookEntries).toLocaleString()}</td>
                <td>${Number(o.pendingSettlement).toLocaleString()}</td>
                <td>${statusBadge(o.status)}</td>
                <td>${o.orderDate}</td>
            </tr>
        `).join("");
    } catch (err) {
        ordersBody.innerHTML = `<tr><td colspan="10" class="loading">Failed to load orders: ${err}</td></tr>`;
    }
}

function updateDownloadLinks() {
    const status = statusFilter.value;
    const query = status ? `?status=${status}` : "";
    downloadCsv.href = `/api/reports/download/csv${query}`;
    downloadExcel.href = `/api/reports/download/excel${query}`;
    downloadPdf.href = `/api/reports/download/pdf${query}`;
}

statusFilter.addEventListener("change", () => {
    loadOrders();
    updateDownloadLinks();
});

loadOrders();
updateDownloadLinks();
