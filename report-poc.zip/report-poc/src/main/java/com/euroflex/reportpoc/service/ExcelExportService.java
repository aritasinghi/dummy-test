package com.euroflex.reportpoc.service;

import com.euroflex.reportpoc.model.ReportOrder;
import com.euroflex.reportpoc.service.style.ExcelStyleFactory;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.OutputStream;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Streams report orders to an .xlsx file using Apache POI's SXSSFWorkbook.
 * windowSize(100) keeps only 100 rows in memory at a time and flushes the
 * rest to a temp file on disk, so this scales to hundreds of thousands
 * of rows without OutOfMemoryError.
 */
@Service
public class ExcelExportService {

    private static final String[] HEADERS = {
            "Order ID", "Issuer Name", "ISIN", "Currency", "Nominal Value",
            "Total Issued", "Book Entries", "Pending Settlement", "Status", "Order Date"
    };

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ISO_LOCAL_DATE;

    public void export(OutputStream outputStream, List<ReportOrder> orders) throws IOException {
        try (SXSSFWorkbook workbook = new SXSSFWorkbook(100)) {
            workbook.setCompressTempFiles(true);
            ExcelStyleFactory styles = new ExcelStyleFactory(workbook);

            SXSSFSheet sheet = workbook.createSheet("Report Orders");
            sheet.trackAllColumnsForAutoSizing();

            int rowNum = 0;

            // Title row
            Row titleRow = sheet.createRow(rowNum++);
            Cell titleCell = titleRow.createCell(0);
            titleCell.setCellValue("Euroflex Report Orders");
            titleCell.setCellStyle(styles.title());
            rowNum++; // blank spacer row

            // Header row
            Row headerRow = sheet.createRow(rowNum++);
            for (int col = 0; col < HEADERS.length; col++) {
                Cell cell = headerRow.createCell(col);
                cell.setCellValue(HEADERS[col]);
                cell.setCellStyle(styles.header());
            }

            // Data rows
            boolean alternate = false;
            for (ReportOrder order : orders) {
                Row row = sheet.createRow(rowNum++);

                setCell(row, 0, order.getOrderId(), styles.dataRow(alternate));
                setCell(row, 1, order.getIssuerName(), styles.dataRow(alternate));
                setCell(row, 2, order.getIsin(), styles.dataRow(alternate));
                setCell(row, 3, order.getCurrency(), styles.dataRow(alternate));

                Cell nominalCell = row.createCell(4);
                nominalCell.setCellValue(order.getNominalValue().doubleValue());
                nominalCell.setCellStyle(styles.currency());

                setCell(row, 5, String.valueOf(order.getTotalIssued()), styles.dataRow(alternate));
                setCell(row, 6, String.valueOf(order.getBookEntries()), styles.dataRow(alternate));
                setCell(row, 7, String.valueOf(order.getPendingSettlement()), styles.dataRow(alternate));

                Cell statusCell = row.createCell(8);
                statusCell.setCellValue(order.getStatus());
                statusCell.setCellStyle(styles.statusFor(order.getStatus()));

                setCell(row, 9, order.getOrderDate().format(DATE_FMT), styles.dataRow(alternate));

                alternate = !alternate;
            }

            for (int col = 0; col < HEADERS.length; col++) {
                sheet.autoSizeColumn(col);
            }

            workbook.write(outputStream);
            workbook.dispose(); // clean up temp files backing the streaming workbook
        }
    }

    private void setCell(Row row, int col, String value, org.apache.poi.ss.usermodel.CellStyle style) {
        Cell cell = row.createCell(col);
        cell.setCellValue(value);
        cell.setCellStyle(style);
    }
}
