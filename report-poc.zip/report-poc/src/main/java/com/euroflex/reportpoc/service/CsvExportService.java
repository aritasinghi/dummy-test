package com.euroflex.reportpoc.service;

import com.euroflex.reportpoc.model.ReportOrder;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Streams report orders to CSV using Apache Commons CSV.
 * Writes directly to the response OutputStream, so memory use stays flat
 * regardless of row count.
 */
@Service
public class CsvExportService {

    private static final String[] HEADERS = {
            "Order ID", "Issuer Name", "ISIN", "Currency", "Nominal Value",
            "Total Issued", "Book Entries", "Pending Settlement", "Status", "Order Date"
    };

    public void export(OutputStream outputStream, List<ReportOrder> orders) throws IOException {
        try (OutputStreamWriter writer = new OutputStreamWriter(outputStream, StandardCharsets.UTF_8);
             CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT.builder()
                     .setHeader(HEADERS)
                     .build())) {

            for (ReportOrder order : orders) {
                printer.printRecord(
                        order.getOrderId(),
                        order.getIssuerName(),
                        order.getIsin(),
                        order.getCurrency(),
                        order.getNominalValue(),
                        order.getTotalIssued(),
                        order.getBookEntries(),
                        order.getPendingSettlement(),
                        order.getStatus(),
                        order.getOrderDate()
                );
            }
            printer.flush();
        }
    }
}
