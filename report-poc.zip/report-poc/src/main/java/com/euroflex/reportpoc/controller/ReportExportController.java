package com.euroflex.reportpoc.controller;

import com.euroflex.reportpoc.model.ReportOrder;
import com.euroflex.reportpoc.service.CsvExportService;
import com.euroflex.reportpoc.service.ExcelExportService;
import com.euroflex.reportpoc.service.PdfExportService;
import com.euroflex.reportpoc.service.ReportOrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/reports/download")
@Tag(name = "Report Export", description = "Generate and download report orders as CSV, Excel (.xlsx) or PDF")
public class ReportExportController {

    private final ReportOrderService reportOrderService;
    private final CsvExportService csvExportService;
    private final ExcelExportService excelExportService;
    private final PdfExportService pdfExportService;

    public ReportExportController(ReportOrderService reportOrderService,
                                   CsvExportService csvExportService,
                                   ExcelExportService excelExportService,
                                   PdfExportService pdfExportService) {
        this.reportOrderService = reportOrderService;
        this.csvExportService = csvExportService;
        this.excelExportService = excelExportService;
        this.pdfExportService = pdfExportService;
    }

    @GetMapping(value = "/csv", produces = "text/csv")
    @Operation(summary = "Download report orders as CSV",
            description = "Streams rows using Apache Commons CSV. Suitable for very large datasets.")
    @ApiResponse(responseCode = "200", description = "CSV file",
            content = @Content(mediaType = "text/csv"))
    public void downloadCsv(
            @Parameter(description = "Filter by status: ACTIVE, PENDING, SETTLED") @RequestParam(required = false) String status,
            HttpServletResponse response) throws IOException {

        List<ReportOrder> orders = reportOrderService.getOrdersByStatus(status);

        response.setContentType("text/csv");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName("report-orders", "csv") + "\"");

        csvExportService.export(response.getOutputStream(), orders);
    }

    @GetMapping(value = "/excel", produces = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    @Operation(summary = "Download report orders as Excel (.xlsx)",
            description = "Streams rows using Apache POI SXSSFWorkbook (windowed, low memory) with styled headers, "
                    + "alternating row colors and a status color badge column.")
    @ApiResponse(responseCode = "200", description = "XLSX file",
            content = @Content(mediaType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
    public void downloadExcel(
            @Parameter(description = "Filter by status: ACTIVE, PENDING, SETTLED") @RequestParam(required = false) String status,
            HttpServletResponse response) throws IOException {

        List<ReportOrder> orders = reportOrderService.getOrdersByStatus(status);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName("report-orders", "xlsx") + "\"");

        excelExportService.export(response.getOutputStream(), orders);
    }

    @GetMapping(value = "/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
    @Operation(summary = "Download report orders as PDF",
            description = "Renders a styled, paginated table using Apache PDFBox directly (landscape A4, "
                    + "branded header band, status color coding, page footer). Recommended for filtered/summary "
                    + "views rather than very large unfiltered exports.")
    @ApiResponse(responseCode = "200", description = "PDF file",
            content = @Content(mediaType = MediaType.APPLICATION_PDF_VALUE))
    public void downloadPdf(
            @Parameter(description = "Filter by status: ACTIVE, PENDING, SETTLED") @RequestParam(required = false) String status,
            HttpServletResponse response) throws IOException {

        List<ReportOrder> orders = reportOrderService.getOrdersByStatus(status);

        response.setContentType(MediaType.APPLICATION_PDF_VALUE);
        response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName("report-orders", "pdf") + "\"");

        pdfExportService.export(response.getOutputStream(), orders);
    }

    private String fileName(String base, String extension) {
        return base + "-" + LocalDate.now() + "." + extension;
    }
}
