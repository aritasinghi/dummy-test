package com.euroflex.reportpoc.service.style;

import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;

import java.awt.Color;

/**
 * Central place for PDF look-and-feel: fonts, colors, spacing.
 * Mirrors the role ExcelStyleFactory plays for the Excel export, so the
 * two exports read from a single "design system" instead of duplicating
 * magic numbers across services.
 */
public final class PdfStyle {

    private PdfStyle() {
    }

    // Page layout
    public static final float PAGE_MARGIN = 40f;
    public static final float ROW_HEIGHT = 20f;
    public static final float TITLE_FONT_SIZE = 18f;
    public static final float HEADER_FONT_SIZE = 9f;
    public static final float CELL_FONT_SIZE = 8.5f;
    public static final float FOOTER_FONT_SIZE = 8f;

    // Colors
    public static final Color COLOR_BRAND_DARK_BLUE = new Color(20, 40, 90);
    public static final Color COLOR_HEADER_TEXT = Color.WHITE;
    public static final Color COLOR_ROW_ALT = new Color(238, 242, 248);
    public static final Color COLOR_ROW_DEFAULT = Color.WHITE;
    public static final Color COLOR_BORDER = new Color(200, 200, 200);
    public static final Color COLOR_TEXT = new Color(30, 30, 30);

    public static final Color COLOR_STATUS_ACTIVE = new Color(210, 240, 210);
    public static final Color COLOR_STATUS_PENDING = new Color(250, 230, 200);
    public static final Color COLOR_STATUS_SETTLED = new Color(210, 225, 250);

    // Fonts (PDFBox 3 standard 14 fonts)
    public static final PDFont FONT_TITLE = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
    public static final PDFont FONT_HEADER = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
    public static final PDFont FONT_CELL = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
    public static final PDFont FONT_CELL_BOLD = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
    public static final PDFont FONT_FOOTER = new PDType1Font(Standard14Fonts.FontName.HELVETICA_OBLIQUE);

    public static Color statusColor(String status) {
        if (status == null) return COLOR_ROW_DEFAULT;
        return switch (status.toUpperCase()) {
            case "ACTIVE" -> COLOR_STATUS_ACTIVE;
            case "PENDING" -> COLOR_STATUS_PENDING;
            case "SETTLED" -> COLOR_STATUS_SETTLED;
            default -> COLOR_ROW_DEFAULT;
        };
    }
}
