package com.euroflex.reportpoc.service;

import com.euroflex.reportpoc.model.ReportOrder;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Stands in for the real repository / JPA layer.
 * In the real ife backend, replace this with a Spring Data repository
 * (e.g. issuerRepository.findAllStream()) and keep the same method signatures
 * so the export services below don't need to change.
 */
@Service
public class ReportOrderService {

    private final List<ReportOrder> orders = new ArrayList<>();

    public ReportOrderService() {
        seedSampleData();
    }

    public List<ReportOrder> getAllOrders() {
        return orders;
    }

    public List<ReportOrder> getOrdersByStatus(String status) {
        if (status == null || status.isBlank()) {
            return orders;
        }
        return orders.stream()
                .filter(o -> o.getStatus().equalsIgnoreCase(status))
                .toList();
    }

    public Optional<ReportOrder> getOrderById(String orderId) {
        return orders.stream().filter(o -> o.getOrderId().equals(orderId)).findFirst();
    }

    private void seedSampleData() {
        Object[][] data = {
                {"ORD-1001", "Nordea Bank Abp", "FI4000297767", "EUR", "1000", 5000000L, 4987000L, 13000L, "ACTIVE"},
                {"ORD-1002", "Sampo Oyj", "FI0009003305", "EUR", "500", 3200000L, 3198500L, 1500L, "ACTIVE"},
                {"ORD-1003", "Kone Corporation", "FI0009013403", "EUR", "250", 1800000L, 1800000L, 0L, "SETTLED"},
                {"ORD-1004", "UPM-Kymmene Oyj", "FI0009005987", "EUR", "750", 2500000L, 2491000L, 9000L, "ACTIVE"},
                {"ORD-1005", "Fortum Oyj", "FI0009007132", "EUR", "100", 890000L, 885000L, 5000L, "PENDING"},
                {"ORD-1006", "Elisa Oyj", "FI0009007884", "EUR", "1000", 4100000L, 4100000L, 0L, "SETTLED"},
                {"ORD-1007", "Wartsila Oyj", "FI0009003727", "EUR", "500", 2200000L, 2150000L, 50000L, "ACTIVE"},
                {"ORD-1008", "Neste Oyj", "FI0009013296", "EUR", "250", 3300000L, 3300000L, 0L, "SETTLED"},
                {"ORD-1009", "Stora Enso Oyj", "FI0009005961", "EUR", "500", 1750000L, 1690000L, 60000L, "ACTIVE"},
                {"ORD-1010", "Metso Oyj", "FI4000524125", "EUR", "100", 990000L, 960000L, 30000L, "PENDING"},
                {"ORD-1011", "Orion Oyj", "FI0009014377", "EUR", "1000", 1420000L, 1420000L, 0L, "SETTLED"},
                {"ORD-1012", "Kesko Oyj", "FI0009000202", "EUR", "500", 1980000L, 1955000L, 25000L, "ACTIVE"},
        };

        long day = 0;
        for (Object[] row : data) {
            orders.add(new ReportOrder(
                    (String) row[0],
                    (String) row[1],
                    (String) row[2],
                    (String) row[3],
                    new BigDecimal((String) row[4]),
                    (Long) row[5],
                    (Long) row[6],
                    (Long) row[7],
                    (String) row[8],
                    LocalDate.now().minusDays(day++)
            ));
        }
    }
}
