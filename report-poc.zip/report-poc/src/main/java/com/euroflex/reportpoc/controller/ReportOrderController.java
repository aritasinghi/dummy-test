package com.euroflex.reportpoc.controller;

import com.euroflex.reportpoc.model.ReportOrder;
import com.euroflex.reportpoc.service.ReportOrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/report-orders")
@Tag(name = "Report Orders", description = "Underlying order data used to build the CSV / Excel / PDF reports")
public class ReportOrderController {

    private final ReportOrderService reportOrderService;

    public ReportOrderController(ReportOrderService reportOrderService) {
        this.reportOrderService = reportOrderService;
    }

    @GetMapping
    @Operation(summary = "List all report orders", description = "Returns every report order, optionally filtered by status")
    public List<ReportOrder> getOrders(
            @Parameter(description = "Filter by status: ACTIVE, PENDING, SETTLED")
            @RequestParam(required = false) String status) {
        return reportOrderService.getOrdersByStatus(status);
    }

    @GetMapping("/{orderId}")
    @Operation(summary = "Get a single report order by ID")
    public ResponseEntity<ReportOrder> getOrder(@PathVariable String orderId) {
        return reportOrderService.getOrderById(orderId)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
