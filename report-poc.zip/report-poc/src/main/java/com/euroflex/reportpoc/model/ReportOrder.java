package com.euroflex.reportpoc.model;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Represents a single report / book-entry order row.
 * Mirrors the issuer + book entry data used across the ife-ui reporting screens.
 */
public class ReportOrder {

    private String orderId;
    private String issuerName;
    private String isin;
    private String currency;
    private BigDecimal nominalValue;
    private long totalIssued;
    private long bookEntries;
    private long pendingSettlement;
    private String status; // ACTIVE, PENDING, SETTLED
    private LocalDate orderDate;

    public ReportOrder() {
    }

    public ReportOrder(String orderId, String issuerName, String isin, String currency,
                        BigDecimal nominalValue, long totalIssued, long bookEntries,
                        long pendingSettlement, String status, LocalDate orderDate) {
        this.orderId = orderId;
        this.issuerName = issuerName;
        this.isin = isin;
        this.currency = currency;
        this.nominalValue = nominalValue;
        this.totalIssued = totalIssued;
        this.bookEntries = bookEntries;
        this.pendingSettlement = pendingSettlement;
        this.status = status;
        this.orderDate = orderDate;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getIssuerName() {
        return issuerName;
    }

    public void setIssuerName(String issuerName) {
        this.issuerName = issuerName;
    }

    public String getIsin() {
        return isin;
    }

    public void setIsin(String isin) {
        this.isin = isin;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public BigDecimal getNominalValue() {
        return nominalValue;
    }

    public void setNominalValue(BigDecimal nominalValue) {
        this.nominalValue = nominalValue;
    }

    public long getTotalIssued() {
        return totalIssued;
    }

    public void setTotalIssued(long totalIssued) {
        this.totalIssued = totalIssued;
    }

    public long getBookEntries() {
        return bookEntries;
    }

    public void setBookEntries(long bookEntries) {
        this.bookEntries = bookEntries;
    }

    public long getPendingSettlement() {
        return pendingSettlement;
    }

    public void setPendingSettlement(long pendingSettlement) {
        this.pendingSettlement = pendingSettlement;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDate orderDate) {
        this.orderDate = orderDate;
    }
}
