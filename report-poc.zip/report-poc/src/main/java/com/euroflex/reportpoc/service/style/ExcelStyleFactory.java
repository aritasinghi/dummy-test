package com.euroflex.reportpoc.service.style;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

/**
 * Centralised styling for the Excel export so every sheet in the app
 * looks consistent. Keep all POI CellStyle / Font creation here rather
 * than scattering it through export services.
 */
public class ExcelStyleFactory {

    private final CellStyle headerStyle;
    private final CellStyle dataStyle;
    private final CellStyle dataStyleAlt;
    private final CellStyle currencyStyle;
    private final CellStyle statusActiveStyle;
    private final CellStyle statusPendingStyle;
    private final CellStyle statusSettledStyle;
    private final CellStyle titleStyle;

    public ExcelStyleFactory(SXSSFWorkbook workbook) {
        this.headerStyle = buildHeaderStyle(workbook);
        this.dataStyle = buildDataStyle(workbook, IndexedColors.WHITE.getIndex());
        this.dataStyleAlt = buildDataStyle(workbook, IndexedColors.GREY_25_PERCENT.getIndex());
        this.currencyStyle = buildCurrencyStyle(workbook);
        this.statusActiveStyle = buildStatusStyle(workbook, IndexedColors.LIGHT_GREEN.getIndex());
        this.statusPendingStyle = buildStatusStyle(workbook, IndexedColors.LIGHT_ORANGE.getIndex());
        this.statusSettledStyle = buildStatusStyle(workbook, IndexedColors.PALE_BLUE.getIndex());
        this.titleStyle = buildTitleStyle(workbook);
    }

    private CellStyle buildTitleStyle(SXSSFWorkbook workbook) {
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 16);
        font.setColor(IndexedColors.DARK_BLUE.getIndex());
        CellStyle style = workbook.createCellStyle();
        style.setFont(font);
        return style;
    }

    private CellStyle buildHeaderStyle(SXSSFWorkbook workbook) {
        Font font = workbook.createFont();
        font.setBold(true);
        font.setColor(IndexedColors.WHITE.getIndex());
        font.setFontHeightInPoints((short) 11);

        CellStyle style = workbook.createCellStyle();
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        applyThinBorder(style);
        return style;
    }

    private CellStyle buildDataStyle(SXSSFWorkbook workbook, short bgColor) {
        CellStyle style = workbook.createCellStyle();
        style.setFillForegroundColor(bgColor);
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        applyThinBorder(style);
        return style;
    }

    private CellStyle buildCurrencyStyle(SXSSFWorkbook workbook) {
        CellStyle style = workbook.createCellStyle();
        DataFormat format = workbook.createDataFormat();
        style.setDataFormat(format.getFormat("#,##0.00"));
        applyThinBorder(style);
        return style;
    }

    private CellStyle buildStatusStyle(SXSSFWorkbook workbook, short bgColor) {
        Font font = workbook.createFont();
        font.setBold(true);
        CellStyle style = workbook.createCellStyle();
        style.setFont(font);
        style.setFillForegroundColor(bgColor);
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setAlignment(HorizontalAlignment.CENTER);
        applyThinBorder(style);
        return style;
    }

    private void applyThinBorder(CellStyle style) {
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
    }

    public CellStyle header() {
        return headerStyle;
    }

    public CellStyle title() {
        return titleStyle;
    }

    public CellStyle dataRow(boolean alternate) {
        return alternate ? dataStyleAlt : dataStyle;
    }

    public CellStyle currency() {
        return currencyStyle;
    }

    public CellStyle statusFor(String status) {
        if (status == null) return dataStyle;
        return switch (status.toUpperCase()) {
            case "ACTIVE" -> statusActiveStyle;
            case "PENDING" -> statusPendingStyle;
            case "SETTLED" -> statusSettledStyle;
            default -> dataStyle;
        };
    }
}
