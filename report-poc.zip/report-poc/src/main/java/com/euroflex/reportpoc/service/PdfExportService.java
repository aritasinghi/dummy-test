package com.euroflex.reportpoc.service;

import com.euroflex.reportpoc.model.ReportOrder;
import com.euroflex.reportpoc.service.style.PdfStyle;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.IOException;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Renders report orders as a styled, paginated PDF table using Apache PDFBox directly
 * (no HTML/CSS templating engine, no extra non-Apache dependency).
 *
 * Note: PDF generation is CPU/memory heavier than CSV or streaming Excel, so in the
 * real backend this should only be offered for filtered/summary views
 * (see the "Suodatus" filter checkbox pattern discussed earlier) — not unbounded
 * exports of hundreds of thousands of rows.
 */
@Service
public class PdfExportService {

    private static final String[] HEADERS = {
            "Order ID", "Issuer", "ISIN", "Ccy", "Nominal", "Total Issued", "Book Entries", "Pending", "Status", "Date"
    };

    // Relative column widths, must sum to 1.0
    private static final float[] COLUMN_WEIGHTS = {0.09f, 0.16f, 0.13f, 0.05f, 0.09f, 0.11f, 0.11f, 0.09f, 0.08f, 0.09f};

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ISO_LOCAL_DATE;

    public void export(OutputStream outputStream, List<ReportOrder> orders) throws IOException {
        try (PDDocument document = new PDDocument()) {
            float pageWidth = PDRectangle.A4.getHeight(); // landscape
            float pageHeight = PDRectangle.A4.getWidth();
            float tableWidth = pageWidth - 2 * PdfStyle.PAGE_MARGIN;

            PageCursor cursor = newPage(document, pageWidth, pageHeight);
            drawTitle(cursor, "Euroflex Report Orders");
            drawTableHeader(cursor, tableWidth);

            int rowsOnPage = 0;
            for (ReportOrder order : orders) {
                if (cursor.y < PdfStyle.PAGE_MARGIN + PdfStyle.ROW_HEIGHT * 2) {
                    cursor.stream.close();
                    cursor = newPage(document, pageWidth, pageHeight);
                    drawTableHeader(cursor, tableWidth);
                    rowsOnPage = 0;
                }
                drawRow(cursor, tableWidth, order, rowsOnPage % 2 == 1);
                rowsOnPage++;
            }
            cursor.stream.close();

            drawFooterOnAllPages(document, orders.size());

            document.save(outputStream);
        }
    }

    // --- internal rendering helpers -------------------------------------------------

    /** Mutable per-page drawing state: current content stream and vertical cursor. */
    private static final class PageCursor {
        final PDPage page;
        final PDPageContentStream stream;
        final float startX;
        float y;

        PageCursor(PDPage page, PDPageContentStream stream, float startX, float y) {
            this.page = page;
            this.stream = stream;
            this.startX = startX;
            this.y = y;
        }
    }

    private PageCursor newPage(PDDocument document, float pageWidth, float pageHeight) throws IOException {
        PDPage page = new PDPage(new PDRectangle(pageWidth, pageHeight));
        document.addPage(page);
        PDPageContentStream stream = new PDPageContentStream(document, page);
        float startY = pageHeight - PdfStyle.PAGE_MARGIN;
        return new PageCursor(page, stream, PdfStyle.PAGE_MARGIN, startY);
    }

    private void drawTitle(PageCursor cursor, String title) throws IOException {
        cursor.stream.beginText();
        cursor.stream.setFont(PdfStyle.FONT_TITLE, PdfStyle.TITLE_FONT_SIZE);
        cursor.stream.setNonStrokingColor(PdfStyle.COLOR_BRAND_DARK_BLUE);
        cursor.stream.newLineAtOffset(cursor.startX, cursor.y - PdfStyle.TITLE_FONT_SIZE);
        cursor.stream.showText(title);
        cursor.stream.endText();

        String generatedAt = "Generated: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        cursor.stream.beginText();
        cursor.stream.setFont(PdfStyle.FONT_FOOTER, PdfStyle.FOOTER_FONT_SIZE);
        cursor.stream.setNonStrokingColor(PdfStyle.COLOR_TEXT);
        cursor.stream.newLineAtOffset(cursor.startX, cursor.y - PdfStyle.TITLE_FONT_SIZE - 14);
        cursor.stream.showText(generatedAt);
        cursor.stream.endText();

        cursor.y -= (PdfStyle.TITLE_FONT_SIZE + 30);
    }

    private void drawTableHeader(PageCursor cursor, float tableWidth) throws IOException {
        float rowY = cursor.y;
        drawRowBackground(cursor, tableWidth, rowY, PdfStyle.COLOR_BRAND_DARK_BLUE);
        drawRowCells(cursor, tableWidth, rowY, HEADERS, PdfStyle.FONT_HEADER, PdfStyle.HEADER_FONT_SIZE, PdfStyle.COLOR_HEADER_TEXT);
        cursor.y = rowY - PdfStyle.ROW_HEIGHT;
    }

    private void drawRow(PageCursor cursor, float tableWidth, ReportOrder order, boolean alternate) throws IOException {
        String[] values = {
                order.getOrderId(),
                truncate(order.getIssuerName(), 22),
                order.getIsin(),
                order.getCurrency(),
                order.getNominalValue().toPlainString(),
                String.valueOf(order.getTotalIssued()),
                String.valueOf(order.getBookEntries()),
                String.valueOf(order.getPendingSettlement()),
                order.getStatus(),
                order.getOrderDate().format(DATE_FMT)
        };

        float rowY = cursor.y;
        Color bg = alternate ? PdfStyle.COLOR_ROW_ALT : PdfStyle.COLOR_ROW_DEFAULT;
        drawRowBackground(cursor, tableWidth, rowY, bg);
        drawStatusCellBackground(cursor, tableWidth, rowY, order.getStatus());
        drawRowCells(cursor, tableWidth, rowY, values, PdfStyle.FONT_CELL, PdfStyle.CELL_FONT_SIZE, PdfStyle.COLOR_TEXT);
        cursor.y = rowY - PdfStyle.ROW_HEIGHT;
    }

    private void drawRowBackground(PageCursor cursor, float tableWidth, float rowY, Color color) throws IOException {
        cursor.stream.setNonStrokingColor(color);
        cursor.stream.addRect(cursor.startX, rowY - PdfStyle.ROW_HEIGHT, tableWidth, PdfStyle.ROW_HEIGHT);
        cursor.stream.fill();
        cursor.stream.setStrokingColor(PdfStyle.COLOR_BORDER);
        cursor.stream.setLineWidth(0.5f);
        cursor.stream.addRect(cursor.startX, rowY - PdfStyle.ROW_HEIGHT, tableWidth, PdfStyle.ROW_HEIGHT);
        cursor.stream.stroke();
    }

    private void drawStatusCellBackground(PageCursor cursor, float tableWidth, float rowY, String status) throws IOException {
        float x = cursor.startX;
        int statusColIndex = HEADERS.length - 2; // "Status" column
        for (int i = 0; i < statusColIndex; i++) {
            x += COLUMN_WEIGHTS[i] * tableWidth;
        }
        float colWidth = COLUMN_WEIGHTS[statusColIndex] * tableWidth;
        cursor.stream.setNonStrokingColor(PdfStyle.statusColor(status));
        cursor.stream.addRect(x, rowY - PdfStyle.ROW_HEIGHT, colWidth, PdfStyle.ROW_HEIGHT);
        cursor.stream.fill();
    }

    private void drawRowCells(PageCursor cursor, float tableWidth, float rowY, String[] values,
                               PDFont font, float fontSize, Color textColor) throws IOException {
        float x = cursor.startX;
        cursor.stream.setNonStrokingColor(textColor);
        for (int i = 0; i < values.length; i++) {
            float colWidth = COLUMN_WEIGHTS[i] * tableWidth;
            String text = values[i] == null ? "" : values[i];
            cursor.stream.beginText();
            cursor.stream.setFont(font, fontSize);
            cursor.stream.newLineAtOffset(x + 4, rowY - PdfStyle.ROW_HEIGHT + 6);
            cursor.stream.showText(text);
            cursor.stream.endText();
            x += colWidth;
        }
    }

    private void drawFooterOnAllPages(PDDocument document, int totalRows) throws IOException {
        int pageCount = document.getNumberOfPages();
        for (int i = 0; i < pageCount; i++) {
            PDPage page = document.getPage(i);
            try (PDPageContentStream stream = new PDPageContentStream(
                    document, page, PDPageContentStream.AppendMode.APPEND, true)) {
                stream.beginText();
                stream.setFont(PdfStyle.FONT_FOOTER, PdfStyle.FOOTER_FONT_SIZE);
                stream.setNonStrokingColor(PdfStyle.COLOR_TEXT);
                stream.newLineAtOffset(PdfStyle.PAGE_MARGIN, PdfStyle.PAGE_MARGIN / 2);
                stream.showText("Page " + (i + 1) + " of " + pageCount + "  |  Total rows: " + totalRows
                        + "  |  Euroflex / ife reporting POC");
                stream.endText();
            }
        }
    }

    private String truncate(String value, int maxLen) {
        if (value == null) return "";
        return value.length() <= maxLen ? value : value.substring(0, maxLen - 1) + "…";
    }
}
