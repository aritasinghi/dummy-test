package com.euroflex.reportpoc.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI reportPocOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Report Order Export POC")
                        .description("POC backend for generating PDF, Excel (.xlsx) and CSV reports "
                                + "from report order data, using Apache POI, Apache PDFBox and Apache Commons CSV. "
                                + "Use the /api/reports/download/{format} endpoints below and click "
                                + "'Try it out' -> 'Execute' -> 'Download file' to test each export.")
                        .version("1.0.0")
                        .contact(new Contact().name("Euroflex / ife reporting team")));
    }
}
