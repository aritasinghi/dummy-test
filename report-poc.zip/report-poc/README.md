# Report Order Export POC

Spring Boot backend that generates **CSV**, **Excel (.xlsx)**, and **PDF** reports
from report order data, using the Apache Foundation stack:

| Format | Library | License |
|---|---|---|
| CSV | Apache Commons CSV 1.10.0 | Apache 2.0 |
| Excel | Apache POI 5.2.5 (`SXSSFWorkbook`, streaming) | Apache 2.0 |
| PDF | Apache PDFBox 3.0.1 (direct drawing, no HTML/CSS engine) | Apache 2.0 |

## Requirements

- Java 17+
- Maven 3.8+ (internet access to Maven Central to resolve dependencies on first build)

## Run it

```bash
cd report-poc
mvn spring-boot:run
```

The app starts on **http://localhost:8080**.

## What you get

- **Test UI**: `http://localhost:8080/` — a small styled page that lists report orders
  and lets you filter by status and download CSV/Excel/PDF directly.
- **Swagger UI**: `http://localhost:8080/swagger-ui.html` — every endpoint documented,
  with "Try it out" so you can execute a request and download the resulting file
  straight from the browser.
- **OpenAPI spec**: `http://localhost:8080/v3/api-docs`

## Endpoints

| Method | Path | Description |
|---|---|---|
| GET | `/api/report-orders` | List orders (optional `?status=ACTIVE\|PENDING\|SETTLED`) |
| GET | `/api/report-orders/{orderId}` | Get a single order |
| GET | `/api/reports/download/csv` | Download CSV |
| GET | `/api/reports/download/excel` | Download XLSX |
| GET | `/api/reports/download/pdf` | Download PDF |

All three download endpoints accept the same optional `status` query param.

## Project layout

```
src/main/java/com/euroflex/reportpoc/
  model/ReportOrder.java              # domain POJO
  service/ReportOrderService.java     # sample data — swap for a JPA repository in prod
  service/CsvExportService.java       # Apache Commons CSV streaming writer
  service/ExcelExportService.java     # Apache POI SXSSFWorkbook streaming writer
  service/PdfExportService.java       # Apache PDFBox paginated table renderer
  service/style/ExcelStyleFactory.java  # centralized POI CellStyle / Font definitions
  service/style/PdfStyle.java           # centralized PDFBox fonts / colors / layout constants
  controller/ReportOrderController.java # JSON listing endpoints
  controller/ReportExportController.java# download endpoints (Swagger annotated)
  config/OpenApiConfig.java             # Swagger/OpenAPI metadata
src/main/resources/
  application.yml
  static/index.html, css/style.css, js/app.js   # minimal test frontend
```

## Wiring into your real `ife` backend

`ReportOrderService` is the only class that stands in for real data access.
To connect this to your actual database:

1. Replace the in-memory list in `ReportOrderService` with a Spring Data
   repository call (e.g. `issuerRepository.findAllStream()` per our earlier
   discussion on streaming large result sets).
2. Keep the method signatures (`getAllOrders()`, `getOrdersByStatus(status)`,
   `getOrderById(id)`) so `CsvExportService`, `ExcelExportService`, and
   `PdfExportService` don't need any changes.
3. For very large exports (50k+ rows), keep CSV and Excel as the primary
   options — PDF is deliberately drawn with PDFBox at a fixed row height and
   should be reserved for filtered/summary views (same "Suodatus" pattern
   from the `ife-ui` download modal).

## Notes on scale

- CSV and Excel write directly to the HTTP response `OutputStream` — no
  in-memory list of formatted rows is built, so memory stays flat as row
  count grows.
- Excel uses `SXSSFWorkbook(100)`, keeping only 100 rows resident in memory
  and flushing the rest to a temp file, then `workbook.dispose()` cleans it
  up after writing.
- PDF is fully in-memory per `PDDocument` — fine for hundreds/low-thousands
  of rows, not recommended unfiltered for 100k+ rows.
