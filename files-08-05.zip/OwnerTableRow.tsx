// ─── OwnerTableRow ────────────────────────────────────────────────────────────
// Renders a single owner row. Only columns that are active for the current
// report type are rendered — no ghost/placeholder cells.

import { Table, TextLink } from '@efi/efi-ui-components';
import type { OwnerRow, ColVisibility } from './types';
import type { Translations } from '@/locales';

type T = Translations['reportView'];

interface Props {
    row:  OwnerRow;
    cols: ColVisibility;
    t:    T;
}

export function OwnerTableRow({ row, cols, t }: Props) {
    if (row.isJointSubRow) {
        return (
            <Table.Row className="rv__row--joint-sub">
                {/* Name — always col 1 */}
                <Table.BodyCell>
                    <div className="rv__name-cell">
                        <div className="rv__name-row">
                            <span className="rv__flag">🔗</span>
                            <span className="rv__sub-label">{t.jointSubLabel}</span>
                        </div>
                        <div className="rv__joint-parent">
                            {t.jointParentLabel}: <TextLink href="#">{row.jointParentName}</TextLink>
                        </div>
                        <span className="rv__ssn-text">{row.personalId}</span>
                        {row.dateOfBirth && <span className="rv__ssn-text">{row.dateOfBirth}</span>}
                    </div>
                </Table.BodyCell>
                {cols.addr  && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.city  && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {/* Book-entry type — always */}
                <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>
                {cols.custodianName && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {/* Amount — always */}
                <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>
                {cols.percentageCombined    && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.numberOfVotes  && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.votingRightsPercentage && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.date   && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.sector && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.payment && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.tax    && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
            </Table.Row>
        );
    }

    return (
        <Table.Row>
            {/* ── Col 1: Name / SSN / DOB / Restriction — always ── */}
            <Table.BodyCell>
                <div className="rv__name-cell">
                    <div className="rv__name-row">
                        {row.isCustodianBank    && <span className="rv__flag" title={t.flagNomineeReg}>🏦</span>}
                        {row.isCompany && !row.isCustodianBank && <span className="rv__flag" title={t.flagNomineeReg}>🏢</span>}
                        <TextLink href="#"><strong>{row.fullName}</strong></TextLink>
                        {row.isNonDisclosure && <span className="rv__flag" title={t.flagNonDisclosure}>🚫</span>}
                        {row.isNomineeRegistered && !row.isCustodianBank && <span className="rv__flag" title={t.flagNominee}>📋</span>}
                    </div>
                    <span className="rv__ssn-text">{row.personalId}</span>
                    {row.dateOfBirth && <span className="rv__ssn-text">{row.dateOfBirth}</span>}
                    {row.customerRestriction && (
                        <span className="rv__restriction">{t.customerRestriction}: {row.customerRestriction}</span>
                    )}
                    {row.isJointOwner && row.jointOwners && (
                        <div className="rv__joint-section">
                            <span className="rv__flag">🔗</span>
                            <span className="rv__joint-label">Yhteisomistus:</span>
                            {row.jointOwners.map((o, i) => (
                                <span key={i} className="rv__cell-sm">
                                    {o.isLinkable ? <TextLink href="#">{o.name}</TextLink> : o.name}
                                    {i < (row.jointOwners?.length ?? 0) - 1 && ', '}
                                </span>
                            ))}
                        </div>
                    )}
                </div>
            </Table.BodyCell>

            {/* ── Col 2: Street address (statutory, full) ── */}
            {cols.addr && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">
                        {row.streetAddress}<br />{row.postAddress}<br />{row.residenceCountry}
                    </span>
                </Table.BodyCell>
            )}

            {/* ── Col 3: Municipality only (AGM) ── */}
            {cols.city && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.city}</span>
                </Table.BodyCell>
            )}

            {/* ── Col 4: Book-entry type — always ── */}
            <Table.BodyCell>
                <div className="rv__shares-vertical">
                    {row.bookEntries.map((s, i) => (
                        <div key={i} className={s.isTotal ? 'rv__cell-total' : 'rv__cell-sm'}>
                            {s.isTotal ? t.totalSharesLabel : s.shareClassName}
                        </div>
                    ))}
                </div>
            </Table.BodyCell>

            {/* ── Col 5: Custodian (statutory, full, short) ── */}
            {cols.custodianName && (
                <Table.BodyCell>
                    <div className="rv__shares-vertical">
                        {row.bookEntries.map((s, i) => (
                            <div key={i} className="rv__cell-sm">
                                {s.isTotal ? '' : (s.custodianName || '')}
                            </div>
                        ))}
                    </div>
                </Table.BodyCell>
            )}

            {/* ── Col 6: Number of book-entries — always ── */}
            <Table.BodyCell align="middle-right">
                <div className="rv__shares-vertical">
                    {row.bookEntries.map((s, i) => (
                        <div key={i} className={s.isTotal ? 'rv__cell-total' : 'rv__cell-sm'}>
                            {s.numberOfEntries}
                        </div>
                    ))}
                </div>
            </Table.BodyCell>

            {/* ── Col 7: % combined (full, short) ── */}
            {cols.percentageCombined && (
                <Table.BodyCell align="middle-right">
                    <div className="rv__shares-vertical">
                        {row.bookEntries.map((s, i) => (
                            <div key={i} className="rv__cell-sm">{s.percentageCombined}</div>
                        ))}
                    </div>
                </Table.BodyCell>
            )}

            {/* ── Col 8: Votes (full only) ── */}
            {cols.numberOfVotes && (
                <Table.BodyCell align="middle-right">
                    <div className="rv__shares-vertical">
                        {row.bookEntries.map((s, i) => (
                            <div key={i} className={s.isTotal ? 'rv__cell-total' : 'rv__cell-sm'}>
                                {s.numberOfVotes || ''}
                            </div>
                        ))}
                    </div>
                </Table.BodyCell>
            )}

            {/* ── Col 9: Vote % (full only) ── */}
            {cols.votingRightsPercentage && (
                <Table.BodyCell align="middle-right">
                    <div className="rv__shares-vertical">
                        {row.bookEntries.map((s, i) => (
                            <div key={i} className="rv__cell-sm">{s.votingRightsPercentage || ''}</div>
                        ))}
                    </div>
                </Table.BodyCell>
            )}

            {/* ── Col 10: Situation date (statutory only) ── */}
            {cols.date && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.situationDate}</span>
                </Table.BodyCell>
            )}

            {/* ── Col 11: Sector (full only) ── */}
            {cols.sector && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.sectorName}</span>
                </Table.BodyCell>
            )}

            {/* ── Col 12: Payment info (statutory, full) ── */}
            {cols.payment && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.paymentInfo}</span>
                </Table.BodyCell>
            )}

            {/* ── Col 13: Tax info (statutory, full) ── */}
            {cols.tax && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.taxInfo}</span>
                </Table.BodyCell>
            )}
        </Table.Row>
    );
}
