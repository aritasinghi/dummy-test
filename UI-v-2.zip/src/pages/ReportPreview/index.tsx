import { Banner, Button, Container } from '@efi/efi-ui-components';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import './ReportPreview.css';

interface ReportPreviewProps {
    reportTitle: string;
    language: Language;
    onBack: () => void;
    onSubscribe: () => void;
}

const REPORT_ROWS = [
    'Osakkeiden määrä',
    'Osakkeiden yhteismäärä, osuus osakkeiden kokonaismäärästä',
    'Henkilö- ja yksilöintitunnus',
    'Maksu- ja verotustiedot, tilinhoitajatieto',
    'Osoitetiedot, maatieto, turvakielliset',
    'Äänimäärätiedot',
    'Sektoritieto',
    'Asiakasrajoitus',
];

const REPORT_MATRIX: Record<string, boolean[]> = {
    'Osakkeiden määrä': [true, true, true, true],
    'Osakkeiden yhteismäärä, osuus osakkeiden kokonaismäärästä': [true, true, true, true],
    'Henkilö- ja yksilöintitunnus': [true, true, true, true],
    'Maksu- ja verotustiedot, tilinhoitajatieto': [true, true, true, false],
    'Osoitetiedot, maatieto, turvakielliset': [true, true, true, true],
    'Äänimäärätiedot': [true, false, false, false],
    'Sektoritieto': [true, false, false, false],
    'Asiakasrajoitus': [true, false, false, false],
};

export default function ReportPreview({ reportTitle, language, onBack, onSubscribe }: ReportPreviewProps) {
    const t = translations[language].reportPreview;
    const columns = [t.full, t.agm, t.statutory, t.short];

    return (
        <>
            {/* Banner with breadcrumb */}
            <Banner appName="MyEuroclear">
                <Banner.Title>
                    <span className="rp__breadcrumb">
                        <span>{t.breadcrumbRoot}</span>
                        <span className="rp__breadcrumb-sep">{'>'}</span>
                        <span>{t.breadcrumbReports}</span>
                    </span>
                </Banner.Title>
                <Banner.Subtitle>
                    {t.title} {reportTitle}
                </Banner.Subtitle>
            </Banner>

            <Container>
                {/* Content + Actions row */}
                <div className="rp__content-row">
                    <div className="rp__content-left">
                        <section className="rp__section">
                            <h2 className="rp__section-title">{t.orderableDataTitle}: {reportTitle}</h2>
                            <h3 className="rp__subtitle">{t.whatIsThisTitle}</h3>
                            <p className="rp__desc">{t.whatIsThisDesc}</p>
                        </section>
                    </div>

                    {/* Action buttons — top right */}
                    <div className="rp__actions-top">
                        <Button variant="secondary" onClick={onBack}>{t.back}</Button>
                        <Button variant="primary" onClick={onSubscribe}>{t.toSubscription}</Button>
                    </div>
                </div>

                {/* Report types matrix — 4 columns */}
                <section className="rp__section">
                    <h3 className="rp__matrix-title">{t.reportTypesTitle}</h3>
                    <div className="rp__matrix">
                        <table className="rp__table">
                            <thead>
                                <tr>
                                    <th className="rp__th-label" />
                                    {columns.map((col) => (
                                        <th key={col} className="rp__th-col">{col}</th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {REPORT_ROWS.map((row) => (
                                    <tr key={row}>
                                        <td className="rp__td-label">{row}</td>
                                        {REPORT_MATRIX[row].map((checked, i) => (
                                            <td key={i} className="rp__td-check">
                                                {checked && (
                                                    <span className="rp__check-icon">
                                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                            <rect x="1" y="1" width="18" height="18" rx="3" fill="#00B9A4" />
                                                            <path d="M6 10l3 3 5-6" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                                        </svg>
                                                    </span>
                                                )}
                                            </td>
                                        ))}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </section>

                {/* Example */}
                <section className="rp__section">
                    <h3 className="rp__subtitle rp__subtitle--bold">{t.exampleTitle}</h3>
                    <div className="rp__example">
                        <div className="rp__example-header">
                            <div className="rp__example-header-left">
                                <span className="rp__example-hamburger">≡</span>
                                <span className="rp__example-logo">⊙</span>
                                <span className="rp__example-app">Information Elements by Euroclear</span>
                            </div>
                            <span className="rp__example-org">Organisaatio: Euroflex ⊗</span>
                        </div>
                        <div className="rp__example-nav">
                            <span className="rp__example-nav-active">RAPORTIT</span>
                            <span>TAPAHTUMALOKI</span>
                            <span>ORGANISAATION TIEDOT</span>
                        </div>
                        <div className="rp__example-content">
                            <p className="rp__example-date">01.11.2025 Liikkeeseenlaskijan osakasluettelo</p>
                            <div className="rp__example-tabs">
                                <span className="rp__example-tab-active">RAPORTTI</span>
                                <span>TILAUKSEN TIEDOT</span>
                            </div>
                        </div>
                    </div>
                </section>
            </Container>
        </>
    );
}
