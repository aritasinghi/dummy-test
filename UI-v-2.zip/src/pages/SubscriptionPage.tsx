import { useState } from 'react';
import './SubscriptionPage.css';

interface ValueShare {
    id: string;
    label: string;
    isin: string;
    checked: boolean;
}

interface SubscriptionPageProps {
    reportTitle?: string;
    onCancel?: () => void;
    onContinue?: () => void;
}

export default function SubscriptionPage({
    reportTitle = 'Liikkeeseenlaskijan osakasluettelo',
    onCancel,
    onContinue,
}: SubscriptionPageProps) {
    // Order type: one-time or recurring
    const [orderType, setOrderType] = useState<'one-time' | 'recurring'>('one-time');

    // Date mode
    const [dateMode, setDateMode] = useState<'latest' | 'custom'>('latest');
    const [customDate, setCustomDate] = useState('2024-02-22');

    // Value shares (Euroflex A/B with ISIN)
    const [valueShares, setValueShares] = useState<ValueShare[]>([
        { id: '1', label: 'Euroflex A', isin: 'FI21049685930', checked: true },
        { id: '2', label: 'Euroflex B', isin: 'FI21049685931', checked: true },
        { id: '3', label: 'Euroflex B', isin: 'FI21049685931', checked: true },
        { id: '4', label: 'Euroflex A', isin: 'FI21049685930', checked: true },
        { id: '5', label: 'Euroflex B', isin: 'FI21049685931', checked: true },
        { id: '6', label: 'Euroflex B', isin: 'FI21049685931', checked: true },
    ]);

    // Reference
    const [reference, setReference] = useState('1234567890');

    const toggleShare = (id: string) => {
        setValueShares((prev) =>
            prev.map((s) => (s.id === id ? { ...s, checked: !s.checked } : s))
        );
    };

    return (
        <div className="subscription-page">
            {/* Page header */}
            <div className="subscription-page__header">
                <h2 className="subscription-page__title">
                    Tilaa uusi raportti: {reportTitle}
                </h2>
                <div className="subscription-page__type-toggle">
                    <label className="subscription-page__radio">
                        <input
                            type="radio"
                            name="orderType"
                            checked={orderType === 'one-time'}
                            onChange={() => setOrderType('one-time')}
                        />
                        <span className="subscription-page__radio-dot" />
                        Tee kertatilaus
                    </label>
                    <label className="subscription-page__radio">
                        <input
                            type="radio"
                            name="orderType"
                            checked={orderType === 'recurring'}
                            onChange={() => setOrderType('recurring')}
                        />
                        <span className="subscription-page__radio-dot" />
                        Tee toistuva tilaus
                    </label>
                </div>
            </div>

            {/* Order type label */}
            <h3 className="subscription-page__section-title">
                {orderType === 'one-time' ? 'Kertatilaus' : 'Toistuva tilaus'}
            </h3>

            {/* Date section */}
            <div className="subscription-page__row">
                <div className="subscription-page__field-group">
                    <h4 className="subscription-page__field-title">Raportin päivämäärä</h4>

                    <label className="subscription-page__radio">
                        <input
                            type="radio"
                            name="dateMode"
                            checked={dateMode === 'latest'}
                            onChange={() => setDateMode('latest')}
                        />
                        <span className="subscription-page__radio-dot" />
                        Viimeisin tilanne, heti saatavilla
                    </label>

                    <label className="subscription-page__radio">
                        <input
                            type="radio"
                            name="dateMode"
                            checked={dateMode === 'custom'}
                            onChange={() => setDateMode('custom')}
                        />
                        <span className="subscription-page__radio-dot" />
                        Tilanne päivän lopulla, saatavilla huomenna
                    </label>

                    {dateMode === 'custom' && (
                        <div className="subscription-page__date-picker">
                            <label className="subscription-page__date-label">Valitse päivämäärä</label>
                            <input
                                type="date"
                                className="subscription-page__date-input"
                                value={customDate}
                                onChange={(e) => setCustomDate(e.target.value)}
                            />
                        </div>
                    )}
                </div>

                {/* Info panel */}
                <div className="subscription-page__info-panel">
                    <h4 className="subscription-page__info-title">Valitse raportin päivämäärä</h4>
                    <p className="subscription-page__info-text">
                        Jos päivämäärä on menneisyydessä, raportti valmistuu
                        hetken kuluttua tilauksesta. Jos valittu päivä on
                        tulevaisuudessa, raportti valmistuu tilauksen seuraavana
                        arkipäivänä. Jos valittu päivämäärä osuu viikonlopulle,
                        raportti toimitetaan edeltävän arkipäivän tilanteesta.
                        Viimeisin tilanne ....
                    </p>
                </div>
            </div>

            {/* Value shares section */}
            <div className="subscription-page__row">
                <div className="subscription-page__field-group">
                    <h4 className="subscription-page__field-title">Arvo-osuudet ja viite</h4>
                    <p className="subscription-page__field-subtitle">Arvo-osuuslaji: Osakkeet</p>

                    <div className="subscription-page__shares-grid">
                        {valueShares.map((share) => (
                            <label key={share.id} className="subscription-page__checkbox">
                                <input
                                    type="checkbox"
                                    checked={share.checked}
                                    onChange={() => toggleShare(share.id)}
                                />
                                <span className="subscription-page__checkbox-box" />
                                <span className="subscription-page__checkbox-text">
                                    <span className="subscription-page__share-label">{share.label}</span>
                                    <span className="subscription-page__share-isin">{share.isin}</span>
                                </span>
                            </label>
                        ))}
                    </div>

                    {/* Reference input */}
                    <div className="subscription-page__reference">
                        <label className="subscription-page__date-label">Tilauksen viite</label>
                        <input
                            type="text"
                            className="subscription-page__text-input"
                            value={reference}
                            onChange={(e) => setReference(e.target.value)}
                            placeholder="1234567890"
                        />
                    </div>
                </div>

                {/* Info panel */}
                <div className="subscription-page__info-panel">
                    <h4 className="subscription-page__info-title">Osakesarjan (lajin) valinta</h4>
                    <p className="subscription-page__info-text">
                        Raportille voi valita ...
                        Vaikutus hintaan: kuvataan
                    </p>

                    <h4 className="subscription-page__info-title subscription-page__info-title--spaced">
                        Tilauksen viite (optional)
                    </h4>
                    <p className="subscription-page__info-text">
                        Tilauksen viitteeksi voitte valita ... Tieto tulee laskulle ...
                    </p>
                </div>
            </div>

            {/* Price note */}
            <p className="subscription-page__price-note">
                Raportin hinta tai hinta-arvio esitetään seuraavassa näkymässä
            </p>

            {/* Actions */}
            <div className="subscription-page__actions">
                <button
                    className="subscription-page__btn subscription-page__btn--outlined"
                    onClick={onCancel}
                    type="button"
                >
                    PERUUTA
                </button>
                <button
                    className="subscription-page__btn subscription-page__btn--primary"
                    onClick={onContinue}
                    type="button"
                >
                    JATKA
                </button>
            </div>
        </div>
    );
}
