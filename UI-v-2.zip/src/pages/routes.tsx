import type React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
// TODO: Uncomment once @efi/efi-ui-components and auth are set up
// import { ThemeProvider as UIProvider } from '@efi/efi-ui-components';
// import { AuthProvider } from '@/config/auth';
// import { UserProvider } from '@/features/auth/UserProvider';
// import { GuestCheck } from '@/features/auth/GuestCheck';
// import { LoginPage } from '@/pages/app/LoginPage';
// import { LoadingPage } from '@/pages/app/LoadingPage';
import LandingPage from '@/pages/LandingPage';

/**
 * Routes definition file.
 *
 * Pattern from portal-app-dev:
 * UIProvider > AuthProvider > UserProvider > Router > Routes
 *
 * Currently simplified — will be expanded as auth is added.
 */

// TODO: Replace with actual profile check
// function RedirectByRole({ profile }: { profile: any }) {
//     if (!profile) return <LoadingPage />;
//     return profile.isAdmin
//         ? <Navigate to="/admin" replace />
//         : <Navigate to="/user" replace />;
// }

const AppRouter: React.FC = () => (
    // TODO: Wrap with providers once available:
    // <UIProvider>
    //     <AuthProvider {...oidcConfig}>
    //         <UserProvider>
    //             <Router>
    //                 <Routes>
    //                     {/* Public routes */}
    //                     <Route
    //                         path="/login"
    //                         element={
    //                             <GuestCheck>
    //                                 <LoginPage />
    //                             </GuestCheck>
    //                         }
    //                     />
    //                     <Route path="/loading" element={<LoadingPage />} />
    //
    //                     {/* Protected routes */}
    //                     <Route path="/reports" element={<LandingPage />} />
    //                     <Route path="/event-log" element={<div>Event Log</div>} />
    //                     <Route path="/organisation" element={<div>Organisation Info</div>} />
    //
    //                     {/* Default */}
    //                     <Route path="*" element={<Navigate to="/reports" replace />} />
    //                 </Routes>
    //             </Router>
    //         </UserProvider>
    //     </AuthProvider>
    // </UIProvider>

    // Simplified version for now
    <Router>
        <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/reports" element={<LandingPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
    </Router>
);

export default AppRouter;
