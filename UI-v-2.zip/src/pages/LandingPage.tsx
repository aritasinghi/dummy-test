import { useState } from 'react';
import {
    Banner,
    Button,
    Container,
    Header,
    Main,
    ProfileMenu,
    LanguageSelector,
} from '@efi/efi-ui-components';
import { translations } from '@/locales';
import type { Language } from '@/locales';
import { SubscriptionModal } from '@/components/SubscriptionModal';
import { DownloadModal } from '@/components/DownloadModal';
import type { SubscriptionFormData } from '@/components/SubscriptionModal';
import type { DownloadOptions } from '@/components/DownloadModal';
import ReportsPage from './ReportsPage';
import ReportPreview from './ReportPreview';
import ReportView from './ReportView';
import SubscribedReports from './SubscribedReports';

// ---------------------------------------------------------------------------
// Navigation state
// ---------------------------------------------------------------------------
type View =
    | { type: 'landing' }
    | { type: 'preview'; reportId: string; reportTitle: string }
    | { type: 'subscribedList'; reportId: string; reportTitle: string }
    | { type: 'reportView'; reportId: string; reportTitle: string; reportDate: string };

export default function LandingPage() {
    const [language, setLanguage] = useState<Language>("en");
    const [activeTab, setActiveTab] = useState<string>("reports");
    const [currentView, setCurrentView] = useState<View>({ type: 'landing' });

    // Modal states
    const [subscriptionModal, setSubscriptionModal] = useState<{ open: boolean; reportTitle: string }>({ open: false, reportTitle: '' });
    const [downloadModal, setDownloadModal] = useState(false);

    const t = translations[language];

    const tabs = [
        { label: t.tabs.reports, path: "reports" },
        { label: t.tabs.log, path: "log" },
        { label: t.tabs.organization, path: "organization" },
    ];

    // ── Navigation handlers ──
    const navigateTo = (view: View) => setCurrentView(view);
    const goBackToLanding = () => setCurrentView({ type: 'landing' });

    const handleShowPreview = (reportId: string, reportTitle: string) => {
        navigateTo({ type: 'preview', reportId, reportTitle });
    };

    const handleShowAllSubscribed = (reportId: string, reportTitle: string, subscribedCount: number) => {
        if (subscribedCount === 1) {
            navigateTo({ type: 'reportView', reportId, reportTitle, reportDate: '01.11.2025' });
        } else {
            navigateTo({ type: 'subscribedList', reportId, reportTitle });
        }
    };

    const handleOpenReport = (reportId: string) => {
        const view = currentView;
        if (view.type === 'subscribedList') {
            navigateTo({ type: 'reportView', reportId, reportTitle: view.reportTitle, reportDate: '01.11.2025' });
        }
    };

    const handleShowLatest = (reportId: string, reportTitle: string) => {
        navigateTo({ type: 'reportView', reportId, reportTitle, reportDate: '01.11.2025' });
    };

    const handleSubscribe = (_reportId: string, reportTitle?: string) => {
        setSubscriptionModal({ open: true, reportTitle: reportTitle ?? '' });
    };

    const handleSubscriptionSubmit = (data: SubscriptionFormData) => {
        console.log('Subscription submitted:', data);
        setSubscriptionModal({ open: false, reportTitle: '' });
    };

    const handleDownload = (options: DownloadOptions) => {
        console.log('Download requested:', options);
        setDownloadModal(false);
    };

    // ── Tab content renderer ──
    const renderTabContent = () => {
        switch (activeTab) {
            case 'reports':
                return (
                    <ReportsPage
                        language={language}
                        onSubscribe={handleSubscribe}
                        onShowPreview={handleShowPreview}
                        onShowAllSubscribed={handleShowAllSubscribed}
                        onShowLatest={handleShowLatest}
                    />
                );
            case 'log':
                return <p>{t.content.log}</p>;
            case 'organization':
                return <p>{t.content.organization}</p>;
            default:
                return null;
        }
    };

    // ── Main content based on current view ──
    const renderMainContent = () => {
        switch (currentView.type) {
            case 'preview':
                return (
                    <ReportPreview
                        reportTitle={currentView.reportTitle}
                        language={language}
                        onBack={goBackToLanding}
                        onSubscribe={() => handleSubscribe(currentView.reportId, currentView.reportTitle)}
                    />
                );

            case 'subscribedList':
                return (
                    <SubscribedReports
                        reportTitle={currentView.reportTitle}
                        language={language}
                        onReportClick={handleOpenReport}
                    />
                );

            case 'reportView':
                return (
                    <ReportView
                        reportTitle={currentView.reportTitle}
                        reportDate={currentView.reportDate}
                        language={language}
                        onBack={goBackToLanding}
                        onSubscribe={() => handleSubscribe(currentView.reportId, currentView.reportTitle)}
                        onDownload={() => setDownloadModal(true)}
                    />
                );

            case 'landing':
            default:
                return (
                    <>
                        <Banner appName="MyEuroclear">
                            <Banner.Title>{t.tabs[activeTab as keyof typeof t.tabs]}</Banner.Title>
                        </Banner>

                        <Container>
                            <Container.Heading>{t.welcome}</Container.Heading>
                            {renderTabContent()}
                        </Container>
                    </>
                );
        }
    };

    return (
        <>
            {/* ════════════════════════════════════════════════════════
               HEADER — using efi compound components
               ════════════════════════════════════════════════════════ */}
            <Header
                skipToContentLabel={t.header.skipToContent}
                drawerProps={{
                    buttonOpen: t.header.openMenu,
                    buttonClose: t.header.closeMenu,
                }}
            >
                <Header.AppName>{t.header.appName}</Header.AppName>
                <Header.SecondaryTitle>{t.header.orgLabel}</Header.SecondaryTitle>

                <Header.Actions>
                    <ProfileMenu aria-label={t.profileMenu.yourProfile}>
                        <ProfileMenu.Title>Justin Time</ProfileMenu.Title>

                        <ProfileMenu.InfoItem label={t.profileMenu.companyLabel}>
                            Wishing Well Investments
                        </ProfileMenu.InfoItem>
                        <ProfileMenu.InfoItem label={t.profileMenu.departmentLabel}>
                            Marketing and communications
                        </ProfileMenu.InfoItem>

                        <LanguageSelector
                            label={t.profileMenu.selectLanguage}
                            defaultSelected={language}
                            onSelect={(_event: unknown, value?: string) => {
                                if (value) setLanguage(value as Language);
                            }}
                        >
                            <LanguageSelector.Option value="en" lang="en-GB">English</LanguageSelector.Option>
                            <LanguageSelector.Option value="sv" lang="sv-SE">Svenska</LanguageSelector.Option>
                            <LanguageSelector.Option value="fi" lang="fi-FI">Suomi</LanguageSelector.Option>
                        </LanguageSelector>

                        <ProfileMenu.Item value="dashboard">{t.profileMenu.dashboard}</ProfileMenu.Item>
                        <ProfileMenu.Item value="profile">{t.profileMenu.profile}</ProfileMenu.Item>
                        <ProfileMenu.Item value="disabled" disabled>{t.profileMenu.notAvailable}</ProfileMenu.Item>
                        <ProfileMenu.Item value="logout">{t.profileMenu.logout}</ProfileMenu.Item>
                    </ProfileMenu>
                </Header.Actions>

                <Header.Navigation aria-label="Main navigation">
                    {tabs.map(({ label, path }) => (
                        <Header.NavigationItem
                            key={path}
                            href={`/${path}`}
                            active={activeTab === path}
                            onClick={(e: React.MouseEvent) => {
                                e.preventDefault();
                                setActiveTab(path);
                                goBackToLanding();
                            }}
                        >
                            {label}
                        </Header.NavigationItem>
                    ))}
                </Header.Navigation>
            </Header>

            {/* ════════════════════════════════════════════════════════
               MAIN — using efi Main component
               ════════════════════════════════════════════════════════ */}
            <Main>
                {renderMainContent()}
            </Main>

            {/* ════════════════════════════════════════════════════════
               MODALS
               ════════════════════════════════════════════════════════ */}
            <SubscriptionModal
                isOpen={subscriptionModal.open}
                reportTitle={subscriptionModal.reportTitle}
                onClose={() => setSubscriptionModal({ open: false, reportTitle: '' })}
                onSubmit={handleSubscriptionSubmit}
                language={language}
            />

            <DownloadModal
                isOpen={downloadModal}
                language={language}
                onClose={() => setDownloadModal(false)}
                onDownload={handleDownload}
            />
        </>
    );
}
