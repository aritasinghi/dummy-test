import './AvailableReportCard.css';

interface AvailableReportCardProps {
    title: string;
    description?: string;
    previewLabel: string;
    subscribeLabel: string;
    onPreview?: () => void;
    onSubscribe?: () => void;
}

export function AvailableReportCard({ title, description, previewLabel, subscribeLabel, onPreview, onSubscribe }: AvailableReportCardProps) {
    return (
        <div className="ois-avail-card">
            {/* Plus icon + title */}
            <div className="ois-avail-card__header">
                <span className="ois-avail-card__plus">+</span>
                <h3 className="ois-avail-card__title">{title}</h3>
            </div>

            {/* Description */}
            {description && (
                <p className="ois-avail-card__desc">
                    {description.length > 120 ? description.slice(0, 120) + '...' : description}
                    {description.length > 120 && <button className="ois-avail-card__read-more" type="button">Lue lisää</button>}
                </p>
            )}

            {/* Actions */}
            <div className="ois-avail-card__actions">
                <button className="ois-avail-card__btn ois-avail-card__btn--outlined" onClick={onPreview} type="button">
                    {previewLabel}
                </button>
                <button className="ois-avail-card__btn ois-avail-card__btn--primary" onClick={onSubscribe} type="button">
                    {subscribeLabel}
                </button>
            </div>
        </div>
    );
}
