import { useState, useMemo } from 'react';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import './DatePicker.css';

interface DatePickerProps {
    isOpen: boolean;
    title?: string;
    selectedDate?: Date;
    onSelect: (date: Date) => void;
    onCancel: () => void;
    showTimeToggle?: boolean;
    lang?: Language;
}

function getDaysInMonth(y: number, m: number) { return new Date(y, m + 1, 0).getDate(); }
function getStartDay(y: number, m: number) { const d = new Date(y, m, 1).getDay(); return d === 0 ? 6 : d - 1; }
function isSameDay(a: Date, b: Date) { return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate(); }
function addDays(d: Date, n: number) { const r = new Date(d); r.setDate(r.getDate() + n); return r; }

export function DatePicker({ isOpen, title, selectedDate, onSelect, onCancel, showTimeToggle = true, lang = 'fi' }: DatePickerProps) {
    const t = translations[lang].datePicker;
    const today = new Date();
    const [viewYear, setViewYear] = useState(selectedDate?.getFullYear() ?? today.getFullYear());
    const [viewMonth, setViewMonth] = useState(selectedDate?.getMonth() ?? today.getMonth());
    const [picked, setPicked] = useState<Date | null>(selectedDate ?? null);
    const [timeEnabled, setTimeEnabled] = useState(false);

    const cells = useMemo(() => {
        const days = getDaysInMonth(viewYear, viewMonth);
        const start = getStartDay(viewYear, viewMonth);
        const c: (number | null)[] = [];
        for (let i = 0; i < start; i++) c.push(null);
        for (let d = 1; d <= days; d++) c.push(d);
        return c;
    }, [viewYear, viewMonth]);

    const quickPicks = [
        { key: 'threeDaysAgo' as const, date: addDays(today, -3) },
        { key: 'twoDaysAgo' as const, date: addDays(today, -2) },
        { key: 'yesterday' as const, date: addDays(today, -1) },
        { key: 'today' as const, date: today },
        { key: 'tomorrow' as const, date: addDays(today, 1) },
        { key: 'nextWeek' as const, date: addDays(today, 7) },
    ];

    if (!isOpen) return null;

    const prevMonth = () => { if (viewMonth === 0) { setViewMonth(11); setViewYear(y => y - 1); } else setViewMonth(m => m - 1); };
    const nextMonth = () => { if (viewMonth === 11) { setViewMonth(0); setViewYear(y => y + 1); } else setViewMonth(m => m + 1); };
    const pickDay = (d: number) => setPicked(new Date(viewYear, viewMonth, d));
    const pickQuick = (d: Date) => { setPicked(d); setViewYear(d.getFullYear()); setViewMonth(d.getMonth()); };

    return (
        <div className="dp__overlay" onClick={onCancel}>
            <div className="dp" onClick={e => e.stopPropagation()}>
                {/* Title + month nav */}
                <div className="dp__head">
                    <h3 className="dp__title">{title ?? t.title}</h3>
                </div>

                <div className="dp__body">
                    <div className="dp__cal">
                        {/* Month nav — only show arrows when not first load */}
                        <div className="dp__nav">
                            <button className="dp__nav-btn" type="button" onClick={prevMonth}>‹</button>
                            <span className="dp__month">{t.months[viewMonth]} {viewYear}</span>
                            <button className="dp__nav-btn" type="button" onClick={nextMonth}>›</button>
                        </div>

                        {/* Day grid — NO weekday headers (matching Figma) */}
                        <div className="dp__grid">
                            {cells.map((day, i) => {
                                if (day === null) return <span key={`e${i}`} className="dp__cell dp__cell--empty" />;
                                const d = new Date(viewYear, viewMonth, day);
                                const sel = picked && isSameDay(d, picked);
                                const tod = isSameDay(d, today);
                                return (
                                    <button key={day} type="button"
                                        className={`dp__cell${tod ? ' dp__cell--today' : ''}${sel ? ' dp__cell--sel' : ''}`}
                                        onClick={() => pickDay(day)}>{day}</button>
                                );
                            })}
                        </div>
                    </div>

                    {/* Quick picks */}
                    <div className="dp__picks">
                        {quickPicks.map(({ key, date }) => (
                            <button key={key} type="button"
                                className={`dp__pick${picked && isSameDay(date, picked) ? ' dp__pick--active' : ''}`}
                                onClick={() => pickQuick(date)}>{t.quickPicks[key]}</button>
                        ))}
                    </div>
                </div>

                {/* Footer */}
                <div className="dp__foot">
                    {showTimeToggle && (
                        <label className="dp__time-toggle">
                            <span className="dp__time-label">{t.selectTime}</span>
                            <button type="button" className={`dp__toggle${timeEnabled ? ' dp__toggle--on' : ''}`}
                                onClick={() => setTimeEnabled(!timeEnabled)} role="switch" aria-checked={timeEnabled}>
                                <span className="dp__toggle-thumb" />
                            </button>
                        </label>
                    )}
                    <div className="dp__actions">
                        <button className="dp__btn dp__btn--cancel" type="button" onClick={onCancel}>{t.cancel}</button>
                        <button className="dp__btn dp__btn--done" type="button" onClick={() => picked && onSelect(picked)} disabled={!picked}>{t.done}</button>
                    </div>
                </div>
            </div>
        </div>
    );
}
