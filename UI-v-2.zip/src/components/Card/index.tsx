import './Card.css';

interface DataRow { name: string; percentage: number; }

interface CardProps {
    title: string;
    badge?: string;
    data: DataRow[];
    lastReportDate: string;
    subscribedCount: number;
    showLatestLabel: string;
    showAllLabel: string;
    subscribeLabel: string;
    onShowLatest?: () => void;
    onShowAll?: () => void;
    onSubscribe?: () => void;
}

export function Card({ title, badge, data, lastReportDate, subscribedCount, showLatestLabel, showAllLabel, subscribeLabel, onShowLatest, onShowAll, onSubscribe }: CardProps) {
    return (
        <div className="ois-card">
            {/* Header */}
            <div className="ois-card__header">
                <h3 className="ois-card__title">{title}</h3>
                {badge && <span className="ois-card__badge">{badge}</span>}
            </div>

            {/* Data table with fade overlay */}
            <div className="ois-card__data-wrap">
                <div className="ois-card__data-table">
                    <div className="ois-card__data-header">
                        <span />
                        <span className="ois-card__data-pct">%</span>
                    </div>
                    {data.map((row) => (
                        <div key={row.name} className="ois-card__data-row">
                            <span className="ois-card__data-name">{row.name}</span>
                            <span className="ois-card__data-value">{row.percentage.toFixed(2)}</span>
                        </div>
                    ))}
                </div>
                {/* Bottom fade/blur overlay */}
                <div className="ois-card__data-fade" />
            </div>

            {/* Latest report link */}
            <a className="ois-card__link" href="#" onClick={(e) => { e.preventDefault(); onShowLatest?.(); }}>
                {showLatestLabel}: {lastReportDate}
            </a>

            {/* Actions */}
            <div className="ois-card__actions">
                <button className="ois-card__btn ois-card__btn--outlined" onClick={onShowAll} type="button">
                    {showAllLabel} ({subscribedCount})
                </button>
                <button className="ois-card__btn ois-card__btn--primary" onClick={onSubscribe} type="button">
                    + {subscribeLabel}
                </button>
            </div>
        </div>
    );
}
