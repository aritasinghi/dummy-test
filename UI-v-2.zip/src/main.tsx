import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import "@efi/efi-ui-components/css/index.css";
import "@efi/efi-ui-components/css/theme-light.css";

// ── App ────────────────────────────────────────────────────────────────────
import { AppProviders } from '@/providers';
import LandingPage from '@/pages/LandingPage';

// ── Mount ──────────────────────────────────────────────────────────────────
const root = document.getElementById('root');

if (!root) {
    throw new Error('Root element #root not found in document.');
}

createRoot(root).render(
    <StrictMode>
        <AppProviders theme="light">
            <LandingPage />
        </AppProviders>
    </StrictMode>,
);
