import { useModals } from '@/context';
import { useLanguage } from '@/context';
import { SubscriptionModal } from '@/components/SubscriptionModal';
import { DownloadModal } from '@/components/DownloadModal';
import type { SubscriptionFormData } from '@/components/SubscriptionModal';
import type { DownloadOptions } from '@/components/DownloadModal';

/**
 * ModalLayer — renders all app modals.
 * Placed once at the root level, reads state from ModalContext.
 * When API hooks are ready, mutation calls go here.
 */
export function ModalLayer() {
    const { modals, closeSubscription, closeDownload } = useModals();
    const { language } = useLanguage();

    const handleSubscriptionSubmit = (data: SubscriptionFormData) => {
        console.log('Subscription submitted:', data);
        // TODO: call useSubscribeToReport().mutate(data)
        closeSubscription();
    };

    const handleDownload = (options: DownloadOptions) => {
        console.log('Download requested:', options);
        // TODO: call download API
        closeDownload();
    };

    return (
        <>
            <SubscriptionModal
                isOpen={modals.subscription.open}
                reportTitle={modals.subscription.reportTitle}
                onClose={closeSubscription}
                onSubmit={handleSubscriptionSubmit}
                language={language}
            />
            <DownloadModal
                isOpen={modals.download.open}
                language={language}
                onClose={closeDownload}
                onDownload={handleDownload}
            />
        </>
    );
}
