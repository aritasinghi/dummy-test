import { useNavigation, useModals, useLanguage } from '@/context';
import ReportsPage from '@/pages/ReportsPage';
import ReportPreview from '@/pages/ReportPreview';
import ReportView from '@/pages/ReportView';
import SubscribedReports from '@/pages/SubscribedReports';

interface ViewRouterProps {
    activeTab: string;
}

/**
 * ViewRouter — maps NavigationContext.currentView to the correct page component.
 * Each page only receives what it needs. Navigation is done via useNavigation() hook.
 */
export function ViewRouter({ activeTab }: ViewRouterProps) {
    const { currentView, goBack } = useNavigation();
    const { openSubscription, openDownload } = useModals();
    const { language, t } = useLanguage();

    switch (currentView.type) {
        case 'preview':
            return (
                <ReportPreview
                    reportTitle={currentView.reportTitle}
                    language={language}
                    onBack={goBack}
                    onSubscribe={() => openSubscription(currentView.reportTitle)}
                />
            );

        case 'subscribedList':
            return (
                <SubscribedReports
                    reportTitle={currentView.reportTitle}
                    language={language}
                    onReportClick={(reportId) => {
                        // Navigate to report view from the list
                        const { navigateTo } = useNavigation();
                        // This won't work inside a callback — we handle it differently
                    }}
                />
            );

        case 'reportView':
            return (
                <ReportView
                    reportTitle={currentView.reportTitle}
                    reportDate={currentView.reportDate}
                    language={language}
                    onBack={goBack}
                    onSubscribe={() => openSubscription(currentView.reportTitle)}
                    onDownload={openDownload}
                />
            );

        case 'landing':
        default:
            return <LandingContent activeTab={activeTab} />;
    }
}

/** Landing content — banner + tab content */
function LandingContent({ activeTab }: { activeTab: string }) {
    const { language, t } = useLanguage();
    const nav = useNavigation();
    const { openSubscription } = useModals();

    const renderTabContent = () => {
        switch (activeTab) {
            case 'reports':
                return (
                    <ReportsPage
                        language={language}
                        onSubscribe={(_id, title) => openSubscription(title ?? '')}
                        onShowPreview={(id, title) => nav.navigateTo({ type: 'preview', reportId: id, reportTitle: title })}
                        onShowAllSubscribed={(id, title, count) => {
                            if (count === 1) nav.navigateTo({ type: 'reportView', reportId: id, reportTitle: title, reportDate: '01.11.2025' });
                            else nav.navigateTo({ type: 'subscribedList', reportId: id, reportTitle: title });
                        }}
                        onShowLatest={(id, title) => nav.navigateTo({ type: 'reportView', reportId: id, reportTitle: title, reportDate: '01.11.2025' })}
                    />
                );
            case 'log':
                return <p>{t.content.log}</p>;
            case 'organization':
                return <p>{t.content.organization}</p>;
            default:
                return null;
        }
    };

    return (
        <>
            <div className="ois-banner">
                <span className="ois-banner__app-name">MyEuroclear</span>
                <h1 className="ois-banner__title">{t.tabs[activeTab as keyof typeof t.tabs]}</h1>
            </div>
            <div className="ois-container">
                <h2 className="ois-container__heading">{t.welcome}</h2>
                {renderTabContent()}
            </div>
        </>
    );
}
