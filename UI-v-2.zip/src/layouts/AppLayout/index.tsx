import { useState } from 'react';
import { useLanguage } from '@/context';
import { useNavigation } from '@/context';
import { ProfileMenu } from '@/components/ProfileMenu';
import type { ReactNode } from 'react';
import './AppLayout.css';

interface AppLayoutProps {
    activeTab: string;
    onTabChange: (tab: string) => void;
    children: ReactNode;
}

export function AppLayout({ activeTab, onTabChange, children }: AppLayoutProps) {
    const { language, setLanguage, t } = useLanguage();
    const { goHome } = useNavigation();

    const tabs = [
        { label: t.tabs.reports, path: 'reports' },
        { label: t.tabs.log, path: 'log' },
        { label: t.tabs.organization, path: 'organization' },
    ];

    const handleTabClick = (path: string) => {
        onTabChange(path);
        goHome();
    };

    return (
        <>
            <header className="ois-header">
                <div className="ois-header__top">
                    <button className="ois-header__hamburger" type="button" aria-label={t.header.openMenu}>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                            <path d="M3 5h14M3 10h14M3 15h14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                        </svg>
                    </button>
                    <span className="ois-header__app-name">{t.header.appName}</span>
                    <div className="ois-header__right">
                        <span className="ois-header__org">{t.header.orgLabel}</span>
                        <ProfileMenu
                            userName="Justin Time"
                            company="Wishing Well Investments"
                            department="Marketing and communications"
                            language={language}
                            onLanguageChange={setLanguage}
                            onNavigate={(path) => console.log('Navigate to:', path)}
                            onLogout={() => console.log('Logout')}
                        />
                    </div>
                </div>
                <nav className="ois-header__nav">
                    {tabs.map(({ label, path }) => (
                        <button
                            key={path}
                            className={`ois-header__nav-item ${activeTab === path ? 'ois-header__nav-item--active' : ''}`}
                            onClick={() => handleTabClick(path)}
                            type="button"
                        >
                            {label}
                        </button>
                    ))}
                </nav>
            </header>

            <main className="ois-main">
                {children}
            </main>
        </>
    );
}
