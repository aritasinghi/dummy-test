import type { ReactNode } from 'react';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from '@/api/queryClient';
import { ThemeProvider } from '@efi/efi-ui-components';
import type { Theme } from '@efi/efi-ui-components';
import { LanguageProvider } from '@/context/LanguageContext';
import { NavigationProvider } from '@/context/NavigationContext';
import { ModalProvider } from '@/context/ModalContext';

interface AppProvidersProps {
    theme?: Theme;
    children: ReactNode;
}

/**
 * Provider composition order:
 * 1. QueryClientProvider  — API cache (outermost, no UI dep)
 * 2. ThemeProvider         — CSS variables
 * 3. LanguageProvider      — i18n (en/sv/fi)
 * 4. NavigationProvider    — view routing + history
 * 5. ModalProvider         — modal open/close state
 * 6. (future) AuthProvider / UserProvider
 */
export function AppProviders({ theme = 'light', children }: AppProvidersProps) {
    return (
        <QueryClientProvider client={queryClient}>
            <ThemeProvider theme={theme}>
                <LanguageProvider defaultLanguage="en">
                    <NavigationProvider>
                        <ModalProvider>
                            {children}
                        </ModalProvider>
                    </NavigationProvider>
                </LanguageProvider>
            </ThemeProvider>
        </QueryClientProvider>
    );
}
