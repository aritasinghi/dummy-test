/**
 * Query key factory — centralized keys for cache management.
 *
 * Usage:
 *   queryKeys.reports.all()            → ['reports']
 *   queryKeys.reports.subscribed()     → ['reports', 'subscribed']
 *   queryKeys.reports.detail('abc')    → ['reports', 'detail', 'abc']
 */
export const queryKeys = {
    reports: {
        all: () => ['reports'] as const,
        subscribed: () => [...queryKeys.reports.all(), 'subscribed'] as const,
        available: () => [...queryKeys.reports.all(), 'available'] as const,
        detail: (id: string) => [...queryKeys.reports.all(), 'detail', id] as const,
    },
    subscriptions: {
        all: () => ['subscriptions'] as const,
        detail: (id: string) => [...queryKeys.subscriptions.all(), 'detail', id] as const,
    },
    organisation: {
        all: () => ['organisation'] as const,
        info: () => [...queryKeys.organisation.all(), 'info'] as const,
    },
    eventLog: {
        all: () => ['eventLog'] as const,
        list: (filters?: Record<string, unknown>) =>
            [...queryKeys.eventLog.all(), 'list', filters] as const,
    },
};
