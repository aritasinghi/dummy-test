import { QueryClient } from '@tanstack/react-query';

/**
 * TanStack Query client with enterprise defaults.
 *
 * - staleTime 5 min — avoids refetching on every mount
 * - gcTime 30 min — keeps cache warm across tab switches
 * - retry 2 — retries failed requests twice
 * - refetchOnWindowFocus false — prevents noisy refetches
 */
export const queryClient = new QueryClient({
    defaultOptions: {
        queries: {
            staleTime: 5 * 60 * 1000,
            gcTime: 30 * 60 * 1000,
            retry: 2,
            refetchOnWindowFocus: false,
        },
        mutations: {
            retry: 0,
        },
    },
});
