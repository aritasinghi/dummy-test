import {useState} from 'react';
import {
    Banner,
    Container,
    Header,
    Main,
    ProfileMenu,
    LanguageSelector as RawLanguageSelector,
} from '@efi/efi-ui-components';
import {translations} from '@/locales';
import type {Language} from '@/locales';
import {useCreateOrder} from '@/hooks/useReports';
import {SubscriptionModal} from '@/components/SubscriptionModal';
import ReportsPage from './ReportsPage';
import ReportPreview from './ReportPreview';
import type {SubscriptionFormData} from '@/components/SubscriptionModal';
import OrganisationPage from './OrganisationInfo/OrganisationPage.tsx';

// Cast to any to bypass mismatched library typings
const LanguageSelector = RawLanguageSelector as any;

type View =
    | { type: 'landing' }
    | { type: 'preview'; reportTypeId: number; reportTitle: string };

export default function LandingPage() {
    const [language, setLanguage] = useState<Language>('fi');
    const [activeTab, setActiveTab] = useState<string>('reports');

    const [currentView, setCurrentView] = useState<View>({type: 'landing'});
    const [subscribeModal, setSubscribeModal] = useState<{ open: boolean; reportTypeId: number; title: string }>({
        open: false,
        reportTypeId: 0,
        title: ''
    });
    const [successMsg, setSuccessMsg] = useState<string | null>(null);

    const createOrder = useCreateOrder();
    const t = translations[language];

    const tabs = [
        {label: t.tabs.reports, path: 'reports'},
        {label: t.tabs.log, path: 'log'},
        {label: t.tabs.organization, path: 'organization'},
    ];

    const goBack = () => setCurrentView({type: 'landing'});

    const handleSubscribeClick = (reportTypeId: number, title: string) => {
        setSubscribeModal({open: true, reportTypeId, title});
    };

    // -------------------------------
    // 🔵 Mapping function (UI → Backend)
    // -------------------------------
    function mapSubscriptionToOrderRequest(form: SubscriptionFormData, reportTypeId: number) {
        let reportDate: string;

        if (form.dateMode === "latest") {
            const d = new Date();
            d.setDate(d.getDate() - 1);
            reportDate = d.toISOString().slice(0, 10);
        } else if (form.dateMode === "end-of-day") {
            const d = new Date();
            reportDate = d.toISOString().slice(0, 10);
        } else {
            reportDate = form.selectedDate!.toISOString().slice(0, 10);
        }

        const instrumentMap: Record<string, number> = {
            "euroflex-a-1": 0,
            "euroflex-b-1": 1,
            "euroflex-b-2": 2,
            "euroflex-a-2": 3,
            "euroflex-b-3": 4,
            "euroflex-b-4": 5,
        };

        return {
            reportTypeId,
            organizationId: 1234567,
            userId: "demo_user",
            reportDate,
            instruments: form.selectedShares.map(v => instrumentMap[v]),
            referenceCode: form.reference || undefined,
        };
    }

    // -------------------------------
    // 🔵 Updated submit handler
    // -------------------------------
    const handleSubscribeSubmit = async (formData: SubscriptionFormData) => {
        try {
            const request = mapSubscriptionToOrderRequest(
                formData,
                subscribeModal.reportTypeId
            );

            const result = await createOrder.mutateAsync(request);

            setSubscribeModal({open: false, reportTypeId: 0, title: ''});
            setSuccessMsg(`Tilaus onnistui! Tilausnumero: ${result.reportOrderId}`);
            setTimeout(() => setSuccessMsg(null), 5000);
        } catch {
            alert('Tilauksen luonti epäonnistui.');
        }
    };

    const renderContent = () => {
        switch (currentView.type) {
            case 'preview':
                return (
                    <ReportPreview
                        reportTitle={currentView.reportTitle}
                        language={language}
                        onBack={goBack}
                        onSubscribe={() => handleSubscribeClick(currentView.reportTypeId, currentView.reportTitle)}
                    />
                );
            default:
                return (
                    <>
                        <Banner appName="MyEuroclear">
                            <Banner.Title>{t.tabs[activeTab as keyof typeof t.tabs]}</Banner.Title>
                        </Banner>
                        <Container>
                            {successMsg && (
                                <div style={{
                                    background: '#e0f5e9',
                                    border: '1px solid #00B9A4',
                                    borderRadius: 8,
                                    padding: '0.75rem 1rem',
                                    marginBottom: '1rem',
                                    color: '#006b5a',
                                    fontWeight: 600
                                }}>
                                    ✓ {successMsg}
                                </div>
                            )}

                            {activeTab === 'reports' && (
                                <ReportsPage
                                    language={language}
                                    onSubscribe={handleSubscribeClick}
                                    onShowPreview={(id, title) => setCurrentView({
                                        type: 'preview',
                                        reportTypeId: id,
                                        reportTitle: title
                                    })}
                                    onShowAllSubscribed={(id, title) => console.log('Show all:', id, title)}
                                    onShowLatest={(id, title) => console.log('Show latest:', id, title)}
                                />
                            )}

                            {activeTab === 'log' &&
                                <p style={{padding: '2rem', color: '#999'}}>Tapahtumaloki — tulossa pian</p>}
                            {activeTab === 'organization' &&(
                                <OrganisationPage language ={language}/>)}
                        </Container>
                    </>
                );
        }
    };

    return (
        <>
            <Header
                skipToContentLabel={t.header.skipToContent}
                drawerProps={{buttonOpen: t.header.openMenu, buttonClose: t.header.closeMenu}}
            >
                <Header.AppName>{t.header.appName}</Header.AppName>
                <Header.SecondaryTitle>
                    <span style={{whiteSpace: 'nowrap'}}>{t.header.orgLabel}</span>
                </Header.SecondaryTitle>

                <Header.Actions>
                    <ProfileMenu aria-label={t.profileMenu.yourProfile}>
                        <LanguageSelector
                            defaultSelected={language}
                            onSelect={(_e: unknown, value?: string) => {
                                if (value) setLanguage(value as Language);
                            }}
                        >
                            <LanguageSelector.Option value="en" lang="en-GB">English</LanguageSelector.Option>
                            {/* <LanguageSelector.Option value="sv" lang="sv-SE">Swedish</LanguageSelector.Option>*/}
                            <LanguageSelector.Option value="fi" lang="fi-FI">Finnish</LanguageSelector.Option>
                        </LanguageSelector>
                    </ProfileMenu>
                </Header.Actions>

                <Header.Navigation aria-label="Main navigation">
                    {tabs.map(({label, path}) => (
                        <Header.NavigationItem key={path} href={`/${path}`}
                                               onClick={(e: React.MouseEvent) => {
                                                   e.preventDefault();
                                                   setActiveTab(path);
                                                   goBack();
                                               }}>
                            {label}
                        </Header.NavigationItem>
                    ))}
                </Header.Navigation>
            </Header>

            <Main>{renderContent()}</Main>

            <SubscriptionModal
                isOpen={subscribeModal.open}
                reportTitle={subscribeModal.title}
                onClose={() => setSubscribeModal({open: false, reportTypeId: 0, title: ''})}
                onSubmit={handleSubscribeSubmit}
                language={language}
            />
        </>
    );
}