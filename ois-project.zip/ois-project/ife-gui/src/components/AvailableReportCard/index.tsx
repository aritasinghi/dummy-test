import { Button } from '@efi/efi-ui-components';
import './AvailableReportCard.css';

interface AvailableReportCardProps {
    title: string;
    description?: string;
    previewLabel: string;
    subscribeLabel: string;
    onPreview?: () => void;
    onSubscribe?: () => void;
}

export function AvailableReportCard({ title, description, previewLabel, subscribeLabel, onPreview, onSubscribe }: AvailableReportCardProps) {
    return (
        <div className="ois-avail-card">
            <div className="ois-avail-card__header">
                <h3 className="ois-avail-card__title">{title}</h3>
                <span className="ois-avail-card__plus">+</span>
            </div>

            {description && (
                <p className="ois-avail-card__desc">{description}</p>
            )}

            <div className="ois-avail-card__actions">
                <Button variant="secondary" onClick={onPreview}>{previewLabel}</Button>
                <Button variant="primary" onClick={onSubscribe}>{subscribeLabel}</Button>
            </div>
        </div>
    );
}
