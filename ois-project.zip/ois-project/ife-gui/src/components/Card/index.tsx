import { Button } from '@efi/efi-ui-components';
import './Card.css';

interface DataRow { name: string; percentage: number }

interface CardProps {
    title: string;
    badge?: string;
    data: DataRow[];
    lastReportDate: string;
    subscribedCount: number;
    showLatestLabel: string;
    showAllLabel: string;
    subscribeLabel: string;
    onShowLatest?: () => void;
    onShowAll?: () => void;
    onSubscribe?: () => void;
}

export function Card({ title, badge, data, lastReportDate, subscribedCount, showLatestLabel, showAllLabel, subscribeLabel, onShowLatest, onShowAll, onSubscribe }: CardProps) {
    const formatPct = (val: number) => val.toFixed(2).replace('.', ',') + ' %';

    return (
        <div className="ois-card">
            <div className="ois-card__header">
                <h3 className="ois-card__title">{title}</h3>
                {badge && <span className="ois-card__badge">{badge}</span>}
            </div>

            <div className="ois-card__data">
                {data.map((row) => (
                    <div key={row.name} className="ois-card__row">
                        <span className="ois-card__name">{row.name.toUpperCase()}</span>
                        <span className="ois-card__pct">{formatPct(row.percentage)}</span>
                    </div>
                ))}
            </div>

            <a className="ois-card__link" href="#" onClick={(e) => { e.preventDefault(); onShowLatest?.(); }}>
                {showLatestLabel}: {lastReportDate}
            </a>

            <div className="ois-card__actions">
                <Button variant="secondary" onClick={onShowAll}>{showAllLabel} ({subscribedCount})</Button>
                <Button variant="primary" onClick={onSubscribe}>+ {subscribeLabel}</Button>
            </div>
        </div>
    );
}
