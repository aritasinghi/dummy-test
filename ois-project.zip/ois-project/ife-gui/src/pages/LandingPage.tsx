import { useState } from 'react';
import {
    Banner, Container, Header, Main,
    LanguageSelector,
} from '@efi/efi-ui-components';
import { translations } from '@/locales';
import type { Language } from '@/locales';
import { useCreateOrder } from '@/hooks/useReports';
import { SubscriptionModal } from '@/components/SubscriptionModal';
import ReportsPage from './ReportsPage';
import ReportPreview from './ReportPreview';

type View =
    | { type: 'landing' }
    | { type: 'preview'; reportTypeId: number; reportTitle: string };

export default function LandingPage() {
    const [language, setLanguage] = useState<Language>("fi");
    const [activeTab, setActiveTab] = useState<string>("reports");
    const [currentView, setCurrentView] = useState<View>({ type: 'landing' });
    const [subscribeModal, setSubscribeModal] = useState<{ open: boolean; reportTypeId: number; title: string }>({ open: false, reportTypeId: 0, title: '' });
    const [successMsg, setSuccessMsg] = useState<string | null>(null);

    const createOrder = useCreateOrder();
    const t = translations[language];

    const tabs = [
        { label: t.tabs.reports, path: "reports" },
        { label: t.tabs.log, path: "log" },
        { label: t.tabs.organization, path: "organization" },
    ];

    const goBack = () => setCurrentView({ type: 'landing' });

    const handleSubscribeClick = (reportTypeId: number, title: string) => {
        setSubscribeModal({ open: true, reportTypeId, title });
    };

    const handleSubscribeSubmit = async () => {
        try {
            const result = await createOrder.mutateAsync({
                reportTypeId: subscribeModal.reportTypeId,
                organizationId: 1234567,
                userId: 'demo_user',
                reportDate: new Date().toISOString().split('T')[0],
                instruments: [1],
                referenceCode: 'REF-' + Date.now(),
            });
            setSubscribeModal({ open: false, reportTypeId: 0, title: '' });
            setSuccessMsg(`Tilaus onnistui! Tilausnumero: ${result.reportOrderId}`);
            setTimeout(() => setSuccessMsg(null), 5000);
        } catch {
            alert('Tilauksen luonti epäonnistui.');
        }
    };

    const renderContent = () => {
        switch (currentView.type) {
            case 'preview':
                return (
                    <ReportPreview
                        reportTitle={currentView.reportTitle}
                        language={language}
                        onBack={goBack}
                        onSubscribe={() => handleSubscribeClick(currentView.reportTypeId, currentView.reportTitle)}
                    />
                );
            default:
                return (
                    <>
                        <Banner appName="MyEuroclear">
                            <Banner.Title>{t.tabs[activeTab as keyof typeof t.tabs]}</Banner.Title>
                        </Banner>
                        <Container>
                            {successMsg && (
                                <div style={{ background: '#e0f5e9', border: '1px solid #00B9A4', borderRadius: 8, padding: '0.75rem 1rem', marginBottom: '1rem', color: '#006b5a', fontWeight: 600 }}>
                                    ✓ {successMsg}
                                </div>
                            )}
                            {activeTab === 'reports' && (
                                <ReportsPage
                                    language={language}
                                    onSubscribe={handleSubscribeClick}
                                    onShowPreview={(id, title) => setCurrentView({ type: 'preview', reportTypeId: id, reportTitle: title })}
                                    onShowAllSubscribed={(id, title) => console.log('Show all:', id, title)}
                                    onShowLatest={(id, title) => console.log('Show latest:', id, title)}
                                />
                            )}
                            {activeTab === 'log' && <p style={{ padding: '2rem', color: '#999' }}>Tapahtumaloki — tulossa pian</p>}
                            {activeTab === 'organization' && <p style={{ padding: '2rem', color: '#999' }}>Organisaation tiedot — tulossa pian</p>}
                        </Container>
                    </>
                );
        }
    };

    return (
        <>
            {/* ── Header: simplified, org right-aligned, only lang selector ── */}
            <Header
                skipToContentLabel={t.header.skipToContent}
                drawerProps={{ buttonOpen: t.header.openMenu, buttonClose: t.header.closeMenu }}
            >
                <Header.AppName>{t.header.appName}</Header.AppName>

                <Header.Actions>
                    {/* Org name + lang selector only */}
                    <span style={{ fontSize: '0.875rem', color: '#555', marginRight: '0.5rem' }}>{t.header.orgLabel}</span>
                    <LanguageSelector
                        defaultSelected={language}
                        onSelect={(_e: unknown, value?: string) => { if (value) setLanguage(value as Language); }}
                    >
                        <LanguageSelector.Option value="en" lang="en-GB" />
                        <LanguageSelector.Option value="sv" lang="sv-SE" />
                        <LanguageSelector.Option value="fi" lang="fi-FI" />
                    </LanguageSelector>
                </Header.Actions>

                <Header.Navigation aria-label="Main navigation">
                    {tabs.map(({ label, path }) => (
                        <Header.NavigationItem key={path} href={`/${path}`}
                            onClick={(e: React.MouseEvent) => { e.preventDefault(); setActiveTab(path); goBack(); }}>
                            {label}
                        </Header.NavigationItem>
                    ))}
                </Header.Navigation>
            </Header>

            <Main>{renderContent()}</Main>

            {/* ── Subscription Modal ── */}
            <SubscriptionModal
                isOpen={subscribeModal.open}
                reportTitle={subscribeModal.title}
                onClose={() => setSubscribeModal({ open: false, reportTypeId: 0, title: '' })}
                onSubmit={handleSubscribeSubmit}
                language={language}
            />
        </>
    );
}
