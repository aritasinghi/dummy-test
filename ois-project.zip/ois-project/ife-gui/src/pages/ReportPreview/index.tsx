import { Banner, Button, Container } from '@efi/efi-ui-components';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import './ReportPreview.css';

interface ReportPreviewProps {
    reportTitle: string;
    language: Language;
    onBack: () => void;
    onSubscribe: () => void;
}

const REPORT_ROWS = [
    'Osakkeiden määrä',
    'Osakkeiden yhteismäärä, osuus osakkeiden kokonaismäärästä',
    'Henkilö- ja yksilöintitunnus',
    'Maksu- ja verotustiedot, tilinhoitajatieto',
    'Osoitetiedot, maatieto, turvakielliset',
    'Äänimäärätiedot',
    'Sektoritieto',
    'Asiakasrajoitus',
];

const MATRIX: Record<string, boolean[]> = {
    'Osakkeiden määrä':         [true, true, true, true],
    'Osakkeiden yhteismäärä, osuus osakkeiden kokonaismäärästä': [true, true, true, true],
    'Henkilö- ja yksilöintitunnus': [true, true, true, true],
    'Maksu- ja verotustiedot, tilinhoitajatieto': [true, true, true, false],
    'Osoitetiedot, maatieto, turvakielliset': [true, true, true, true],
    'Äänimäärätiedot':          [true, false, false, false],
    'Sektoritieto':             [true, false, false, false],
    'Asiakasrajoitus':          [true, false, false, false],
};

export default function ReportPreview({ reportTitle, language, onBack, onSubscribe }: ReportPreviewProps) {
    const t = translations[language].reportPreview;
    const cols = [t.full, t.agm, t.statutory, t.short];

    return (
        <>
            <Banner appName="MyEuroclear">
                <Banner.Title>
                    <span className="rp__bc">{t.breadcrumbRoot} {'>'} {t.breadcrumbReports}</span>
                </Banner.Title>
                <Banner.Subtitle>{t.title} {reportTitle}</Banner.Subtitle>
            </Banner>

            <Container>
                {/* Content + action buttons */}
                <div className="rp__top-row">
                    <div className="rp__top-left">
                        <h2 className="rp__h2">{t.orderableDataTitle}: {reportTitle}</h2>
                        <h3 className="rp__h3">{t.whatIsThisTitle}</h3>
                        <p className="rp__desc">{t.whatIsThisDesc}</p>
                    </div>
                    <div className="rp__top-actions">
                        <Button variant="secondary" onClick={onBack}>{t.back}</Button>
                        <Button variant="primary" onClick={onSubscribe}>{t.toSubscription}</Button>
                    </div>
                </div>

                {/* Matrix table */}
                <h3 className="rp__matrix-title">{t.reportTypesTitle}</h3>
                <table className="rp__table">
                    <thead>
                        <tr>
                            <th className="rp__th-label" />
                            {cols.map(c => <th key={c} className="rp__th-col">{c}</th>)}
                        </tr>
                    </thead>
                    <tbody>
                        {REPORT_ROWS.map(row => (
                            <tr key={row}>
                                <td className="rp__td-label">{row}</td>
                                {MATRIX[row].map((ok, i) => (
                                    <td key={i} className="rp__td-check">
                                        {ok && <svg width="20" height="20" viewBox="0 0 20 20"><rect x="1" y="1" width="18" height="18" rx="3" fill="#00B9A4"/><path d="M6 10l3 3 5-6" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                                    </td>
                                ))}
                            </tr>
                        ))}
                    </tbody>
                </table>

                {/* Example image */}
                <h3 className="rp__h3" style={{ marginTop: '2rem' }}>{t.exampleTitle}</h3>
                <div className="rp__example-img">
                    {/* Place your Figma screenshot as: public/images/report-example.png */}
                    <img
                        src="/images/report-example.png"
                        alt="Report example"
                        className="rp__example-screenshot"
                        onError={(e) => {
                            // Fallback if image not found — show placeholder
                            (e.target as HTMLImageElement).style.display = 'none';
                            (e.target as HTMLImageElement).parentElement!.classList.add('rp__example-fallback');
                        }}
                    />
                </div>
            </Container>
        </>
    );
}
