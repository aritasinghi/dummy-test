// ─── ReportView Static Data ───────────────────────────────────────────────────
// TODO: Replace OWNER_ROWS and SUMMARY_ROWS with real API calls via useReportData hook

import type { OwnerRow, SummaryRow, ShareInfo } from './types';

export const SHOW_DATA_KEYS = ['address', 'isin', 'expired', 'sector', 'custodian'] as const;
export type ShowDataKey = (typeof SHOW_DATA_KEYS)[number];

export const INITIAL_CHIP_KEYS = [
    { key: 'directly',   count: 2379, active: true  },
    { key: 'nominee',    count: 12,   active: false  },
    { key: 'companies',  count: 1112, active: true   },
    { key: 'financial',  count: 23,   active: false  },
    { key: 'households', count: 1856, active: true   },
] as const;

// ─── Shares metadata (header card) ───────────────────────────────────────────

export const SHARES_INFO: ShareInfo[] = [
    { name: 'EUROFLEX A', isin: 'FI21049685930', abbr: 'EUROFLA' },
    { name: 'EUROFLEX B', isin: 'FI21049685931', abbr: 'EUROFLB' },
    { name: 'EUROFLEX C', isin: 'FI21049685932', abbr: 'EUROFLC' },
];

// ─── Summary table rows ───────────────────────────────────────────────────────

export const SUMMARY_ROWS: SummaryRow[] = [
    { aoLaji: 'EUROFLA', omistajien: '1 300', yhteis: '12', kaikkien: '1 006 970', osuus: '50,3 %',  kokonaisAani: '2 000 000', osakas: '503 488', odotus: '5 000', hallinta: '10 000', yhteistili: '481 512', liikkeeseen: '1 000 000', bold: false, isTotal: false },
    { aoLaji: 'EUROFLB', omistajien: '600',   yhteis: '24', kaikkien: '285 369',   osuus: '71,3 %',  kokonaisAani: '400 000',   osakas: '285 369', odotus: '4 800', hallinta: '18 995', yhteistili: '90 836',  liikkeeseen: '400 000',   bold: false, isTotal: false },
    { aoLaji: 'total',   omistajien: '1 900', yhteis: '36', kaikkien: '1 292 339', osuus: '53,8 %',  kokonaisAani: '2 400 000', osakas: '788 857', odotus: '9 800', hallinta: '28 995', yhteistili: '572 348', liikkeeseen: '1 400 000', bold: true,  isTotal: true  },
];

// ─── Owner rows (mock — replace with API) ────────────────────────────────────

export const OWNER_ROWS: OwnerRow[] = [
    {
        id: 1, name: 'Thomas-Peter Along-lastname', ssn: '120370-8902A', dob: '12.03.1970',
        address: 'Arvo-osuuskuja 212', postAddress: '00550 Espoo', country: 'Espoo, Suomi',
        city: 'Espoo', situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',     amount: '30 300', pct: '3,03000', votes: '60 900', votePct: '2,54000' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '600',    pct: '0,15000', votes: '',       votePct: '' },
            { type: 'Arvo-osuudet yhteensä', custodian: '', amount: '30 900', pct: '2,21000', votes: '60 900', votePct: '2,54000', isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 2, name: 'Clarck Confidential', ssn: '020377-02908', dob: '02.03.1977',
        isRestricted: true,
        address: 'Yhteyssoite: Jokitie 22 b', postAddress: '00100 Helsinki', country: 'Tai Ei osoitetta',
        city: '', situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',     amount: '15', pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX A', custodian: 'Nordea', amount: '15', pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX B', custodian: 'OP',     amount: '40', pct: '0,00004', votes: '100', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', custodian: '', amount: '70', pct: '0,00003', votes: '100', votePct: '0,00003', isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 3, name: 'D-Yritys OY Ab', ssn: 'T769765-S', dob: '', asiakasrajoitus: 'konkurssi',
        isCompany: true, city: 'Helsinki',
        address: 'Arvopaperitie 12', postAddress: '00100 Helsinki', country: 'Helsinki, Suomi',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',     amount: '30', pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '40', pct: '0,00004', votes: '100', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', custodian: '', amount: '70', pct: '0,00003', votes: '100', votePct: '0,00003', isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 4, name: 'Thomas Elling', ssn: '200274-89020', dob: '20.02.1974',
        isJoint: true, asiakasrajoitus: 'kuolinpesä', city: 'Helsinki',
        address: 'Thomaksentie 12', postAddress: '00100 Helsinki', country: 'Helsinki, Suomi',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',       amount: '30', pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX B', custodian: 'Nordea',   amount: '40', pct: '0,00004', votes: '160', votePct: '0,00003' },
            { type: 'EUROFLEX A', custodian: 'Third LTD',amount: '20', pct: '0,00003', votes: '',    votePct: '' },
            { type: 'EUROFLEX B', custodian: '4TH LTD',  amount: '20', pct: '0,00003', votes: '',    votePct: '' },
            { type: 'Arvo-osuudet yhteensä', custodian: '', amount: '110', pct: '0,00003', votes: '160', votePct: '0,00003', isTotal: true },
        ],
        jointOwners: [{ name: 'Tiina Ollila' }, { name: 'Veijo Välisää', linkable: true }],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 5, name: 'Thomas Elling', ssn: '200274-89020', dob: '20.02.1974',
        isJoint: true, city: 'Helsinki',
        address: 'Thomaksentie 12', postAddress: '00100 Helsinki', country: 'Helsinki, Suomi',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',     amount: '30', pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '40', pct: '0,00004', votes: '603', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', custodian: '', amount: '70', pct: '0,00003', votes: '603', votePct: '0,00003', isTotal: true },
        ],
        jointOwners: [{ name: 'Tiina Ollila' }, { name: 'Veijo Välisää', linkable: true }],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 6, name: 'William Elling', ssn: '180372-89020', dob: '18.03.1972',
        city: 'Helsinki', address: 'Viljaminkuja 22 b 33', postAddress: '00100 Helsinki', country: 'Helsinki, Suomi',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',     amount: '30', pct: '0,00005', votes: '',    votePct: '' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '40', pct: '0,00004', votes: '603', votePct: '0,00003' },
            { type: 'Arvo-osuudet yhteensä', custodian: '', amount: '70', pct: '0,00003', votes: '603', votePct: '0,00003', isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 7, name: 'Elli Ollinen', ssn: '120378-1902B', dob: '12.03.1978',
        isJointSubRow: true, jointParent: 'Thomas Elling',
        city: 'Helsinki', address: 'Elisenkuja 6 B', postAddress: '00100 Helsinki', country: 'Helsinki, Suomi',
        shares: [], sektori: '', maksu: '', vero: '',
    },
    {
        id: 8, name: 'Sakari Penttinen', ssn: '220368-3456A', dob: '23.03.1968',
        city: 'Helsinki', address: 'Sakarianpolku 1 C', postAddress: '00100 Helsinki', country: 'Helsinki, Suomi',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP', amount: '30', pct: '0,00005', votes: '3', votePct: '0,00005' },
            { type: 'Arvo-osuudet yhteensä', custodian: '', amount: '30', pct: '0,00005', votes: '3', votePct: '0,00005', isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
    {
        id: 9, name: 'SEC Custody Bank', ssn: '1169765-6', dob: '',
        isBank: true, isNominee: true, city: 'Helsinki',
        address: 'Pankkiirinkatu 32', postAddress: '00100 Helsinki', country: 'Helsinki, Suomi',
        situationDate: '31/12/2024',
        shares: [
            { type: 'EUROFLEX A', custodian: 'OP',     amount: '120', pct: '0,00010', votes: '70', votePct: '0,00010' },
            { type: 'EUROFLEX B', custodian: 'Nordea', amount: '60',  pct: '0,00010', votes: '',   votePct: '' },
            { type: 'Arvo-osuudet yhteensä', custodian: '', amount: '180', pct: '0,00008', votes: '70', votePct: '0,00010', isTotal: true },
        ],
        sektori: 'Julkiset yritykset pl. asuntoyhteisö', maksu: 'FI1234567787788', vero: 'TBC',
    },
];
