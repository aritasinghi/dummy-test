// ─── ReportView Types ─────────────────────────────────────────────────────────

export type ReportType = 'statutory' | 'full' | 'agm' | 'short';
export type SortField  = 'name' | 'bookEntries' | 'votes';
export type SortDir    = 'asc' | 'desc';

export interface ShareRow {
    type:      string;
    custodian?: string;
    amount:    string;
    pct:       string;
    votes:     string;
    votePct:   string;
    isTotal?:  boolean;
}

export interface OwnerRow {
    id:                number;
    name:              string;
    ssn:               string;
    dob:               string;
    asiakasrajoitus?:  string;
    isRestricted?:     boolean;
    isJoint?:          boolean;
    isNominee?:        boolean;
    isBank?:           boolean;
    isCompany?:        boolean;
    city?:             string;
    address:           string;
    postAddress:       string;
    country:           string;
    shares:            ShareRow[];
    sektori:           string;
    maksu:             string;
    vero:              string;
    situationDate?:    string;
    jointOwners?:      { name: string; linkable?: boolean }[];
    isJointSubRow?:    boolean;
    jointParent?:      string;
}

export interface SummaryRow {
    aoLaji:       string;
    omistajien:   string;
    yhteis:       string;
    kaikkien:     string;
    osuus:        string;
    kokonaisAani: string;
    osakas:       string;
    odotus:       string;
    hallinta:     string;
    yhteistili:   string;
    liikkeeseen:  string;
    bold:         boolean;
    isTotal:      boolean;
}

export interface ShareInfo {
    name: string;
    isin: string;
    abbr: string;
}

/** Which columns to SHOW for each report type — only shown cols are rendered */
export type ColVisibility = {
    addr:      boolean; // Street + post + country
    city:      boolean; // Municipality only (AGM)
    custodian: boolean;
    pct:       boolean;
    votes:     boolean;
    votePct:   boolean;
    date:      boolean;
    sector:    boolean;
    payment:   boolean;
    tax:       boolean;
};

/** Whether the Show details + Filtering sections appear (only for Full) */
export const SHOW_FILTERS_FOR: Record<ReportType, boolean> = {
    statutory: false,
    full:      true,
    agm:       false,
    short:     false,
};

export const COLS: Record<ReportType, ColVisibility> = {
    //            addr   city   cust   pct    votes  vpct   date   sec    pay    tax
    statutory: { addr: true,  city: false, custodian: true,  pct: false, votes: false, votePct: false, date: false, sector: false, payment: true,  tax: true  },
    full:      { addr: true,  city: false, custodian: true,  pct: true,  votes: true,  votePct: true,  date: false, sector: true,  payment: true,  tax: true  },
    agm:       { addr: false, city: true,  custodian: false, pct: false, votes: false, votePct: false, date: false, sector: false, payment: false, tax: false },
    short:     { addr: false, city: false, custodian: true,  pct: true,  votes: false, votePct: false, date: false, sector: false, payment: false, tax: false },
};
