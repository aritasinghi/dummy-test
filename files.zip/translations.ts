/**
 * OIS Portal translations — English, Swedish (sv), Finnish (fi)
 *
 * Central source of truth for all UI text.
 * When adding new strings, add to ALL three languages.
 */

export type Language = 'en' | 'sv' | 'fi';

export interface Translations {
    welcome: string;
    tabs: {
        reports: string;
        log: string;
        organization: string;
    };
    content: {
        reports: string;
        log: string;
        organization: string;
    };
    header: {
        appName: string;
        orgLabel: string;
        skipToContent: string;
        openMenu: string;
        closeMenu: string;
    };
    reports: {
        subscribedTitle: string;
        availableTitle: string;
        showLatestReport: string;
        showAllSubscribed: string;
        subscribeNew: string;
        showPreview: string;
        subscribe: string;
    };
    subscription: {
        title: string;
        oneTime: string;
        recurring: string;
        oneTimeTitle: string;
        recurringTitle: string;
        /** One-time date mode options */
        reportDateTitle: string;
        dateLatest: string;
        dateEndOfDay: string;
        dateSelectCustom: string;
        selectDateLabel: string;
        dateInfoTitle: string;
        dateInfoDesc: string;
        /** Recurring frequency */
        frequencyTitle: string;
        daily: string;
        monthly: string;
        monthlyLast: string;
        quarterly: string;
        quarterlyLast: string;
        yearly: string;
        selectDay: string;
        frequencyInfoTitle: string;
        frequencyInfoMonthly: string;
        frequencyInfoMonthlyNote: string;
        frequencyInfoQuarterly: string;
        frequencyInfoYearly: string;
        /** Shares + reference */
        sharesTitle: string;
        shareType: string;
        shareSelectionTitle: string;
        shareSelectionDesc: string;
        referenceLabel: string;
        referencePlaceholder: string;
        referenceInfoTitle: string;
        referenceInfoDesc: string;
        priceNote: string;
        priceNextView: string;
        cancel: string;
        submit: string;
    };
    datePicker: {
        title: string;
        cancel: string;
        done: string;
        selectTime: string;
        months: string[];
        weekdays: string[];
        quickPicks: {
            threeDaysAgo: string;
            twoDaysAgo: string;
            yesterday: string;
            today: string;
            tomorrow: string;
            nextWeek: string;
        };
    };
    profileMenu: {
        yourProfile: string;
        companyLabel: string;
        departmentLabel: string;
        dashboard: string;
        profile: string;
        notAvailable: string;
        logout: string;
        selectLanguage: string;
    };
    /** Report preview page */
    reportPreview: {
        breadcrumbRoot: string;
        breadcrumbReports: string;
        title: string;
        orderableDataTitle: string;
        whatIsThisTitle: string;
        whatIsThisDesc: string;
        reportTypesTitle: string;
        full: string;
        agm: string;
        statutory: string;
        short: string;
        exampleTitle: string;
        back: string;
        toSubscription: string;
    };
    /** Full report view page */
    reportView: {
        downloadFile: string;
        tabReport: string;
        tabSubscriptionInfo: string;
        summaryTitle: string;
        reportTypeTitle: string;
        fullDesc: string;
        agmDesc: string;
        statutoryDesc: string;
        shortDesc: string;
        showDataTitle: string;
        filterTitle: string;
        fileDownloadTitle: string;
        fileDownloadDesc: string;
        infoTitle: string;
        issuer: string;
        reportName: string;
        orderDate: string;
        situationDate: string;
        shareNameLabel: string;
        isinLabel: string;
        abbreviationLabel: string;
        searchPlaceholder: string;
        filteredSummary: string;
        owners: string;
        shares: string;
        back: string;
        toSubscription: string;
        first: string;
        last: string;
        /* ── Owner table column headers ── */
        colName: string;
        colIdentCode: string;
        colDob: string;
        colCustomerRestrictions: string;
        colStreetAddress: string;
        colPostAddress: string;
        colMunicipality: string;
        colMunicipalityCountry: string;
        colBookEntryType: string;
        colDepositoryParticipant: string;
        colNumberOfBookEntries: string;
        colPctBookEntries: string;
        colNumberOfVotes: string;
        colPctVotingRights: string;
        colSituationDate: string;
        colSector: string;
        colPaymentInfo: string;
        colTaxInfo: string;
        /* ── Summary table column headers ── */
        summColBookEntry: string;
        summColOwners: string;
        summColJointOwners: string;
        summColVotesConferred: string;
        summColPctVotes: string;
        summColTotalVotes: string;
        summColInShareholderList: string;
        summColInWaitingList: string;
        summColNomineeReg: string;
        summColJointAccount: string;
        summColIssuedAmount: string;
        /* ── Filter chips ── */
        chipDirectly: string;
        chipNominee: string;
        chipCompanies: string;
        chipFinancial: string;
        chipHouseholds: string;
        /* ── Legend ── */
        legendNonDisclosure: string;
        legendJointOwnership: string;
        legendNomineeHolding: string;
        legendNomineeCustodians: string;
        /* ── Show details options ── */
        showOptAddress: string;
        showOptIsin: string;
        showOptExpired: string;
        showOptSector: string;
        showOptCustodian: string;
        /* ── Sidebar descriptions ── */
        sidebarFull: string;
        sidebarAgm: string;
        sidebarStatutory: string;
        sidebarShort: string;
        /* ── Row labels ── */
        customerRestriction: string;
        totalSharesLabel: string;
        summaryTotal: string;
        jointSubLabel: string;
        jointParentLabel: string;
        flagNomineeReg: string;
        flagNonDisclosure: string;
        flagNominee: string;
        fileDownloadSidebarDesc: string;
        reportTypeStatutoryTitle: string;
        reportTypeStatutoryDesc: string;
        reportTypeFullTitle: string;
        reportTypeFullDesc: string;
        reportTypeAgmTitle: string;
        reportTypeAgmDesc: string;
        reportTypeShortTitle: string;
        reportTypeShortDesc: string;
    };
    /** Subscribed reports list (Tilatut raportit) */
    subscribedReports: {
        title: string;
        availabilityNote: string;
        colDate: string;
        colOrdered: string;
        colFrequency: string;
        colReference: string;
        colStatus: string;
        statusReady: string;
        statusProcessing: string;
        oneTime: string;
        monthly: string;
    };
    /** Download modal ("Lataa tiedostona") */
    downloadModal: {
        title: string;
        reportTypeTitle: string;
        filterTitle: string;
        filterUserVersion: string;
        fileTypeTitle: string;
        languageTitle: string;
        cancel: string;
        download: string;
    };
    common: {
        loading: string;
        error: string;
        retry: string;
        noData: string;
        save: string;
        close: string;
        back: string;
        next: string;
        confirm: string;
        delete: string;
        edit: string;
        search: string;
    };
}

const en: Translations = {
    welcome: "Welcome to the landing page",
    tabs: { reports: "Reports", log: "Event Log", organization: "Organization Info" },
    content: { reports: "Reports content goes here", log: "Event log content goes here", organization: "Organization info content goes here" },
    header: { appName: "Information Elements by Euroclear", orgLabel: "Organisation: Euroflex", skipToContent: "Skip to main content", openMenu: "Open menu", closeMenu: "Close menu" },
    reports: { subscribedTitle: "Subscribed report types", availableTitle: "Other available report types", showLatestReport: "Show latest report", showAllSubscribed: "SHOW ALL SUBSCRIBED REPORTS", subscribeNew: "+ SUBSCRIBE NEW REPORT", showPreview: "SHOW PREVIEW", subscribe: "SUBSCRIBE REPORT" },
    subscription: {
        title: "Subscribe new report", oneTime: "One-time order", recurring: "Recurring order", oneTimeTitle: "One-time order", recurringTitle: "Recurring order",
        reportDateTitle: "Report date", dateLatest: "Latest situation,\nimmediately available", dateEndOfDay: "End of day situation,\navailable tomorrow", dateSelectCustom: "Select report date", selectDateLabel: "Select date",
        dateInfoTitle: "Select report date", dateInfoDesc: "If the date is in the past, the report will be ready after a moment from placing the order. If the selected date is in the future, the report will be ready on the following business day. If the selected date falls on a weekend, the report is delivered from the preceding business day's situation.\nLatest situation ....",
        frequencyTitle: "Order frequency",
        daily: "Once a day", monthly: "Once a month", monthlyLast: "Once a month,\nlast day of month", quarterly: "Once a quarter", quarterlyLast: "Once a quarter,\nlast day of quarter", yearly: "Once a year", selectDay: "Select day",
        frequencyInfoTitle: "Order frequency",
        frequencyInfoMonthly: "The selected report is delivered once a month.\nPrice impact: report generated once a month.",
        frequencyInfoMonthlyNote: "Consider how the date selection is made for month, quarter and year.\n\"Once a month on day X\" (if selected day 29-31, the condition applies \"if the month has fewer days, the report is generated on the last day\")\n\"Once a quarter, on day X of month X\" (in June 30 days)\n\"Once a year, select day\"",
        frequencyInfoQuarterly: "The selected report is delivered once a quarter.\nPrice impact: report generated once a quarter.",
        frequencyInfoYearly: "The selected report is delivered once a year.\nPrice impact: report generated once a year.",
        sharesTitle: "Value shares and reference", shareType: "Value share type: Shares", shareSelectionTitle: "Share series (class) selection", shareSelectionDesc: "You can select one or more share series for the report.\nPrice impact: described in the next view.",
        referenceLabel: "Order reference", referencePlaceholder: "1234567890", referenceInfoTitle: "Order reference (optional)", referenceInfoDesc: "You can choose a reference for the order. This information will appear on the invoice.",
        priceNote: "*Price includes base fee and delivery fee. Price consists of...", priceNextView: "Report price will be shown in the next view", cancel: "CANCEL", submit: "CONTINUE",
    },
    datePicker: {
        title: "Select day", cancel: "CANCEL", done: "DONE", selectTime: "Select time",
        months: ["January","February","March","April","May","June","July","August","September","October","November","December"],
        weekdays: ["Mo","Tu","We","Th","Fr","Sa","Su"],
        quickPicks: { threeDaysAgo: "3 days ago", twoDaysAgo: "2 days ago", yesterday: "Yesterday", today: "Today", tomorrow: "Tomorrow", nextWeek: "Next week" },
    },
    profileMenu: { yourProfile: "Your profile", companyLabel: "Company", departmentLabel: "Department", dashboard: "Dashboard", profile: "Profile", notAvailable: "Not available", logout: "Logout", selectLanguage: "Select language" },
    reportPreview: {
        breadcrumbRoot: "INFORMATION ELEMENTS", breadcrumbReports: "REPORTS", title: "Report preview", orderableDataTitle: "Data to be ordered", whatIsThisTitle: "What kind of data is this?", whatIsThisDesc: "The report is a list...",
        reportTypesTitle: "Report types included in the orderable data:", full: "Full", agm: "AGM", statutory: "Statutory", short: "Short", exampleTitle: "Example of the data:", back: "< BACK", toSubscription: "TO REPORT SUBSCRIPTION →",
    },
    reportView: {
        downloadFile: "DOWNLOAD FILE", tabReport: "REPORT", tabSubscriptionInfo: "SUBSCRIPTION INFO",
        summaryTitle: "Report summary", reportTypeTitle: "Report type", fullDesc: "All available data", agmDesc: "Shareholder list for AGM", statutoryDesc: "Statutory data", shortDesc: "Owner names and share counts",
        showDataTitle: "Show data", filterTitle: "Filtering", fileDownloadTitle: "File download", fileDownloadDesc: "You can choose what version and format...",
        infoTitle: "Information", issuer: "Issuer", reportName: "Report name", orderDate: "Order date", situationDate: "Situation date",
        shareNameLabel: "Share name", isinLabel: "ISIN code", abbreviationLabel: "Abbreviation",
        searchPlaceholder: "Search owner by name", filteredSummary: "Filtered: {owners} owners, {shares} shares",
        owners: "owners", shares: "shares", back: "BACK", toSubscription: "TO REPORT SUBSCRIPTION →", first: "First", last: "Last",
        colName: "NAME", colIdentCode: "IDENTIFICATION CODE", colDob: "DATE OF BIRTH", colCustomerRestrictions: "CUSTOMER RESTRICTIONS",
        colStreetAddress: "STREET ADDRESS", colPostAddress: "POST ADDRESS", colMunicipality: "MUNICIPALITY", colMunicipalityCountry: "MUNICIPALITY, COUNTRY",
        colBookEntryType: "NAME OF THE BOOK-ENTRY TYPE", colDepositoryParticipant: "DEPOSITORY PARTICIPANT",
        colNumberOfBookEntries: "NUMBER OF BOOK-ENTRIES", colPctBookEntries: "PERCENTAGE OF BOOK-ENTRIES COMBINED",
        colNumberOfVotes: "NUMBER OF VOTES", colPctVotingRights: "PERCENTAGE OF TOTAL VOTING RIGHTS",
        colSituationDate: "SITUATION DATE", colSector: "SECTOR", colPaymentInfo: "PAYMENT INFORMATION", colTaxInfo: "TAX INFORMATION",
        summColBookEntry: "BOOK-ENTRY TYPE", summColOwners: "NUMBER OF OWNERS AND NOMINEE-REGISTRATION CUSTODIANS",
        summColJointOwners: "NUMBER OF JOINT OWNERS", summColVotesConferred: "NUMBER OF VOTES CONFERRED BY ALL THE BOOK-ENTRIES IN BOOK-ENTRY ACCOUNTS",
        summColPctVotes: "PERCENTAGE OF VOTES CONFERRED BY ALL THE BOOK-ENTRIES", summColTotalVotes: "TOTAL NUMBER OF VOTES",
        summColInShareholderList: "IN THE SHAREHOLDER LIST", summColInWaitingList: "IN THE WAITING LIST",
        summColNomineeReg: "NOMINEE-REGISTERED", summColJointAccount: "IN THE JOINT ACCOUNT", summColIssuedAmount: "ISSUED AMOUNT",
        chipDirectly: "Directly-registered holdings", chipNominee: "Nominee-registered holdings", chipCompanies: "Companies",
        chipFinancial: "Financial and insurance institutions", chipHouseholds: "Households",
        legendNonDisclosure: "Non-disclosure", legendJointOwnership: "Joint ownership",
        legendNomineeHolding: "Nominee-registered holding", legendNomineeCustodians: "Nominee Registration Custodians",
        showOptAddress: "Address information subject to non-disclosure", showOptIsin: "Identification code",
        showOptExpired: "Discontinued book-entry types", showOptSector: "Sector information", showOptCustodian: "Depository participant",
        sidebarFull: "Full: As the name suggests, includes the complete content of the report with additional details.\nGeneral Meeting: The shareholder register available at the General Meeting.\nIssuer's Shareholder List: Includes the information required under the Finnish Limited Liability Companies Act.\nShort: The report includes names of shareholders and number of shares.",
        sidebarAgm: "General Meeting: The shareholder register available at the General Meeting. Includes only the information required under the Finnish Limited Liability Companies Act.",
        sidebarStatutory: "Issuer's Shareholder List: Includes the information required under the Finnish Limited Liability Companies Act.",
        sidebarShort: "Short: The report includes the names of shareholders or nominee registration custodians and the number of book-entries per book-entry type.",
        customerRestriction: "Customer restriction", totalSharesLabel: "Total book-entries",
        summaryTotal: "Total", jointSubLabel: "Included in joint ownership",
        jointParentLabel: "Right holder", flagNomineeReg: "Nominee Registration Custodian",
        flagNonDisclosure: "Non-disclosure", flagNominee: "Nominee-registered",
        fileDownloadSidebarDesc: "In the file download window, you can choose which report type you want to download and in which file format. You can also choose whether to download the file using the selections and filters applied in this view, or in its original format.",
        reportTypeStatutoryTitle: "Issuer's shareholder list", reportTypeStatutoryDesc: "Statutory information",
        reportTypeFullTitle: "Full", reportTypeFullDesc: "All available information",
        reportTypeAgmTitle: "General meeting", reportTypeAgmDesc: "Shareholder register for the general meeting",
        reportTypeShortTitle: "Short", reportTypeShortDesc: "Names of shareholders and number of shares",
    },
    subscribedReports: {
        title: "Subscribed reports", availabilityNote: "Completed reports are available in the service for 60 days.",
        colDate: "REPORT DATE", colOrdered: "ORDERED", colFrequency: "ORDER FREQUENCY", colReference: "ORDER REFERENCE", colStatus: "ORDER STATUS",
        statusReady: "Ready", statusProcessing: "Processing", oneTime: "One-time order", monthly: "Once a month",
    },
    downloadModal: {
        title: "Download as file", reportTypeTitle: "Report type", filterTitle: "Filtering", filterUserVersion: "Download user filtered version",
        fileTypeTitle: "File type", languageTitle: "Language", cancel: "CANCEL", download: "DOWNLOAD",
    },
    common: { loading: "Loading...", error: "An error occurred", retry: "Retry", noData: "No data available", save: "Save", close: "Close", back: "Back", next: "Next", confirm: "Confirm", delete: "Delete", edit: "Edit", search: "Search" },
};

const sv: Translations = {
    welcome: "Välkommen till startsidan",
    tabs: { reports: "Rapporter", log: "Händelselogg", organization: "Organisationsinfo" },
    content: { reports: "Rapportinnehåll visas här", log: "Händelselogg visas här", organization: "Organisationsinfo visas här" },
    header: { appName: "Information Elements by Euroclear", orgLabel: "Organisation: Euroflex", skipToContent: "Hoppa till huvudinnehåll", openMenu: "Öppna meny", closeMenu: "Stäng meny" },
    reports: { subscribedTitle: "Prenumererade rapporttyper", availableTitle: "Andra tillgängliga rapporttyper", showLatestReport: "Visa senaste rapporten", showAllSubscribed: "VISA ALLA PRENUMERERADE RAPPORTER", subscribeNew: "+ PRENUMERERA NY RAPPORT", showPreview: "VISA FÖRHANDSGRANSKNING", subscribe: "PRENUMERERA RAPPORT" },
    subscription: {
        title: "Prenumerera ny rapport", oneTime: "Engångsbeställning", recurring: "Återkommande beställning", oneTimeTitle: "Engångsbeställning", recurringTitle: "Återkommande beställning",
        reportDateTitle: "Rapportens datum", dateLatest: "Senaste situationen,\ntillgänglig direkt", dateEndOfDay: "Slutet av dagens situation,\ntillgänglig imorgon", dateSelectCustom: "Välj rapportens datum", selectDateLabel: "Välj datum",
        dateInfoTitle: "Välj rapportens datum", dateInfoDesc: "Om datumet ligger i det förflutna blir rapporten klar efter en stund från beställningen. Om valt datum är i framtiden blir rapporten klar nästa arbetsdag. Om valt datum infaller på en helg levereras rapporten från föregående arbetsdags situation.\nSenaste situationen ....",
        frequencyTitle: "Beställningsfrekvens",
        daily: "En gång per dag", monthly: "En gång per månad", monthlyLast: "En gång per månad,\nsista dagen i månaden", quarterly: "En gång per kvartal", quarterlyLast: "En gång per kvartal,\nsista dagen i kvartalet", yearly: "En gång per år", selectDay: "Välj dag",
        frequencyInfoTitle: "Beställningsfrekvens",
        frequencyInfoMonthly: "Den valda rapporten levereras en gång per månad.\nPåverkan på pris: rapport genereras en gång per månad.",
        frequencyInfoMonthlyNote: "Tänk på hur datumvalet görs för månad, kvartal och år.\n\"En gång per månad dag X\" (om vald dag 29-31, gäller villkoret \"om månaden har färre dagar genereras rapporten sista dagen\")\n\"En gång per kvartal, dag X i månad X\" (i juni 30 dagar)\n\"En gång per år, välj dag\"",
        frequencyInfoQuarterly: "Den valda rapporten levereras en gång per kvartal.\nPåverkan på pris: rapport genereras en gång per kvartal.",
        frequencyInfoYearly: "Den valda rapporten levereras en gång per år.\nPåverkan på pris: rapport genereras en gång per år.",
        sharesTitle: "Värdeandelar och referens", shareType: "Värdeandelslag: Aktier", shareSelectionTitle: "Val av aktieserie (klass)", shareSelectionDesc: "Du kan välja en eller flera aktieserier för rapporten.\nPåverkan på pris: beskrivs i nästa vy.",
        referenceLabel: "Beställningsreferens", referencePlaceholder: "1234567890", referenceInfoTitle: "Beställningsreferens (valfritt)", referenceInfoDesc: "Du kan välja en referens för beställningen. Informationen visas på fakturan.",
        priceNote: "*Priset inkluderar grundavgift och leveransavgift. Priset består av...", priceNextView: "Rapportens pris visas i nästa vy", cancel: "AVBRYT", submit: "FORTSÄTT",
    },
    datePicker: {
        title: "Välj dag", cancel: "AVBRYT", done: "KLAR", selectTime: "Välj tid",
        months: ["Januari","Februari","Mars","April","Maj","Juni","Juli","Augusti","September","Oktober","November","December"],
        weekdays: ["Må","Ti","On","To","Fr","Lö","Sö"],
        quickPicks: { threeDaysAgo: "3 dagar sedan", twoDaysAgo: "2 dagar sedan", yesterday: "Igår", today: "Idag", tomorrow: "Imorgon", nextWeek: "Nästa vecka" },
    },
    profileMenu: { yourProfile: "Din profil", companyLabel: "Företag", departmentLabel: "Avdelning", dashboard: "Instrumentpanel", profile: "Profil", notAvailable: "Inte tillgänglig", logout: "Logga ut", selectLanguage: "Välj språk" },
    reportPreview: {
        breadcrumbRoot: "INFORMATION ELEMENTS", breadcrumbReports: "RAPPORTER", title: "Förhandsgranskning av rapport", orderableDataTitle: "Data som kan beställas", whatIsThisTitle: "Vad för slags data är detta?", whatIsThisDesc: "Rapporten är en lista...",
        reportTypesTitle: "Rapporttyper som ingår i beställningsbar data:", full: "Fullständig", agm: "Bolagsstämma", statutory: "Lagstadgad", short: "Kort", exampleTitle: "Exempel på data:", back: "< TILLBAKA", toSubscription: "TILL RAPPORTBESTÄLLNING →",
    },
    reportView: {
        downloadFile: "LADDA NER FIL", tabReport: "RAPPORT", tabSubscriptionInfo: "PRENUMERATIONSINFO",
        summaryTitle: "Rapportsammanfattning", reportTypeTitle: "Rapporttyp", fullDesc: "All tillgänglig data", agmDesc: "Aktieägarlista för bolagsstämma", statutoryDesc: "Lagstadgad data", shortDesc: "Ägarnamn och aktieantal",
        showDataTitle: "Visa data", filterTitle: "Filtrering", fileDownloadTitle: "Filnedladdning", fileDownloadDesc: "Du kan välja vilken version och format...",
        infoTitle: "Information", issuer: "Utgivare", reportName: "Rapportnamn", orderDate: "Beställningsdatum", situationDate: "Situationsdatum",
        shareNameLabel: "Aktienamn", isinLabel: "ISIN-kod", abbreviationLabel: "Förkortning",
        searchPlaceholder: "Sök ägare efter namn", filteredSummary: "Filtrerat: {owners} ägare, {shares} aktier",
        owners: "ägare", shares: "aktier", back: "TILLBAKA", toSubscription: "TILL RAPPORTBESTÄLLNING →", first: "Första", last: "Sista",
        colName: "NAMN", colIdentCode: "IDENTIFIERINGSKOD", colDob: "FÖDELSEDATUM", colCustomerRestrictions: "KUNDBEGRÄNSNINGAR",
        colStreetAddress: "GATUADRESS", colPostAddress: "POSTADRESS", colMunicipality: "KOMMUN", colMunicipalityCountry: "KOMMUN, LAND",
        colBookEntryType: "NAMN PÅ VÄRDEANDELSLAGET", colDepositoryParticipant: "DEPÅDELTAGARE",
        colNumberOfBookEntries: "ANTAL VÄRDEANDELAR", colPctBookEntries: "ANDEL AV VÄRDEANDELAR SAMMANLAGT",
        colNumberOfVotes: "ANTAL RÖSTER", colPctVotingRights: "ANDEL AV TOTALA RÖSTRÄTTEN",
        colSituationDate: "SITUATIONSDATUM", colSector: "SEKTOR", colPaymentInfo: "BETALNINGSINFORMATION", colTaxInfo: "SKATTEINFORMATION",
        summColBookEntry: "VÄRDEANDELSLAG", summColOwners: "ANTAL ÄGARE OCH FÖRVALTNINGSREGISTRERINGENS FÖRVARINGSINSTITUTET",
        summColJointOwners: "ANTAL SAMÄGARE", summColVotesConferred: "ANTAL RÖSTER FRÅN ALLA BOKFÖRINGSPOSTER I VÄRDEANDELSKONTON",
        summColPctVotes: "ANDEL RÖSTER FRÅN ALLA BOKFÖRINGSPOSTER", summColTotalVotes: "TOTALT ANTAL RÖSTER",
        summColInShareholderList: "I AKTIEÄGARFÖRTECKNINGEN", summColInWaitingList: "I VÄNTELISTAN",
        summColNomineeReg: "FÖRVALTNINGSREGISTRERAT", summColJointAccount: "PÅ SAMKONTOT", summColIssuedAmount: "EMITTERAT BELOPP",
        chipDirectly: "Direkt registrerade innehav", chipNominee: "Förvaltningsregistrerade innehav", chipCompanies: "Företag",
        chipFinancial: "Finans- och försäkringsinstitut", chipHouseholds: "Hushåll",
        legendNonDisclosure: "Sekretess", legendJointOwnership: "Samägande",
        legendNomineeHolding: "Förvaltningsregistrerat innehav", legendNomineeCustodians: "Förvaltningsregistreringens förvaringsinstitut",
        showOptAddress: "Adressuppgifter som omfattas av sekretess", showOptIsin: "Identifieringskod",
        showOptExpired: "Avslutade bokföringsposttyper", showOptSector: "Sektorinformation", showOptCustodian: "Depådeltagare",
        sidebarFull: "Fullständig: Inkluderar fullständigt innehåll i rapporten med ytterligare detaljer.\nBolagsstämma: Aktieägarregistret tillgängligt vid bolagsstämman.\nEmittentens aktieägarförteckning: Inkluderar information som krävs enligt finsk aktiebolagslag.\nKort: Rapporten inkluderar ägarnas namn och antal aktier.",
        sidebarAgm: "Bolagsstämma: Aktieägarregistret tillgängligt vid bolagsstämman. Inkluderar endast information som krävs enligt finsk aktiebolagslag.",
        sidebarStatutory: "Emittentens aktieägarförteckning: Inkluderar information som krävs enligt finsk aktiebolagslag.",
        sidebarShort: "Kort: Rapporten inkluderar namnen på aktieägare eller förvaltningsregistreringens förvaringsinstitut och antal bokföringsposter per bokföringsposttyp.",
        customerRestriction: "Kundbegränsning", totalSharesLabel: "Värdeandelar sammanlagt",
        summaryTotal: "Totalt", jointSubLabel: "Inkluderad i samägande",
        jointParentLabel: "Rättighetshavare", flagNomineeReg: "Förvaltningsregistreringens förvaringsinstitut",
        flagNonDisclosure: "Sekretess", flagNominee: "Förvaltningsregistrerat",
        fileDownloadSidebarDesc: "I fönstret för filnedladdning kan du välja vilken rapporttyp du vill ladda ner och i vilket filformat. Du kan också välja om du vill ladda ner filen med de val och filter som gjorts i den här vyn, eller i dess ursprungliga format.",
        reportTypeStatutoryTitle: "Emittentens aktieägarförteckning", reportTypeStatutoryDesc: "Lagstadgad information",
        reportTypeFullTitle: "Fullständig", reportTypeFullDesc: "All tillgänglig information",
        reportTypeAgmTitle: "Bolagsstämma", reportTypeAgmDesc: "Aktieägarregister för bolagsstämman",
        reportTypeShortTitle: "Kort", reportTypeShortDesc: "Ägarnas namn och antal aktier",
    },
    subscribedReports: {
        title: "Prenumererade rapporter", availabilityNote: "Färdiga rapporter är tillgängliga i tjänsten i 60 dagar.",
        colDate: "RAPPORTDATUM", colOrdered: "BESTÄLLD", colFrequency: "BESTÄLLNINGSFREKVENS", colReference: "BESTÄLLNINGSREFERENS", colStatus: "BESTÄLLNINGSSTATUS",
        statusReady: "Klar", statusProcessing: "Bearbetar", oneTime: "Engångsbeställning", monthly: "En gång per månad",
    },
    downloadModal: {
        title: "Ladda ner som fil", reportTypeTitle: "Rapporttyp", filterTitle: "Filtrering", filterUserVersion: "Ladda ner användarfiltrerad version",
        fileTypeTitle: "Filtyp", languageTitle: "Språk", cancel: "AVBRYT", download: "LADDA NER",
    },
    common: { loading: "Laddar...", error: "Ett fel inträffade", retry: "Försök igen", noData: "Ingen data tillgänglig", save: "Spara", close: "Stäng", back: "Tillbaka", next: "Nästa", confirm: "Bekräfta", delete: "Radera", edit: "Redigera", search: "Sök" },
};

const fi: Translations = {
    welcome: "Tervetuloa aloitussivulle",
    tabs: { reports: "Raportit", log: "Tapahtumaloki", organization: "Organisaation tiedot" },
    content: { reports: "Raporttien sisältö tulee tähän", log: "Tapahtumalokin sisältö tulee tähän", organization: "Organisaation tiedot tulee tähän" },
    header: { appName: "Information Elements by Euroclear", orgLabel: "Organisaatio: Euroflex", skipToContent: "Siirry pääsisältöön", openMenu: "Avaa valikko", closeMenu: "Sulje valikko" },
    reports: { subscribedTitle: "Tilatut raportityypit", availableTitle: "Muut saatavilla olevat raportityypit", showLatestReport: "Näytä viimeisin raportti", showAllSubscribed: "NÄYTÄ KAIKKI TILATUT RAPORTIT", subscribeNew: "+ TILAA UUSI RAPORTTI", showPreview: "NÄYTÄ ESIKATSELU", subscribe: "TILAA RAPORTTI" },
    subscription: {
        title: "Tilaa uusi raportti", oneTime: "Tee kertatilaus", recurring: "Tee toistuva tilaus", oneTimeTitle: "Kertatilaus", recurringTitle: "Toistuva tilaus",
        reportDateTitle: "Raportin päivämäärä", dateLatest: "Viimeisin tilanne,\nheti saatavilla", dateEndOfDay: "Tilanne päivän lopulla,\nsaatavilla huomenna", dateSelectCustom: "Valitse raportin päivämäärä", selectDateLabel: "Valitse päivämäärä",
        dateInfoTitle: "Valitse raportin päivämäärä", dateInfoDesc: "Jos päivämäärä on menneisyydessä, raportti valmistuu hetken kuluttua tilauksesta. Jos valittu päivä on tulevaisuudessa, raportti valmistuu tilauksesta seuraavana arkipäivänä. Jos valittu päivämäärä osuu viikonlopulle, raportti toimitetaan edeltävän arkipäivän tilanteesta.\nViimeisin tilanne ....",
        frequencyTitle: "Tilauksen toistuvuus",
        daily: "Kerran päivässä", monthly: "Kerran kuukaudessa", monthlyLast: "Kerran kuukaudessa,\nkuukauden viimeinen päivä", quarterly: "Kerran kvartaalissa", quarterlyLast: "Kerran kvartaalissa,\nkvartaalin viimeinen päivä", yearly: "Kerran vuodessa", selectDay: "Valitse päivä",
        frequencyInfoTitle: "Tilauksen toistuvuus",
        frequencyInfoMonthly: "Kerran kuussa toimitettavaksi valittu raportti toimitetaan...\nVaikutus hintaan: kerran kuussa muodostuva raportti ...",
        frequencyInfoMonthlyNote: "Mietittävä, kuinka pvm valinta tehdään kuukauden, kvartaalin ja vuoden yhteydessä.\n\"Kerran kuukaudessa kuukauden x:nä päivänä\" (jos valittu päivä 29-31, tarvitaan ehto \"jos kuussa vähemmän päiviä, muodostuu raportti viimeisenä päivänä\")\n\"Kerran kvartaalissa, kvartaalin x. kuun x:nä päivänä\" (kesäkuussa 30 päivää)\n\"Kerran vuodessa, valitse päivä\"",
        frequencyInfoQuarterly: "Kerran kvartaalissa toimitettavaksi valittu raportti toimitetaan...\nVaikutus hintaan: kerran kvartaalissa muodostuva raportti ...",
        frequencyInfoYearly: "Kerran vuodessa toimitettavaksi valittu raportti toimitetaan...\nVaikutus hintaan: kerran vuodessa muodostuva raportti ...",
        sharesTitle: "Arvo-osuudet ja viite", shareType: "Arvo-osuuslaji: Osakkeet", shareSelectionTitle: "Osakesarjan (lajin) valinta", shareSelectionDesc: "Raportille voi valita yhden tai useamman osakesarjan.\nVaikutus hintaan: kuvataan seuraavassa näkymässä.",
        referenceLabel: "Tilauksen viite", referencePlaceholder: "1234567890", referenceInfoTitle: "Tilauksen viite (valinnainen)", referenceInfoDesc: "Tilauksen viitteeksi voitte valita haluamanne viitteen. Tieto tulee laskulle.",
        priceNote: "*Hinta sisältää perusmaksun ja toimitusmaksun. Hinta koostuu...", priceNextView: "Raportin hinta esitetään seuraavassa näkymässä", cancel: "PERUUTA", submit: "JATKA",
    },
    datePicker: {
        title: "Valitse päivä", cancel: "PERUUTA", done: "VALMIS", selectTime: "Valitse aika",
        months: ["Tammikuu","Helmikuu","Maaliskuu","Huhtikuu","Toukokuu","Kesäkuu","Heinäkuu","Elokuu","Syyskuu","Lokakuu","Marraskuu","Joulukuu"],
        weekdays: ["Ma","Ti","Ke","To","Pe","La","Su"],
        quickPicks: { threeDaysAgo: "3 päivää sitten", twoDaysAgo: "2 päivää sitten", yesterday: "Eilen", today: "Tänään", tomorrow: "Huomenna", nextWeek: "Ensi viikko" },
    },
    profileMenu: { yourProfile: "Profiilisi", companyLabel: "Yritys", departmentLabel: "Osasto", dashboard: "Kojelauta", profile: "Profiili", notAvailable: "Ei saatavilla", logout: "Kirjaudu ulos", selectLanguage: "Valitse kieli" },
    reportPreview: {
        breadcrumbRoot: "INFORMATION ELEMENTS", breadcrumbReports: "RAPORTIT", title: "Raportin esikatselu", orderableDataTitle: "Tilattava aineisto", whatIsThisTitle: "Millaisesta aineistosta on kyse?", whatIsThisDesc: "Raportti on luettelo liikkeeseenlaskijan puolesta ABESO:n mukaisesti Euroclear Finlandin ylläpitämään arvo-osuusjärjestelmään liitetystä tai siihen sisältyvistä osakkeiden omistajista (mukaan lukien hallintarekisteröinnin hoitajat), eikä se ole julkista tietoa osakeyhtiölain mukaisesti. Tämä raportti ei sisällä odotuslistalla olevia omistajia eikä yhteisellä arvo-osuustilillä olevia omistajia.",
        reportTypesTitle: "Tilattavaan aineistoon sisältyvät raportityypit:", full: "Täysi", agm: "Yhtiökokous", statutory: "Lakisääteinen", short: "Lyhyt", exampleTitle: "Esimerkki aineistosta:", back: "< TAKAISIN", toSubscription: "RAPORTIN TILAUKSEEN →",
    },
    reportView: {
        downloadFile: "LATAA TIEDOSTONA", tabReport: "RAPORTTI", tabSubscriptionInfo: "TILAUKSEN TIEDOT",
        summaryTitle: "Raportin yhteenveto", reportTypeTitle: "Raportin tyyppi", fullDesc: "Kaikki saatavilla olevat tiedot", agmDesc: "Osakasluettelo yhtiökokoukseen", statutoryDesc: "Lakisääteiset tiedot", shortDesc: "Omistajien nimet ja osakkeiden lukumäärä",
        showDataTitle: "Näytä tiedot", filterTitle: "Suodatus", fileDownloadTitle: "Tiedoston lataus", fileDownloadDesc: "Tiedoston lataus ikkunassa voit vaikuttaa siihen, minkä raportin version haluat ladata ja missä tiedostomuodoissa. Voit myös valita haluatko ladata tiedoston tässä näkymässä tekemilläsi valinnoilla ja suodatuksilla vai raportin alkuperäisessä muodossa ...",
        infoTitle: "Tiedot", issuer: "Liikkeeseenlaskija", reportName: "Raportin nimi", orderDate: "Tilauspäivä", situationDate: "Tilannepäivä",
        shareNameLabel: "Arvo-osuuden nimi", isinLabel: "ISIN-koodi", abbreviationLabel: "Arvo-osuuden lyhenne",
        searchPlaceholder: "Hae omistajaa listasta nimellä", filteredSummary: "Suodatuksella: omistajia {owners} kpl, osakkeita {shares} kpl",
        owners: "kpl", shares: "kpl", back: "TAKAISIN", toSubscription: "RAPORTIN TILAUKSEEN →", first: "Ensimmäinen", last: "Viimeinen",
        colName: "NIMI", colIdentCode: "TUNNISTETIEDOT", colDob: "SYNTYMÄAIKA", colCustomerRestrictions: "ASIAKASRAJOITUKSET",
        colStreetAddress: "KATUOSOITE", colPostAddress: "POSTIOSOITE", colMunicipality: "KOTIKUNTA", colMunicipalityCountry: "KOTIKUNTA, MAA",
        colBookEntryType: "ARVO-OSUUSLAJIN NIMI", colDepositoryParticipant: "SÄILYTTÄJÄ",
        colNumberOfBookEntries: "ARVO-OSUUKSIEN MÄÄRÄ", colPctBookEntries: "ARVO-OSUUKSIEN YHTEISMÄÄRÄ %",
        colNumberOfVotes: "ÄÄNIMÄÄRÄ", colPctVotingRights: "KOKONAISÄÄNIMÄÄRÄ %",
        colSituationDate: "TILANNEPÄIVÄ", colSector: "TOIMIALA", colPaymentInfo: "MAKSUTIEDOT", colTaxInfo: "VEROTIEDOT",
        summColBookEntry: "AO-LAJI", summColOwners: "OMISTAJIEN JA HALLINTAREKISTERÖINNIN HOITAJIEN MÄÄRÄ",
        summColJointOwners: "YHTEISOMISTAJIEN MÄÄRÄ", summColVotesConferred: "KAIKKIEN AO-TILIKIRJAUSTEN ÄÄNIOIKEUDET",
        summColPctVotes: "OSUUS KAIKKIEN AO-TILIKIRJAUSTEN ÄÄNISTÄ", summColTotalVotes: "KOKONAISÄÄNIMÄÄRÄ",
        summColInShareholderList: "OSAKASLUETTELOSSA", summColInWaitingList: "ODOTUSLISTALLA",
        summColNomineeReg: "HALLINTAREKISTERÖITY", summColJointAccount: "YHTEISTILILLÄ", summColIssuedAmount: "LIIKKEESEENLASKETTU MÄÄRÄ",
        chipDirectly: "Suoraan rekisteröidyt omistukset", chipNominee: "Hallintarekisteröidyt omistukset", chipCompanies: "Yritykset",
        chipFinancial: "Rahoitus- ja vakuutuslaitokset", chipHouseholds: "Kotitaloudet",
        legendNonDisclosure: "Salassapito", legendJointOwnership: "Yhteisomistus",
        legendNomineeHolding: "Hallintarekisteröity omistus", legendNomineeCustodians: "Hallintarekisteröinnin säilyttäjät",
        showOptAddress: "Salassapidon piirissä olevat osoitetiedot", showOptIsin: "Tunnistetiedot",
        showOptExpired: "Lakkautetut arvo-osuuslajit", showOptSector: "Sektoritiedot", showOptCustodian: "Säilyttäjä",
        sidebarFull: "Täysi: Sisältää raportin täydellisen sisällön lisätietoineen.\nYhtiökokous: Yhtiökokouksessa saatavilla oleva osakasrekisteri.\nLiikkeeseenlaskijan osakasluettelo: Sisältää osakeyhtiölain mukaiset tiedot.\nLyhyt: Raportti sisältää osakkaiden nimet ja osakkeiden lukumäärän.",
        sidebarAgm: "Yhtiökokous: Yhtiökokouksessa saatavilla oleva osakasrekisteri. Sisältää vain osakeyhtiölain mukaiset tiedot.",
        sidebarStatutory: "Liikkeeseenlaskijan osakasluettelo: Sisältää osakeyhtiölain mukaiset tiedot.",
        sidebarShort: "Lyhyt: Raportti sisältää osakkaiden tai hallintarekisteröinnin hoitajien nimet ja arvo-osuuksien määrän arvo-osuuslajeittain.",
        customerRestriction: "Asiakasrajoitus", totalSharesLabel: "Arvo-osuudet yhteensä",
        summaryTotal: "Yhteensä", jointSubLabel: "Mukana yhteisomistuksessa",
        jointParentLabel: "Oikeudenhaltija", flagNomineeReg: "Hallintarekisteröinnin hoitaja",
        flagNonDisclosure: "Salassapito", flagNominee: "Hallintarekisteröity",
        fileDownloadSidebarDesc: "Tiedoston lataus ikkunassa voit vaikuttaa siihen, minkä raportin version haluat ladata ja missä tiedostomuodoissa. Voit myös valita haluatko ladata tiedoston tässä näkymässä tekemilläsi valinnoilla ja suodatuksilla vai raportin alkuperäisessä muodossa.",
        reportTypeStatutoryTitle: "Liikkeeseenlaskijan osakasluettelo", reportTypeStatutoryDesc: "Lakisääteiset tiedot",
        reportTypeFullTitle: "Täysi", reportTypeFullDesc: "Kaikki saatavilla olevat tiedot",
        reportTypeAgmTitle: "Yhtiökokous", reportTypeAgmDesc: "Osakasrekisteri yhtiökokoukseen",
        reportTypeShortTitle: "Lyhyt", reportTypeShortDesc: "Omistajien nimet ja osakkeiden lukumäärä",
    },
    subscribedReports: {
        title: "Tilatut raportit", availabilityNote: "Valmistuneet raportit ovat saatavilla palvelussa 60 päivän ajan.",
        colDate: "RAPORTIN PÄIVÄMÄÄRÄ", colOrdered: "TILATTU", colFrequency: "TILAUKSEN TOISTUVUUS", colReference: "TILAUKSEN VIITE", colStatus: "TILAUKSEN TILA",
        statusReady: "Valmis", statusProcessing: "Valmistumassa", oneTime: "Kertatilaus", monthly: "Kerran kuussa",
    },
    downloadModal: {
        title: "Lataa tiedostona", reportTypeTitle: "Raportin tyyppi", filterTitle: "Suodatus", filterUserVersion: "Lataa käyttäjän suodattama versio",
        fileTypeTitle: "Tiedostotyyppi", languageTitle: "Kieli", cancel: "PERUUTA", download: "LATAA",
    },
    common: { loading: "Ladataan...", error: "Tapahtui virhe", retry: "Yritä uudelleen", noData: "Ei tietoja saatavilla", save: "Tallenna", close: "Sulje", back: "Takaisin", next: "Seuraava", confirm: "Vahvista", delete: "Poista", edit: "Muokkaa", search: "Haku" },
};

export const translations: Record<Language, Translations> = { en, sv, fi };
