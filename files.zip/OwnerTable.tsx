// ─── OwnerTable ───────────────────────────────────────────────────────────────
// Renders the owner table with ONLY the columns relevant for the current report type.
// No ghost/placeholder columns — unused columns are simply not rendered.
// First column always has sortDirection (library mandate → teal highlight).

import { Table } from '@efi/efi-ui-components';
import type { OwnerRow, ColVisibility, SortDir } from './types';
import type { Translations } from '@/locales';
import { OwnerTableRow } from './OwnerTableRow';

type T = Translations['reportView'];

interface Props {
    rows:     OwnerRow[];
    cols:     ColVisibility;
    t:        T;
    sortDir:  SortDir;
    onSort:   (dir: SortDir) => void;
}

export function OwnerTable({ rows, cols, t, sortDir, onSort }: Props) {
    return (
        <div className="rv__table-wrap">
            <Table layout="fixed" hover>
                <Table.Head>
                    <Table.Row>
                        {/* ── Col 1: Name — always, sortable, sortDirection gives teal colour ── */}
                        <Table.HeadCell
                            column="name"
                            sortable
                            sortDirection={sortDir}
                            className="rv__th"
                            style={{ width: '14%' }}
                            onSort={(dir: SortDir) => onSort(dir)}
                        >
                            {t.colName}
                            <Table.SecondaryText>{t.colIdentCode}</Table.SecondaryText>
                            <Table.SecondaryText>{t.colDob}</Table.SecondaryText>
                            <Table.SecondaryText>{t.colCustomerRestrictions}</Table.SecondaryText>
                        </Table.HeadCell>

                        {/* ── Col 2: Street address (statutory, full) ── */}
                        {cols.addr && (
                            <Table.HeadCell column="addr" className="rv__th" style={{ width: '12%' }}>
                                {t.colStreetAddress}
                                <Table.SecondaryText>{t.colPostAddress}</Table.SecondaryText>
                                <Table.SecondaryText>{t.colMunicipalityCountry}</Table.SecondaryText>
                            </Table.HeadCell>
                        )}

                        {/* ── Col 3: Municipality only (AGM) ── */}
                        {cols.city && (
                            <Table.HeadCell column="city" className="rv__th" style={{ width: '9%' }}>
                                {t.colMunicipality}
                            </Table.HeadCell>
                        )}

                        {/* ── Col 4: Book-entry type — always ── */}
                        <Table.HeadCell column="type" className="rv__th" style={{ width: '13%' }}>
                            {t.colBookEntryType}
                        </Table.HeadCell>

                        {/* ── Col 5: Custodian (statutory, full, short) ── */}
                        {cols.custodian && (
                            <Table.HeadCell column="cust" className="rv__th" style={{ width: '9%' }}>
                                {t.colDepositoryParticipant}
                            </Table.HeadCell>
                        )}

                        {/* ── Col 6: Number of book-entries — always ── */}
                        <Table.HeadCell column="amt" align="right" className="rv__th" style={{ width: '8%' }}>
                            {t.colNumberOfBookEntries}
                        </Table.HeadCell>

                        {/* ── Col 7: % combined (full, short) ── */}
                        {cols.pct && (
                            <Table.HeadCell column="pct" align="right" className="rv__th" style={{ width: '9%' }}>
                                {t.colPctBookEntries}
                            </Table.HeadCell>
                        )}

                        {/* ── Col 8: Votes (full only) ── */}
                        {cols.votes && (
                            <Table.HeadCell column="votes" align="right" className="rv__th" style={{ width: '8%' }}>
                                {t.colNumberOfVotes}
                            </Table.HeadCell>
                        )}

                        {/* ── Col 9: Vote % (full only) ── */}
                        {cols.votePct && (
                            <Table.HeadCell column="vpct" align="right" className="rv__th" style={{ width: '9%' }}>
                                {t.colPctVotingRights}
                            </Table.HeadCell>
                        )}

                        {/* ── Col 10: Situation date (statutory) ── */}
                        {cols.date && (
                            <Table.HeadCell column="date" className="rv__th" style={{ width: '7%' }}>
                                {t.colSituationDate}
                            </Table.HeadCell>
                        )}

                        {/* ── Col 11: Sector (full only) ── */}
                        {cols.sector && (
                            <Table.HeadCell column="sec" className="rv__th" style={{ width: '9%' }}>
                                {t.colSector}
                            </Table.HeadCell>
                        )}

                        {/* ── Col 12: Payment info (statutory, full) ── */}
                        {cols.payment && (
                            <Table.HeadCell column="pay" className="rv__th" style={{ width: '8%' }}>
                                {t.colPaymentInfo}
                            </Table.HeadCell>
                        )}

                        {/* ── Col 13: Tax info (statutory, full) ── */}
                        {cols.tax && (
                            <Table.HeadCell column="tax" className="rv__th" style={{ width: '7%' }}>
                                {t.colTaxInfo}
                            </Table.HeadCell>
                        )}
                    </Table.Row>
                </Table.Head>

                <Table.Body>
                    {rows.map(row => (
                        <OwnerTableRow key={row.id} row={row} cols={cols} t={t} />
                    ))}
                </Table.Body>
            </Table>
        </div>
    );
}
