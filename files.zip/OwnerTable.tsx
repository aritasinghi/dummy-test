import { Table } from '@efi/efi-ui-components';
import type { OwnerRow, ColVisibility, SortDir } from './types';
import type { Translations } from '@/locales';
import { OwnerTableRow } from './OwnerTableRow';

type T = Translations['reportView'];

interface Props {
    rows:    OwnerRow[];
    cols:    ColVisibility;
    t:       T;
    sortDir: SortDir;
    onSort:  (dir: SortDir) => void;
}

// ── Column header background rules ────────────────────────────────────────────
// Teal  (#E5F8F6):  Name column | Number of book-entries | Number of votes
// Dark  (#6D828A):  All other header columns — white text for readability
// Sort indicator:   teal bg + teal bottom border + teal text on Name col

const TEAL: React.CSSProperties  = { backgroundColor: '#E5F8F6', color: '#232E32' };
const DARK: React.CSSProperties  = { backgroundColor: '#6D828A', color: '#ffffff' };
const SORT: React.CSSProperties  = {
    backgroundColor: '#E5F8F6',
    color: '#00B9A4',
    borderBottom: '2px solid #00B9A4',
};

export function OwnerTable({ rows, cols, t, sortDir, onSort }: Props) {
    return (
        <div className="rv__table-wrap">
            <Table layout="auto" hover>
                <Table.Head>
                    <Table.Row>

                        {/* ── TEAL: Col 1 — Name (sortable) ── */}
                        <Table.HeadCell
                            column="name" sortable sortDirection={sortDir}
                            style={SORT}
                            onSort={(dir: SortDir) => onSort(dir)}
                        >
                            {t.colName}
                            <Table.SecondaryText>{t.colIdentCode}</Table.SecondaryText>
                            <Table.SecondaryText>{t.colDob}</Table.SecondaryText>
                            <Table.SecondaryText>{t.colCustomerRestrictions}</Table.SecondaryText>
                        </Table.HeadCell>

                        {/* ── DARK: Col 2a — Street address ── */}
                        {cols.addr && (
                            <Table.HeadCell column="addr" style={DARK}>
                                {t.colStreetAddress}
                                <Table.SecondaryText>{t.colPostAddress}</Table.SecondaryText>
                                <Table.SecondaryText>{t.colMunicipalityCountry}</Table.SecondaryText>
                            </Table.HeadCell>
                        )}

                        {/* ── DARK: Col 2b — Municipality (AGM) ── */}
                        {cols.city && (
                            <Table.HeadCell column="city" style={DARK}>
                                {t.colMunicipality}
                            </Table.HeadCell>
                        )}

                        {/* ── DARK: Col 3 — Book-entry type ── */}
                        <Table.HeadCell column="type" style={DARK}>
                            {t.colBookEntryType}
                        </Table.HeadCell>

                        {/* ── DARK: Depository participant ── */}
                        {cols.custodian && (
                            <Table.HeadCell column="cust" style={DARK}>
                                {t.colDepositoryParticipant}
                            </Table.HeadCell>
                        )}

                        {/* ── TEAL: Number of book-entries ── */}
                        <Table.HeadCell column="amt" style={TEAL}>
                            {t.colNumberOfBookEntries}
                        </Table.HeadCell>

                        {/* ── DARK: % combined ── */}
                        {cols.pct && (
                            <Table.HeadCell column="pct" style={DARK}>
                                {t.colPctBookEntries}
                            </Table.HeadCell>
                        )}

                        {/* ── TEAL: Number of votes ── */}
                        {cols.votes && (
                            <Table.HeadCell column="votes" style={TEAL}>
                                {t.colNumberOfVotes}
                            </Table.HeadCell>
                        )}

                        {/* ── DARK: % voting rights ── */}
                        {cols.votePct && (
                            <Table.HeadCell column="vpct" style={DARK}>
                                {t.colPctVotingRights}
                            </Table.HeadCell>
                        )}

                        {/* ── DARK: Situation date ── */}
                        {cols.date && (
                            <Table.HeadCell column="date" style={DARK}>
                                {t.colSituationDate}
                            </Table.HeadCell>
                        )}

                        {/* ── DARK: Sector ── */}
                        {cols.sector && (
                            <Table.HeadCell column="sec" style={DARK}>
                                {t.colSector}
                            </Table.HeadCell>
                        )}

                        {/* ── DARK: Payment info ── */}
                        {cols.payment && (
                            <Table.HeadCell column="pay" style={DARK}>
                                {t.colPaymentInfo}
                            </Table.HeadCell>
                        )}

                        {/* ── DARK: Tax info ── */}
                        {cols.tax && (
                            <Table.HeadCell column="tax" style={DARK}>
                                {t.colTaxInfo}
                            </Table.HeadCell>
                        )}

                    </Table.Row>
                </Table.Head>

                <Table.Body>
                    {(Array.isArray(rows) ? rows : []).map(row => (
                        <OwnerTableRow key={row.id} row={row} cols={cols} t={t} />
                    ))}
                </Table.Body>
            </Table>
        </div>
    );
}
