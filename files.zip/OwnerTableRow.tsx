// ─── OwnerTableRow ────────────────────────────────────────────────────────────
// Renders a single owner row. Only columns that are active for the current
// report type are rendered — no ghost/placeholder cells.

import { Table, TextLink } from '@efi/efi-ui-components';
import type { OwnerRow, ColVisibility } from './types';
import type { Translations } from '@/locales';

type T = Translations['reportView'];

interface Props {
    row:  OwnerRow;
    cols: ColVisibility;
    t:    T;
}

export function OwnerTableRow({ row, cols, t }: Props) {
    if (row.isJointSubRow) {
        return (
            <Table.Row className="rv__row--joint-sub">
                {/* Name — always col 1 */}
                <Table.BodyCell>
                    <div className="rv__name-cell">
                        <div className="rv__name-row">
                            <span className="rv__flag">🔗</span>
                            <span className="rv__sub-label">{t.jointSubLabel}</span>
                        </div>
                        <div className="rv__joint-parent">
                            {t.jointParentLabel}: <TextLink href="#">{row.jointParent}</TextLink>
                        </div>
                        <span className="rv__ssn-text">{row.ssn}</span>
                        {row.dob && <span className="rv__ssn-text">{row.dob}</span>}
                    </div>
                </Table.BodyCell>
                {cols.addr  && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.city  && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {/* Book-entry type — always */}
                <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>
                {cols.custodian && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {/* Amount — always */}
                <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>
                {cols.pct    && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.votes  && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.votePct && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.date   && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.sector && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.payment && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
                {cols.tax    && <Table.BodyCell><span className="rv__cell-muted">—</span></Table.BodyCell>}
            </Table.Row>
        );
    }

    return (
        <Table.Row>
            {/* ── Col 1: Name / SSN / DOB / Restriction — always ── */}
            <Table.BodyCell>
                <div className="rv__name-cell">
                    <div className="rv__name-row">
                        {row.isBank    && <span className="rv__flag" title={t.flagNomineeReg}>🏦</span>}
                        {row.isCompany && !row.isBank && <span className="rv__flag" title={t.flagNomineeReg}>🏢</span>}
                        <TextLink href="#"><strong>{row.name}</strong></TextLink>
                        {row.isRestricted && <span className="rv__flag" title={t.flagNonDisclosure}>🚫</span>}
                        {row.isNominee && !row.isBank && <span className="rv__flag" title={t.flagNominee}>📋</span>}
                    </div>
                    <span className="rv__ssn-text">{row.ssn}</span>
                    {row.dob && <span className="rv__ssn-text">{row.dob}</span>}
                    {row.asiakasrajoitus && (
                        <span className="rv__restriction">{t.customerRestriction}: {row.asiakasrajoitus}</span>
                    )}
                    {row.isJoint && row.jointOwners && (
                        <div className="rv__joint-section">
                            <span className="rv__flag">🔗</span>
                            <span className="rv__joint-label">Yhteisomistus:</span>
                            {row.jointOwners.map((o, i) => (
                                <span key={i} className="rv__cell-sm">
                                    {o.linkable ? <TextLink href="#">{o.name}</TextLink> : o.name}
                                    {i < (row.jointOwners?.length ?? 0) - 1 && ', '}
                                </span>
                            ))}
                        </div>
                    )}
                </div>
            </Table.BodyCell>

            {/* ── Col 2: Street address (statutory, full) ── */}
            {cols.addr && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">
                        {row.address}<br />{row.postAddress}<br />{row.country}
                    </span>
                </Table.BodyCell>
            )}

            {/* ── Col 3: Municipality only (AGM) ── */}
            {cols.city && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.city}</span>
                </Table.BodyCell>
            )}

            {/* ── Col 4: Book-entry type — always ── */}
            <Table.BodyCell>
                <div className="rv__shares-vertical">
                    {row.shares.map((s, i) => (
                        <div key={i} className={s.isTotal ? 'rv__cell-total' : 'rv__cell-sm'}>
                            {s.isTotal ? t.totalSharesLabel : s.type}
                        </div>
                    ))}
                </div>
            </Table.BodyCell>

            {/* ── Col 5: Custodian (statutory, full, short) ── */}
            {cols.custodian && (
                <Table.BodyCell>
                    <div className="rv__shares-vertical">
                        {row.shares.map((s, i) => (
                            <div key={i} className="rv__cell-sm">
                                {s.isTotal ? '' : (s.custodian || '')}
                            </div>
                        ))}
                    </div>
                </Table.BodyCell>
            )}

            {/* ── Col 6: Number of book-entries — always ── */}
            <Table.BodyCell align="middle-right">
                <div className="rv__shares-vertical">
                    {row.shares.map((s, i) => (
                        <div key={i} className={s.isTotal ? 'rv__cell-total' : 'rv__cell-sm'}>
                            {s.amount}
                        </div>
                    ))}
                </div>
            </Table.BodyCell>

            {/* ── Col 7: % combined (full, short) ── */}
            {cols.pct && (
                <Table.BodyCell align="middle-right">
                    <div className="rv__shares-vertical">
                        {row.shares.map((s, i) => (
                            <div key={i} className="rv__cell-sm">{s.pct}</div>
                        ))}
                    </div>
                </Table.BodyCell>
            )}

            {/* ── Col 8: Votes (full only) ── */}
            {cols.votes && (
                <Table.BodyCell align="middle-right">
                    <div className="rv__shares-vertical">
                        {row.shares.map((s, i) => (
                            <div key={i} className={s.isTotal ? 'rv__cell-total' : 'rv__cell-sm'}>
                                {s.votes || ''}
                            </div>
                        ))}
                    </div>
                </Table.BodyCell>
            )}

            {/* ── Col 9: Vote % (full only) ── */}
            {cols.votePct && (
                <Table.BodyCell align="middle-right">
                    <div className="rv__shares-vertical">
                        {row.shares.map((s, i) => (
                            <div key={i} className="rv__cell-sm">{s.votePct || ''}</div>
                        ))}
                    </div>
                </Table.BodyCell>
            )}

            {/* ── Col 10: Situation date (statutory only) ── */}
            {cols.date && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.situationDate}</span>
                </Table.BodyCell>
            )}

            {/* ── Col 11: Sector (full only) ── */}
            {cols.sector && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.sektori}</span>
                </Table.BodyCell>
            )}

            {/* ── Col 12: Payment info (statutory, full) ── */}
            {cols.payment && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.maksu}</span>
                </Table.BodyCell>
            )}

            {/* ── Col 13: Tax info (statutory, full) ── */}
            {cols.tax && (
                <Table.BodyCell>
                    <span className="rv__cell-sm">{row.vero}</span>
                </Table.BodyCell>
            )}
        </Table.Row>
    );
}
