import { useState } from 'react';
import {
    Banner, Chip, Table, Pagination, ButtonIcon, InfoIcon, Container, Loader,
} from '@efi/efi-ui-components';
import type { Language } from '@/locales';
import { translations } from '@/locales';
import type { FilterKey } from '@/api/reportApiTypes';
import type { ReportType } from './types';
import { COLS, SHOW_FILTERS_FOR } from './types';
import { SHOW_DATA_KEYS } from './reportData';
import { useReportData } from './useReportData';
import { OwnerTable } from './OwnerTable';
import { DownloadModal } from '@/components/DownloadModal';
import './ReportView.css';

interface ReportViewProps {
    reportId:    string;
    reportTitle: string;
    reportDate:  string;
    language:    Language;
    onBack:      () => void;
    onSubscribe: () => void;
    onDownload?: () => void;
}

export default function ReportView({
    reportId, reportTitle, reportDate, language, onDownload,
}: ReportViewProps) {
    const t = translations[language].reportView;

    // ── Backend state ──────────────────────────────────────────────────────────
    const {
        metadata, summaryRows, securities, filterCounts,
        metaLoading,
        owners, totalCount, totalPages, currentPage,
        ownersLoading,
        setPage, setSearch, setFilters,
        search, activeFilters,
    } = useReportData(Number(reportId));

    // ── Frontend-only state (no API) ───────────────────────────────────────────
    const [activeTab,  setActiveTab]  = useState<'report' | 'subscription'>('report');
    const [reportType, setReportType] = useState<ReportType>('statutory');
    const [showData,   setShowData]   = useState<Record<string, boolean>>(
        Object.fromEntries(SHOW_DATA_KEYS.map(k => [k, true]))
    );
    const [downloadOpen, setDownloadOpen] = useState(false);

    const cols        = COLS[reportType];
    const showFilters = SHOW_FILTERS_FOR[reportType];

    // Apply showData checkbox overrides to column visibility
    // showData.custodian → depository participant column
    // showData.sector    → sector column
    const effectiveCols = {
        ...cols,
        custodian: cols.custodian && (showData.custodian ?? true),
        sector:    cols.sector    && (showData.sector    ?? true),
    };

    // ── Chip labels & toggle ───────────────────────────────────────────────────
    const CHIP_KEYS: FilterKey[] = ['directly','nominee','companies','financial','households'];
    const chipLabels: Record<FilterKey, string> = {
        directly: t.chipDirectly, nominee: t.chipNominee,
        companies: t.chipCompanies, financial: t.chipFinancial, households: t.chipHouseholds,
    };
    const handleChipToggle = (key: FilterKey) => {
        const next = activeFilters.includes(key)
            ? activeFilters.filter(f => f !== key)
            : [...activeFilters, key];
        setFilters(next);
    };

    // ── Show-data options ──────────────────────────────────────────────────────
    const showDataOptions = [
        { key: 'address',   label: t.showOptAddress },
        { key: 'isin',      label: t.showOptIsin },
        { key: 'expired',   label: t.showOptExpired },
        { key: 'sector',    label: t.showOptSector },
        { key: 'custodian', label: t.showOptCustodian },
    ];

    // ── Radio options ──────────────────────────────────────────────────────────
    const reportTypeOptions = [
        { key: 'statutory' as ReportType, title: t.reportTypeStatutoryTitle, desc: t.reportTypeStatutoryDesc },
        { key: 'full'      as ReportType, title: t.reportTypeFullTitle,       desc: t.reportTypeFullDesc },
        { key: 'agm'       as ReportType, title: t.reportTypeAgmTitle,        desc: t.reportTypeAgmDesc },
        { key: 'short'     as ReportType, title: t.reportTypeShortTitle,      desc: t.reportTypeShortDesc },
    ];

    // ── Sidebar content per report type (matches Figma exactly) ───────────────
    // For Full: show combined description of all 4 types
    // For others: show specific type description only
    const sidebarReportTypeContent = () => {
        if (reportType === 'full') {
            return (
                <>
                    <p className="rv__sidebar-text">
                        <strong>{t.reportTypeFullTitle}:</strong> {t.sidebarFull}
                    </p>
                    <p className="rv__sidebar-text rv__sidebar-text--mt">
                        <strong>{t.reportTypeAgmTitle}:</strong> {t.sidebarAgm}
                    </p>
                    <p className="rv__sidebar-text rv__sidebar-text--mt">
                        <strong>{t.reportTypeStatutoryTitle}:</strong> {t.sidebarStatutory}
                    </p>
                    <p className="rv__sidebar-text rv__sidebar-text--mt">
                        <strong>{t.reportTypeShortTitle}:</strong> {t.sidebarShort}
                    </p>
                </>
            );
        }
        const desc: Record<ReportType, string> = {
            full: t.sidebarFull, agm: t.sidebarAgm,
            statutory: t.sidebarStatutory, short: t.sidebarShort,
        };
        const title: Record<ReportType, string> = {
            full: t.reportTypeFullTitle, agm: t.reportTypeAgmTitle,
            statutory: t.reportTypeStatutoryTitle, short: t.reportTypeShortTitle,
        };
        return (
            <>
                <p className="rv__sidebar-subtitle">
                    {reportTitle} — {title[reportType]}
                </p>
                <p className="rv__sidebar-text rv__sidebar-text--mt">
                    {t.reportTypeTitle}: {desc[reportType]}
                </p>
            </>
        );
    };

    // ── Filtered summary text — defensive (filterCounts may be partial) ────────
    // Map FilterKey → filterCounts field (naming differs)
    const chipCountMap: Record<string, string> = {
        directly: 'directCount', nominee: 'nomineeCount',
        companies: 'companyCount', financial: 'financialCount', households: 'householdCount',
    };
    const fc = filterCounts as Record<string, number> ?? {};
    const filteredSummaryText = (t.filteredSummary ?? 'Filtered: {owners} owners, {shares} shares')
        .replace('{owners}', String(fc.filteredOwners ?? totalCount))
        .replace('{shares}', String(fc.filteredUnits ?? 0));

    // ══════════════════════════════════════════════════════════════════════════
    // RENDER
    // ══════════════════════════════════════════════════════════════════════════

    return (
        <div className="rv__page">
            {/* ══ BANNER ══ */}
            <Banner appName="MyEuroclear" sticky>
                <Banner.Title>{reportDate} {reportTitle}</Banner.Title>
                <Banner.Actions>
                    <button type="button" className="rv__download-btn" onClick={() => setDownloadOpen(true)}>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                            <path d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                            <path d="M7 11l5 5 5-5M12 4v12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                        {t.downloadFile}
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
                            <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                    </button>
                </Banner.Actions>
                <Banner.Tabs value={activeTab} onValueChange={v => setActiveTab(v as 'report' | 'subscription')}>
                    <Banner.Tab value="report">{t.tabReport}</Banner.Tab>
                    <Banner.Tab value="subscription">{t.tabSubscriptionInfo}</Banner.Tab>
                </Banner.Tabs>
            </Banner>

            <Container>
                <div className="rv">
                    {activeTab === 'report' && (
                        <>
                            {/* ══ SUMMARY CARD ══ */}
                            <section className="rv__summary-card">
                                <h2 className="rv__section-title">{t.summaryTitle}</h2>

                                {/* Info row: issuer + share classes */}
                                <div className="rv__info-row">
                                    <div className="rv__info-block">
                                        <h4 className="rv__info-heading">{t.infoTitle}</h4>
                                        <p className="rv__info-line">{t.issuer}: <strong>{metadata.issuerName || '—'}</strong></p>
                                        <p className="rv__info-line">{t.reportName}: <strong>{metadata.reportName || '—'}</strong></p>
                                        <p className="rv__info-line">{t.situationDate}: <strong>{metadata.situationDate || '—'}</strong></p>
                                    </div>
                                    <div className="rv__shares-block">
                                        <h4 className="rv__info-heading">Arvo-osuudet</h4>
                                        <div className="rv__shares-grid">
                                            {(Array.isArray(securities) ? securities : []).map(s => (
                                                <div key={s.securityId} className="rv__share-col">
                                                    <p className="rv__info-line">{t.shareNameLabel}: <strong>{s.securityName}</strong></p>
                                                    <p className="rv__info-line">{t.isinLabel}: <strong>—</strong></p>
                                                    <p className="rv__info-line">{t.abbreviationLabel}: <strong>{s.securityShortName}</strong></p>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                {/* Summary table */}
                                <h3 className="rv__sub-title">Yhteenveto</h3>
                                <div className="rv__summary-table-wrap">
                                    <Table layout="auto" hover striped>
                                        <Table.Head>
                                            <Table.Row>
                                                <Table.HeadCell column="ao" sortable sortDirection="desc">{t.summColBookEntry}</Table.HeadCell>
                                                <Table.HeadCell column="om">{t.summColOwners}</Table.HeadCell>
                                                <Table.HeadCell column="yh">{t.summColJointOwners}</Table.HeadCell>
                                                <Table.HeadCell column="kk">{t.summColVotesConferred}</Table.HeadCell>
                                                <Table.HeadCell column="os">{t.summColPctVotes}</Table.HeadCell>
                                                <Table.HeadCell column="ka">{t.summColTotalVotes}</Table.HeadCell>
                                                <Table.HeadCell column="ol">{t.summColInShareholderList}</Table.HeadCell>
                                                <Table.HeadCell column="od">{t.summColInWaitingList}</Table.HeadCell>
                                                <Table.HeadCell column="hr">{t.summColNomineeReg}</Table.HeadCell>
                                                <Table.HeadCell column="yt">{t.summColJointAccount}</Table.HeadCell>
                                                <Table.HeadCell column="lm">{t.summColIssuedAmount}</Table.HeadCell>
                                            </Table.Row>
                                        </Table.Head>
                                        <Table.Body>
                                            {(Array.isArray(summaryRows) ? summaryRows : []).map(row => (
                                                <Table.Row key={row.shareClassCode}>
                                                    <Table.BodyCell>
                                                        {row.isBold
                                                            ? <strong>{row.isTotal ? t.summaryTotal : row.shareClassCode}</strong>
                                                            : row.shareClassCode}
                                                    </Table.BodyCell>
                                                    <Table.BodyCell>{row.ownerCount}</Table.BodyCell>
                                                    <Table.BodyCell>{row.jointOwnerCount}</Table.BodyCell>
                                                    <Table.BodyCell>{row.votesConferred}</Table.BodyCell>
                                                    <Table.BodyCell>{row.votesPercentage}</Table.BodyCell>
                                                    <Table.BodyCell>{row.totalVotes}</Table.BodyCell>
                                                    <Table.BodyCell>{row.inShareholderList}</Table.BodyCell>
                                                    <Table.BodyCell>{row.inWaitingList}</Table.BodyCell>
                                                    <Table.BodyCell>{row.nomineeRegistered}</Table.BodyCell>
                                                    <Table.BodyCell>{row.inJointAccount}</Table.BodyCell>
                                                    <Table.BodyCell>{row.issuedAmount}</Table.BodyCell>
                                                </Table.Row>
                                            ))}
                                        </Table.Body>
                                    </Table>
                                </div>
                            </section>

                            {/* ══ FILTERS + SIDEBAR 80/20 ══ */}
                            <div className="rv__content-layout">

                                {/* ── LEFT 80%: Filter sections ── */}
                                <div className="rv__filters-left">

                                    {/* Report type — always visible, all 4 radios in ONE row */}
                                    <section className="rv__filter-section">
                                        <h3 className="rv__filter-label">
                                            {t.reportTypeTitle}
                                            <ButtonIcon className="rv__info-btn" aria-label="Report type info">
                                                <InfoIcon />
                                            </ButtonIcon>
                                        </h3>
                                        <div className="rv__radio-row">
                                            {reportTypeOptions.map(({ key, title, desc }) => (
                                                <label key={key} className="rv__radio-option">
                                                    <input
                                                        type="radio"
                                                        name="reportType"
                                                        checked={reportType === key}
                                                        onChange={() => { setReportType(key); setPage(1); }}
                                                        className="rv__radio-input"
                                                    />
                                                    <span className="rv__radio-content">
                                                        <span className="rv__radio-title">{title}</span>
                                                        <span className="rv__radio-desc">{desc}</span>
                                                    </span>
                                                </label>
                                            ))}
                                        </div>
                                    </section>

                                    {/* Show details — only Full */}
                                    {showFilters && (
                                        <section className="rv__filter-section">
                                            <h3 className="rv__filter-label">
                                                {t.showDataTitle}
                                                <ButtonIcon className="rv__info-btn" aria-label="Show data info">
                                                    <InfoIcon />
                                                </ButtonIcon>
                                            </h3>
                                            <div className="rv__checkbox-row">
                                                {showDataOptions.map(opt => (
                                                    <label key={opt.key} className="rv__checkbox-option">
                                                        <input
                                                            type="checkbox"
                                                            checked={showData[opt.key]}
                                                            onChange={() => setShowData(p => ({ ...p, [opt.key]: !p[opt.key] }))}
                                                            className="rv__checkbox-input"
                                                        />
                                                        <span className="rv__checkbox-label">{opt.label}</span>
                                                    </label>
                                                ))}
                                            </div>
                                        </section>
                                    )}

                                    {/* Filtering chips — only Full */}
                                    {showFilters && (
                                        <section className="rv__filter-section">
                                            <h3 className="rv__filter-label">
                                                {t.filterTitle}
                                                <ButtonIcon className="rv__info-btn" aria-label="Filter info">
                                                    <InfoIcon />
                                                </ButtonIcon>
                                            </h3>
                                            <div className="rv__chips-row">
                                                {CHIP_KEYS.map(key => (
                                                    <Chip
                                                        key={key}
                                                        mode="selectable"
                                                        size="medium"
                                                        selected={activeFilters.includes(key)}
                                                        onClick={() => handleChipToggle(key)}
                                                    >
                                                        {chipLabels[key]}
                                                        <Chip.Counter>{fc[chipCountMap[key]] ?? 0}</Chip.Counter>
                                                    </Chip>
                                                ))}
                                            </div>
                                        </section>
                                    )}
                                </div>

                                {/* ── RIGHT 20%: Sidebar ── */}
                                <aside className="rv__sidebar">
                                    {/* Report type description — content varies per selection */}
                                    <section className="rv__sidebar-section">
                                        <h4 className="rv__sidebar-title">{t.reportTypeTitle}</h4>
                                        {sidebarReportTypeContent()}
                                    </section>

                                    {/* Show details desc — only Full */}
                                    {showFilters && (
                                        <section className="rv__sidebar-section">
                                            <h4 className="rv__sidebar-title">{t.showDataTitle}</h4>
                                            <p className="rv__sidebar-text">{t.showDataDesc}</p>
                                        </section>
                                    )}

                                    {/* Filtering desc — only Full */}
                                    {showFilters && (
                                        <section className="rv__sidebar-section">
                                            <h4 className="rv__sidebar-title">{t.filterTitle}</h4>
                                            <p className="rv__sidebar-text">{t.filterDesc}</p>
                                        </section>
                                    )}

                                    {/* File download — always */}
                                    <section className="rv__sidebar-section">
                                        <h4 className="rv__sidebar-title">{t.fileDownloadTitle}</h4>
                                        <p className="rv__sidebar-text">{t.fileDownloadSidebarDesc}</p>
                                    </section>
                                </aside>
                            </div>

                            {/* ══ SEARCH BAR (LEFT) + LEGEND (RIGHT) — one line ══ */}
                            <div className="rv__search-legend-row">
                                <div className="rv__search-left">
                                    <p className="rv__filter-summary">{filteredSummaryText}</p>
                                    <div className="rv__search-box">
                                        <input
                                            type="text"
                                            placeholder={t.searchPlaceholder}
                                            value={search}
                                            onChange={e => setSearch(e.target.value)}
                                            className="rv__search-input"
                                        />
                                        <svg className="rv__search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none">
                                            <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="1.5"/>
                                            <path d="M16.5 16.5L21 21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                                        </svg>
                                    </div>
                                </div>
                                <div className="rv__legend-row">
                                    <span className="rv__legend-item"><span className="rv__legend-icon rv__legend-icon--nondisclosure" aria-hidden="true" />  {t.legendNonDisclosure}</span>
                                    <span className="rv__legend-item"><span className="rv__legend-icon rv__legend-icon--joint" aria-hidden="true" /> {t.legendJointOwnership}</span>
                                    <span className="rv__legend-item"><span className="rv__legend-icon rv__legend-icon--nominee" aria-hidden="true" /> {t.legendNomineeHolding}</span>
                                    <span className="rv__legend-item"><span className="rv__legend-icon rv__legend-icon--bank" aria-hidden="true" /> {t.legendNomineeCustodians}</span>
                                </div>
                            </div>

                            {/* ══ OWNER TABLE ══ */}
                            {ownersLoading ? (
                                <div className="rv__loader-wrap">
                                    <Loader aria-label="Loading owners" />
                                </div>
                            ) : (
                                <OwnerTable rows={Array.isArray(owners) ? owners : []} cols={effectiveCols} t={t} sortDir="asc" onSort={() => {}} />
                            )}

                            {/* ══ PAGINATION ══ */}
                            {totalPages > 1 && (
                                <div className="rv__pagination">
                                    <span className="rv__pagination-info">
                                        {((currentPage - 1) * 13) + 1}–{Math.min(currentPage * 13, totalCount)} / {totalCount}
                                    </span>
                                    <Pagination
                                        as="button"
                                        currentPage={currentPage}
                                        totalPages={totalPages}
                                        maxPages={5}
                                        onPageChange={(p: number) => setPage(p)}
                                        showFirst showLast showNext showPrevious
                                        ariaLabels={{
                                            first: 'Move to first page', last: 'Move to last page',
                                            nav: 'Navigate between paginated table',
                                            next: 'Move to next page', page: 'Move to page',
                                            previous: 'Move to previous page',
                                        }}
                                    />
                                </div>
                            )}
                        </>
                    )}

                    {activeTab === 'subscription' && (
                        <div className="rv__subscription-tab">
                            <p>Subscription info — coming soon</p>
                        </div>
                    )}
                </div>
            </Container>

            {/* ══ DOWNLOAD MODAL ══ */}
            <DownloadModal
                isOpen={downloadOpen}
                language={language}
                currentReportType={reportType}
                onClose={() => setDownloadOpen(false)}
                onDownload={(opts) => {
                    console.log('Download:', opts);
                    setDownloadOpen(false);
                    onDownload?.();
                }}
            />
        </div>
    );
}
