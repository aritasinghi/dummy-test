// ─── ReportView ───────────────────────────────────────────────────────────────
// Main page component. Composed of sub-components:
//   types.ts        — shared types + COLS visibility map
//   reportData.ts   — mock data (replace with API)
//   useReportData.ts — API hook (wire up real endpoint later)
//   OwnerTableRow.tsx — single row, conditional columns
//   OwnerTable.tsx  — table header + body (only active cols rendered)
//   index.tsx       — this file: state + layout

import { useState } from 'react';
import {
    Banner, Chip, Table, PaginationRoot, ButtonIcon, InfoIcon, Container,
} from '@efi/efi-ui-components';
import type { Language } from '@/locales';
import { translations } from '@/locales';

import type { ReportType, SortDir } from './types';
import { COLS, SHOW_FILTERS_FOR } from './types';
import { SHOW_DATA_KEYS, INITIAL_CHIP_KEYS, SUMMARY_ROWS, SHARES_INFO } from './reportData';
import { useReportData } from './useReportData';
import { OwnerTable } from './OwnerTable';
import './ReportView.css';

interface ReportViewProps {
    reportTitle: string;
    reportDate:  string;
    language:    Language;
    onBack:      () => void;
    onSubscribe: () => void;
    onDownload?: () => void;
}

export default function ReportView({
    reportTitle, reportDate, language, onBack, onSubscribe, onDownload,
}: ReportViewProps) {
    const t = translations[language].reportView;

    const [activeTab,   setActiveTab]   = useState<'report' | 'subscription'>('report');
    const [reportType,  setReportType]  = useState<ReportType>('statutory');
    const [showData,    setShowData]    = useState<Record<string, boolean>>(
        Object.fromEntries(SHOW_DATA_KEYS.map(k => [k, true]))
    );
    const [chips,       setChips]       = useState(INITIAL_CHIP_KEYS.map(c => ({ ...c })));
    const [search,      setSearch]      = useState('');
    const [sortDir,     setSortDir]     = useState<SortDir>('asc');
    const [currentPage, setCurrentPage] = useState(1);
    const totalPages = 14;

    const cols        = COLS[reportType];
    const showFilters = SHOW_FILTERS_FOR[reportType]; // Näytä tiedot + Suodatus only for Full

    const { owners, metadata, loading } = useReportData({ search });

    const chipLabels: Record<string, string> = {
        directly: t.chipDirectly, nominee: t.chipNominee, companies: t.chipCompanies,
        financial: t.chipFinancial, households: t.chipHouseholds,
    };
    const showDataOptions = [
        { key: 'address',   label: t.showOptAddress },
        { key: 'isin',      label: t.showOptIsin },
        { key: 'expired',   label: t.showOptExpired },
        { key: 'sector',    label: t.showOptSector },
        { key: 'custodian', label: t.showOptCustodian },
    ];
    const sidebarDesc: Record<ReportType, string> = {
        full: t.sidebarFull, agm: t.sidebarAgm,
        statutory: t.sidebarStatutory, short: t.sidebarShort,
    };
    const reportTypeOptions = [
        { key: 'statutory' as ReportType, title: t.reportTypeStatutoryTitle, desc: t.reportTypeStatutoryDesc },
        { key: 'full'      as ReportType, title: t.reportTypeFullTitle,       desc: t.reportTypeFullDesc },
        { key: 'agm'       as ReportType, title: t.reportTypeAgmTitle,        desc: t.reportTypeAgmDesc },
        { key: 'short'     as ReportType, title: t.reportTypeShortTitle,      desc: t.reportTypeShortDesc },
    ];

    const toggleChip = (key: string) =>
        setChips(prev => prev.map(c => c.key === key ? { ...c, active: !c.active } : c));

    const filteredSummaryText = t.filteredSummary
        .replace('{owners}', String(owners.length))
        .replace('{shares}', String(owners.reduce((s, r) => s + r.shares.length, 0)));

    return (
        <>
            <Banner appName="MyEuroclear" sticky={true}>
                <Banner.Title>{reportDate} {reportTitle}</Banner.Title>
                <Banner.Actions>
                    <button type="button" className="rv__download-btn" onClick={onDownload}>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                            <path d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                            <path d="M7 11l5 5 5-5M12 4v12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                        {t.downloadFile}
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                            <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                    </button>
                </Banner.Actions>
                <Banner.Tabs
                    value={activeTab}
                    onValueChange={(val: string) => setActiveTab(val as 'report' | 'subscription')}
                >
                    <Banner.Tab value="report">{t.tabReport}</Banner.Tab>
                    <Banner.Tab value="subscription">{t.tabSubscriptionInfo}</Banner.Tab>
                </Banner.Tabs>
            </Banner>

            <Container>
                <div className="rv">
                    {activeTab === 'report' && (
                        <>
                            {/* ══ SUMMARY CARD ══ */}
                            <section className="rv__summary-card">
                                <h2 className="rv__section-title">{t.summaryTitle}</h2>
                                <div className="rv__info-row">
                                    <div className="rv__info-block">
                                        <h4 className="rv__info-heading">{t.infoTitle}</h4>
                                        <p className="rv__info-line">{t.issuer}: <strong>{metadata.issuer}</strong></p>
                                        <p className="rv__info-line">{t.reportName}: <strong>{metadata.reportName}</strong></p>
                                        <p className="rv__info-line">{t.situationDate}: <strong>{metadata.situationDate}</strong></p>
                                    </div>
                                    <div className="rv__shares-block">
                                        <h4 className="rv__info-heading">Arvo-osuudet</h4>
                                        <div className="rv__shares-grid">
                                            {SHARES_INFO.map(s => (
                                                <div key={s.isin} className="rv__share-col">
                                                    <p className="rv__info-line">{t.shareNameLabel}: <strong>{s.name}</strong></p>
                                                    <p className="rv__info-line">{t.isinLabel}: <strong>{s.isin}</strong></p>
                                                    <p className="rv__info-line">{t.abbreviationLabel}: <strong>{s.abbr}</strong></p>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                                <h3 className="rv__sub-title">Yhteenveto</h3>
                                <div className="rv__summary-table-wrap">
                                    <Table layout="fixed" hover striped>
                                        <Table.Head>
                                            <Table.Row>
                                                <Table.HeadCell column="ao" sortable sortDirection="desc">{t.summColBookEntry}</Table.HeadCell>
                                                <Table.HeadCell column="om">{t.summColOwners}</Table.HeadCell>
                                                <Table.HeadCell column="yh">{t.summColJointOwners}</Table.HeadCell>
                                                <Table.HeadCell column="kk">{t.summColVotesConferred}</Table.HeadCell>
                                                <Table.HeadCell column="os">{t.summColPctVotes}</Table.HeadCell>
                                                <Table.HeadCell column="ka">{t.summColTotalVotes}</Table.HeadCell>
                                                <Table.HeadCell column="ol">{t.summColInShareholderList}</Table.HeadCell>
                                                <Table.HeadCell column="od">{t.summColInWaitingList}</Table.HeadCell>
                                                <Table.HeadCell column="hr">{t.summColNomineeReg}</Table.HeadCell>
                                                <Table.HeadCell column="yt">{t.summColJointAccount}</Table.HeadCell>
                                                <Table.HeadCell column="lm">{t.summColIssuedAmount}</Table.HeadCell>
                                            </Table.Row>
                                        </Table.Head>
                                        <Table.Body>
                                            {SUMMARY_ROWS.map(row => (
                                                <Table.Row key={row.aoLaji}>
                                                    <Table.BodyCell>
                                                        {row.bold ? <strong>{row.isTotal ? t.summaryTotal : row.aoLaji}</strong> : row.aoLaji}
                                                    </Table.BodyCell>
                                                    <Table.BodyCell>{row.omistajien}</Table.BodyCell>
                                                    <Table.BodyCell>{row.yhteis}</Table.BodyCell>
                                                    <Table.BodyCell>{row.kaikkien}</Table.BodyCell>
                                                    <Table.BodyCell>{row.osuus}</Table.BodyCell>
                                                    <Table.BodyCell>{row.kokonaisAani}</Table.BodyCell>
                                                    <Table.BodyCell>{row.osakas}</Table.BodyCell>
                                                    <Table.BodyCell>{row.odotus}</Table.BodyCell>
                                                    <Table.BodyCell>{row.hallinta}</Table.BodyCell>
                                                    <Table.BodyCell>{row.yhteistili}</Table.BodyCell>
                                                    <Table.BodyCell>{row.liikkeeseen}</Table.BodyCell>
                                                </Table.Row>
                                            ))}
                                        </Table.Body>
                                    </Table>
                                </div>
                            </section>

                            {/* ══ FILTERS + SIDEBAR (80/20) ══ */}
                            <div className="rv__content-layout">
                                <div className="rv__filters-left">

                                    {/* Report type — always visible, all 4 radios */}
                                    <section className="rv__filter-section">
                                        <h3 className="rv__filter-label">
                                            {t.reportTypeTitle}
                                            <ButtonIcon className="rv__info-btn" aria-label="Report type info">
                                                <InfoIcon />
                                            </ButtonIcon>
                                        </h3>
                                        <div className="rv__radio-row">
                                            {reportTypeOptions.map(({ key, title, desc }) => (
                                                <label key={key} className="rv__radio-option">
                                                    <input
                                                        type="radio"
                                                        name="reportType"
                                                        checked={reportType === key}
                                                        onChange={() => { setReportType(key); setCurrentPage(1); }}
                                                        className="rv__radio-input"
                                                    />
                                                    <span className="rv__radio-content">
                                                        <span className="rv__radio-title">{title}</span>
                                                        <span className="rv__radio-desc">{desc}</span>
                                                    </span>
                                                </label>
                                            ))}
                                        </div>
                                    </section>

                                    {/* Show details — only when Full selected */}
                                    {showFilters && (
                                        <section className="rv__filter-section">
                                            <h3 className="rv__filter-label">
                                                {t.showDataTitle}
                                                <ButtonIcon className="rv__info-btn" aria-label="Show data info">
                                                    <InfoIcon />
                                                </ButtonIcon>
                                            </h3>
                                            <div className="rv__checkbox-row">
                                                {showDataOptions.map(opt => (
                                                    <label key={opt.key} className="rv__checkbox-option">
                                                        <input
                                                            type="checkbox"
                                                            checked={showData[opt.key]}
                                                            onChange={() => setShowData(p => ({ ...p, [opt.key]: !p[opt.key] }))}
                                                            className="rv__checkbox-input"
                                                        />
                                                        <span className="rv__checkbox-label">{opt.label}</span>
                                                    </label>
                                                ))}
                                            </div>
                                        </section>
                                    )}

                                    {/* Filtering chips — only when Full selected */}
                                    {showFilters && (
                                        <section className="rv__filter-section rv__filter-section--last">
                                            <h3 className="rv__filter-label">
                                                {t.filterTitle}
                                                <ButtonIcon className="rv__info-btn" aria-label="Filtering info">
                                                    <InfoIcon />
                                                </ButtonIcon>
                                            </h3>
                                            <div className="rv__chips-row">
                                                {chips.map(chip => (
                                                    <Chip
                                                        key={chip.key}
                                                        mode="selectable"
                                                        size="medium"
                                                        selected={chip.active}
                                                        onClick={() => toggleChip(chip.key)}
                                                    >
                                                        {chipLabels[chip.key]}
                                                        <Chip.Counter>{chip.count}</Chip.Counter>
                                                    </Chip>
                                                ))}
                                            </div>
                                        </section>
                                    )}
                                </div>

                                {/* RIGHT 20% — sidebar */}
                                <div className="rv__sidebar">
                                    <section className="rv__sidebar-section">
                                        <h4 className="rv__sidebar-title">{t.reportTypeTitle}</h4>
                                        <p className="rv__sidebar-text" style={{ whiteSpace: 'pre-line' }}>{sidebarDesc[reportType]}</p>
                                    </section>
                                    {showFilters && (
                                        <>
                                            <section className="rv__sidebar-section">
                                                <h4 className="rv__sidebar-title">{t.showDataTitle}</h4>
                                                <p className="rv__sidebar-text">In the Show details section, you can control which columns are displayed in the table.</p>
                                            </section>
                                            <section className="rv__sidebar-section">
                                                <h4 className="rv__sidebar-title">{t.filterTitle}</h4>
                                                <p className="rv__sidebar-text">Filters allow you to control the content shown in the table.</p>
                                            </section>
                                        </>
                                    )}
                                    <section className="rv__sidebar-section rv__sidebar-section--last">
                                        <h4 className="rv__sidebar-title">{t.fileDownloadTitle}</h4>
                                        <p className="rv__sidebar-text">{t.fileDownloadSidebarDesc}</p>
                                    </section>
                                </div>
                            </div>

                            {/* ══ SEARCH + LEGEND ══ */}
                            <div className="rv__search-and-legend">
                                <p className="rv__filter-summary">{filteredSummaryText}</p>
                                <div className="rv__search-box">
                                    <input
                                        type="text"
                                        placeholder={t.searchPlaceholder}
                                        value={search}
                                        onChange={e => setSearch(e.target.value)}
                                        className="rv__search-input"
                                    />
                                    <span className="rv__search-icon">🔍</span>
                                </div>
                                <div className="rv__legend-row">
                                    <span className="rv__legend-item">🚫 {t.legendNonDisclosure}</span>
                                    <span className="rv__legend-item">🔗 {t.legendJointOwnership}</span>
                                    <span className="rv__legend-item">📋 {t.legendNomineeHolding}</span>
                                    <span className="rv__legend-item">🏦 {t.legendNomineeCustodians}</span>
                                </div>
                            </div>

                            {/* ══ OWNER TABLE ══ */}
                            {loading ? (
                                <div className="rv__loading">Loading…</div>
                            ) : (
                                <OwnerTable
                                    rows={owners}
                                    cols={cols}
                                    t={t}
                                    sortDir={sortDir}
                                    onSort={setSortDir}
                                />
                            )}

                            {/* ══ PAGINATION ══ */}
                            <div className="rv__pagination">
                                <PaginationRoot
                                    as="button"
                                    currentPage={currentPage}
                                    totalPages={totalPages}
                                    maxPages={5}
                                    onPageChange={(page: number) => setCurrentPage(page)}
                                    showFirst showLast showNext showPrevious
                                    ariaLabels={{
                                        first: 'Move to first page', last: 'Move to last page',
                                        nav: 'Navigate between paginated table',
                                        next: 'Move to next page', page: 'Move to page',
                                        previous: 'Move to previous page',
                                    }}
                                />
                            </div>
                        </>
                    )}

                    {activeTab === 'subscription' && (
                        <div className="rv__subscription-tab">
                            <p>Subscription info — coming soon</p>
                        </div>
                    )}
                </div>
            </Container>
        </>
    );
}
