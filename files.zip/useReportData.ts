// ─── useReportData ────────────────────────────────────────────────────────────
// Placeholder API hook. Replace mock data with real fetch calls when API is ready.
//
// Example future implementation:
//   const { data } = useSWR(`/api/reports/${reportId}/owners`, fetcher);
//
// For now returns mock data synchronously.

import { useState, useEffect } from 'react';
import type { OwnerRow, SummaryRow, ShareInfo } from './types';
import { OWNER_ROWS, SUMMARY_ROWS, SHARES_INFO } from './reportData';

export interface ReportMetadata {
    issuer:        string;
    reportName:    string;
    situationDate: string;
}

export interface ReportDataState {
    owners:   OwnerRow[];
    summary:  SummaryRow[];
    shares:   ShareInfo[];
    metadata: ReportMetadata;
    loading:  boolean;
    error:    string | null;
}

interface UseReportDataOptions {
    reportId?: string;
    search?:   string;
}

export function useReportData({ search = '' }: UseReportDataOptions = {}): ReportDataState {
    const [loading, setLoading] = useState(false);
    const [error]   = useState<string | null>(null);

    // Simulate async load (remove once real API wired in)
    useEffect(() => {
        setLoading(true);
        const t = setTimeout(() => setLoading(false), 0);
        return () => clearTimeout(t);
    }, []);

    const filteredOwners = OWNER_ROWS.filter(row =>
        !search || row.name.toLowerCase().includes(search.toLowerCase())
    );

    return {
        owners:   filteredOwners,
        summary:  SUMMARY_ROWS,
        shares:   SHARES_INFO,
        metadata: {
            issuer:        'Euroflex Oyj',
            reportName:    'Liikkeeseenlaskijan omistusraportti',
            situationDate: '13.3.2026',
        },
        loading,
        error,
    };
}
