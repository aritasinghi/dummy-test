import { useState, useMemo } from 'react';
import './ExtractOfOwnersFilterSection.css';
import SearchableMultiSelect from './shared/components/SearchableMultiSelect';
import countriesData from './shared/data/countries.json';

// =============================================================================
// Types
// =============================================================================

export interface BookEntryType {
    code: string;      // e.g. "Euroflex A"
    isin: string;       // e.g. "FI21049685930"
}

export interface HoldingsRange {
    min: string;
    max: string;
}

export interface PerTypeHoldings {
    code: string;                 // BookEntryType.code this row belongs to
    mode: 'all' | 'range';
    min: string;
    max: string;
}

export interface PostalCodeRange {
    from: string;
    to: string;
}

export interface AgeRange {
    from: string;
    to: string;
}

export interface SectorOption {
    code: string;          // "111211"
    label: string;         // "Domestic corporations"
    parentCode?: string;    // "1100000" — used to auto-include children when a parent is checked
}

export type HoldingsMode = 'all' | 'combined' | 'perType';
export type PostAddressMode = 'all' | 'single' | 'range';
export type SelectionMode = 'all' | 'select';
export type OwnerType = 'both' | 'natural' | 'legal';
export type RegistrationType = 'both' | 'direct' | 'nominee';
export type DirectMarketing = 'included' | 'notIncluded';
export type AgeGroupMode = 'all' | 'predefined' | 'custom';

export interface ExtractOfOwnersFilters {
    holdingsMode: HoldingsMode;
    holdingsCombinedRange: HoldingsRange;
    holdingsPerType: PerTypeHoldings[];

    postAddressMode: PostAddressMode;
    postalCodes: string[];
    postalCodeRanges: PostalCodeRange[];

    countryMode: SelectionMode;
    countries: string[];

    sectorMode: SelectionMode;
    sectors: string[];

    ownerType: OwnerType;
    registrationType: RegistrationType;
    directMarketing: DirectMarketing;

    ageGroupMode: AgeGroupMode;
    predefinedAgeGroups: string[];
    customAgeRanges: AgeRange[];

    onlyAddressInfo: boolean;
}

interface Texts {
    title: string;
    rangeOfHoldings: string;
    allHoldings: string;
    numberOfHoldingsCombined: string;
    numberOfHoldingsPerType: string;
    combinedHeading: string;
    perTypeHeading: string;
    min: string;
    max: string;
    rangeOfHoldingsRadio: string;
    holdingsInfoTitle: string;
    holdingsInfoCombinedDesc: string;
    holdingsInfoPerTypeDesc: string;

    postAddress: string;
    selectAll: string;
    postAddresses: string;
    rangeOfPostAddresses: string;
    postalCode: string;
    addToSelection: string;
    selected: string;
    deselectAll: string;
    from: string;
    to: string;
    postAddressDefault: string;
    postAddressInfoTitle: string;
    postAddressInfoDesc: string;

    country: string;
    selectCountries: string;
    countryLabel: string;
    countryDefault: string;
    countryInfoTitle: string;
    countryInfoDesc: string;

    sectorClassification: string;
    selectSectors: string;
    sectorLabel: string;
    sectorDefault: string;
    sectorInfoTitle: string;
    sectorInfoDesc: string;

    ownerType: string;
    both: string;
    naturalPersons: string;
    legalPersons: string;
    ownerTypeInfo: string;

    registrationType: string;
    directHoldingOwners: string;
    nomineeRegistrationCustodians: string;
    registrationTypeInfo: string;

    directMarketing: string;
    toBeIncluded: string;
    notToBeIncluded: string;
    directMarketingInfo: string;

    ageGroups: string;
    all: string;
    predefinedAgeGroups: string;
    customAgeRange: string;
    ageGroupsInfoTitle: string;
    ageGroupsInfoDesc: string;

    onlyAddressInfo: string;
    yes: string;
    onlyAddressInfoInfoTitle: string;
    onlyAddressInfoInfoDesc: string;

    priceNote: string;
    cancel: string;
    continue: string;
}

const EN: Texts = {
    title: 'Order new report: Extract of Owners',
    rangeOfHoldings: 'Range of holdings',
    allHoldings: 'All holdings',
    numberOfHoldingsCombined: 'Number of holdings combined',
    numberOfHoldingsPerType: 'Number of holdings per Book-Entry Type',
    combinedHeading: 'Number of owned Book-Entries Book-Entry Types combined.',
    perTypeHeading: 'Number of owned Book-Entries per Book-Entry Type',
    min: 'min',
    max: 'max',
    rangeOfHoldingsRadio: 'Range of holdings',
    holdingsInfoTitle: 'Number of holdings',
    holdingsInfoCombinedDesc: 'User can select the holdings in the report based on the number of owned Book-Entries.',
    holdingsInfoPerTypeDesc: 'User can select the holdings in the report based on the number of owned Book-Entries per Book-Entry Type.',

    postAddress: 'Post address',
    selectAll: 'Select all',
    postAddresses: 'Post addresses',
    rangeOfPostAddresses: 'Range of post addresses',
    postalCode: 'Postal code',
    addToSelection: 'Add to selection',
    selected: 'Selected:',
    deselectAll: 'Deselect all',
    from: 'From',
    to: 'To',
    postAddressDefault: 'By default all the post addresses are selected. Select Post addresses above to select specific post addresses or Range of post addresses to filter by a range.',
    postAddressInfoTitle: 'Holdings in the report based on post addresses',
    postAddressInfoDesc: 'You can select the holdings in the report based on one, several or range of post addresses. You can select one or more ranges e.g., 5200 \u2013 5600, only 5200 or 5200 and 5600',

    country: 'Country of residence / registration',
    selectCountries: 'Select the countries',
    countryLabel: 'Country',
    countryDefault: 'By default all countries are included.',
    countryInfoTitle: 'Select the country of residence / registration',
    countryInfoDesc: 'You can select the holdings in the report based on the selected countries. For natural persons country information applies and for legal entities country of registration applies. If owner has a non-disclosure, the actual address information is used and not the contact address.',

    sectorClassification: 'Sector classification',
    selectSectors: 'Select the sectors',
    sectorLabel: 'Sector',
    sectorDefault: 'By default all sectors are included.',
    sectorInfoTitle: 'Sector classification',
    sectorInfoDesc: 'You can select one or more sector codes. The selection automatically includes the subcodes of the selected sector codes. You can remove your selections at any time.',

    ownerType: 'Owner type',
    both: 'Both',
    naturalPersons: 'Natural persons',
    legalPersons: 'Legal persons',
    ownerTypeInfo: 'You can include natural persons, legal persons or both',

    registrationType: 'Registration type',
    directHoldingOwners: 'Direct-Holding Owners',
    nomineeRegistrationCustodians: 'Nominee Registration Custodians',
    registrationTypeInfo: 'You can include Direct-Holding Owners, Nominee Registration Custodians or both',

    directMarketing: 'Direct marketing prohibitions',
    toBeIncluded: 'To be included',
    notToBeIncluded: 'Not to be included',
    directMarketingInfo: 'You can select to include Direct-Holding Owners and Nominee Registration Custodians who have active direct marketing prohibition: underage owners and owners who have declined the usage of their contact information',

    ageGroups: 'Age groups',
    all: 'All',
    predefinedAgeGroups: 'Pre-defined age-groups',
    customAgeRange: 'Custom age range',
    ageGroupsInfoTitle: 'Age groups',
    ageGroupsInfoDesc: 'User can select the holdings in the report based on pre-defined age groups (multi select) or use custom age range.',

    onlyAddressInfo: 'Only address information',
    yes: 'Yes',
    onlyAddressInfoInfoTitle: 'Only address information',
    onlyAddressInfoInfoDesc: 'This can be selected as Yes, if user orders only the address information of selected Owners.',

    priceNote: 'The report price or cost estimate will be displayed in the next view.',
    cancel: 'Cancel',
    continue: 'Continue',
};

const DEFAULT_AGE_GROUPS = ['Under 18', '18-30', '31-50', '51-65', '65+'];
// Front-end owned country list (shared/data/countries.json) — no backend call, filtered client-side as the user types.
const DEFAULT_COUNTRIES: string[] = (countriesData as { code: string; name: string }[]).map((c) => c.name);
const DEFAULT_SECTORS: SectorOption[] = [
    { code: '1000000', label: 'TOTAL ECONOMY' },
    { code: '1100000', label: 'CORPORATIONS', parentCode: '1000000' },
    { code: '111211', label: 'Domestic corporations', parentCode: '1100000' },
    { code: '111212', label: 'Financial and insurance institutions', parentCode: '1100000' },
];

const makeDefaultFilters = (bookEntryTypes: BookEntryType[]): ExtractOfOwnersFilters => ({
    holdingsMode: 'all',
    holdingsCombinedRange: { min: '', max: '' },
    holdingsPerType: bookEntryTypes.map((t) => ({ code: t.code, mode: 'all', min: '', max: '' })),

    postAddressMode: 'all',
    postalCodes: [],
    postalCodeRanges: [],

    countryMode: 'all',
    countries: [],

    sectorMode: 'all',
    sectors: [],

    ownerType: 'both',
    registrationType: 'both',
    directMarketing: 'included',

    ageGroupMode: 'all',
    predefinedAgeGroups: [],
    customAgeRanges: [],

    onlyAddressInfo: false,
});

interface Props {
    isOpen: boolean;
    /** Book-entry types carried over from step 1 of the subscription modal (e.g. Euroflex A, B). */
    bookEntryTypes?: BookEntryType[];
    countryOptions?: string[];
    sectorOptions?: SectorOption[];
    ageGroupOptions?: string[];
    /** Optional starting values, e.g. when re-opening a previously configured order. */
    initialFilters?: Partial<ExtractOfOwnersFilters>;
    onCancel: () => void;
    onContinue: (filters: ExtractOfOwnersFilters) => void;
    texts?: Partial<Texts>;
}

// =============================================================================
// Small reusable bits
// =============================================================================

function TagList({
    items,
    onRemove,
    onDeselectAll,
    deselectLabel,
}: {
    items: string[];
    onRemove: (item: string) => void;
    onDeselectAll: () => void;
    deselectLabel: string;
}) {
    if (items.length === 0) return null;
    return (
        <div className="eoo-filter__tag-row">
            {items.map((item) => (
                <span key={item} className="eoo-filter__tag">
                    {item}
                    <button
                        type="button"
                        className="eoo-filter__tag-remove"
                        onClick={() => onRemove(item)}
                        aria-label={`Remove ${item}`}
                    >
                        &times;
                    </button>
                </span>
            ))}
            <button type="button" className="eoo-filter__deselect-all" onClick={onDeselectAll}>
                {deselectLabel} <span aria-hidden="true">&times;</span>
            </button>
        </div>
    );
}

function InfoBox({ title, desc }: { title: string; desc: string }) {
    return (
        <div className="eoo-filter__info-box">
            <h4 className="eoo-filter__info-title">{title}</h4>
            <p className="eoo-filter__info-desc">{desc}</p>
        </div>
    );
}

function RadioRow<T extends string>({
    name,
    value,
    options,
    onChange,
}: {
    name: string;
    value: T;
    options: { value: T; label: string }[];
    onChange: (value: T) => void;
}) {
    return (
        <div className="eoo-filter__radio-row">
            {options.map((opt) => (
                <label key={opt.value} className="eoo-filter__radio">
                    <input
                        type="radio"
                        name={name}
                        checked={value === opt.value}
                        onChange={() => onChange(opt.value)}
                    />
                    <span className="eoo-filter__radio-dot" />
                    <span className="eoo-filter__radio-text">{opt.label}</span>
                </label>
            ))}
        </div>
    );
}

// =============================================================================
// Main component
// =============================================================================

export default function ExtractOfOwnersFilterSection({
    isOpen,
    bookEntryTypes = [
        { code: 'Euroflex A', isin: 'FI21049685930' },
        { code: 'Euroflex B', isin: 'FI21049685931' },
    ],
    countryOptions = DEFAULT_COUNTRIES,
    sectorOptions = DEFAULT_SECTORS,
    ageGroupOptions = DEFAULT_AGE_GROUPS,
    initialFilters,
    onCancel,
    onContinue,
    texts,
}: Props) {
    const t: Texts = { ...EN, ...texts };

    const [filters, setFilters] = useState<ExtractOfOwnersFilters>({
        ...makeDefaultFilters(bookEntryTypes),
        ...initialFilters,
    });

    // ad-hoc input state for "add to selection" style fields
    const [postalCodeInput, setPostalCodeInput] = useState('');
    const [postalRangeFrom, setPostalRangeFrom] = useState('');
    const [postalRangeTo, setPostalRangeTo] = useState('');
    const [ageRangeFrom, setAgeRangeFrom] = useState('');
    const [ageRangeTo, setAgeRangeTo] = useState('');

    if (!isOpen) return null;

    const update = <K extends keyof ExtractOfOwnersFilters>(key: K, value: ExtractOfOwnersFilters[K]) => {
        setFilters((prev) => ({ ...prev, [key]: value }));
    };

    const updatePerType = (code: string, patch: Partial<PerTypeHoldings>) => {
        setFilters((prev) => ({
            ...prev,
            holdingsPerType: prev.holdingsPerType.map((row) =>
                row.code === code ? { ...row, ...patch } : row
            ),
        }));
    };

    // --- Post address helpers ---
    const addPostalCode = () => {
        const code = postalCodeInput.trim();
        if (!code || filters.postalCodes.includes(code)) return;
        update('postalCodes', [...filters.postalCodes, code]);
        setPostalCodeInput('');
    };
    const addPostalRange = () => {
        if (!postalRangeFrom.trim() || !postalRangeTo.trim()) return;
        const label = `${postalRangeFrom.trim()}-${postalRangeTo.trim()}`;
        update('postalCodeRanges', [...filters.postalCodeRanges, { from: postalRangeFrom, to: postalRangeTo }]);
        setPostalRangeFrom('');
        setPostalRangeTo('');
        void label;
    };

    // --- Sector helpers ---
    const toggleSector = (code: string) => {
        const isSelected = filters.sectors.includes(code);
        if (isSelected) {
            update('sectors', filters.sectors.filter((c) => c !== code));
        } else {
            // auto-include: selecting a parent brings in its children too
            const children = sectorOptions.filter((s) => s.parentCode === code).map((s) => s.code);
            update('sectors', [...new Set([...filters.sectors, code, ...children])]);
        }
    };

    // Flattened, depth-annotated sector list for the searchable picker.
    // depth is computed by walking parentCode chains — supports arbitrary nesting, not just 2 levels.
    const sectorSearchOptions = useMemo(() => {
        const depthOf = (code: string, seen = new Set<string>()): number => {
            const opt = sectorOptions.find((s) => s.code === code);
            if (!opt?.parentCode || seen.has(opt.parentCode)) return 0;
            seen.add(opt.parentCode);
            return 1 + depthOf(opt.parentCode, seen);
        };
        return sectorOptions.map((s) => ({
            value: s.code,
            label: `${s.code} ${s.label}`,
            depth: depthOf(s.code),
        }));
    }, [sectorOptions]);

    // --- Age group helpers ---
    const toggleAgeGroup = (group: string) => {
        const isSelected = filters.predefinedAgeGroups.includes(group);
        update(
            'predefinedAgeGroups',
            isSelected
                ? filters.predefinedAgeGroups.filter((g) => g !== group)
                : [...filters.predefinedAgeGroups, group]
        );
    };
    const addAgeRange = () => {
        if (!ageRangeFrom.trim() || !ageRangeTo.trim()) return;
        update('customAgeRanges', [...filters.customAgeRanges, { from: ageRangeFrom, to: ageRangeTo }]);
        setAgeRangeFrom('');
        setAgeRangeTo('');
    };

    const handleSubmit = () => {
        onContinue(filters);
    };

    return (
        <div className="eoo-filter" role="dialog" aria-modal="true" aria-label={t.title}>
            <h2 className="eoo-filter__title">{t.title}</h2>
            <div className="eoo-filter__divider" />

            {/* ===================== Range of holdings ===================== */}
            <section className="eoo-filter__section">
                <div className="eoo-filter__two-col">
                    <div className="eoo-filter__col-left">
                        <h3 className="eoo-filter__section-title">{t.rangeOfHoldings}</h3>
                        <RadioRow
                            name="holdingsMode"
                            value={filters.holdingsMode}
                            onChange={(v) => update('holdingsMode', v)}
                            options={[
                                { value: 'all', label: t.allHoldings },
                                { value: 'combined', label: t.numberOfHoldingsCombined },
                                { value: 'perType', label: t.numberOfHoldingsPerType },
                            ]}
                        />

                        {filters.holdingsMode === 'all' && (
                            <p className="eoo-filter__default-text">
                                By default all the holdings are selected. Select {t.numberOfHoldingsCombined} or{' '}
                                {t.numberOfHoldingsPerType} above to select a specific range of holdings to be
                                included into the report.
                            </p>
                        )}

                        {filters.holdingsMode === 'combined' && (
                            <div className="eoo-filter__subsection">
                                <p className="eoo-filter__subsection-label">{t.combinedHeading}</p>
                                <div className="eoo-filter__minmax-row">
                                    <span className="eoo-filter__row-label">{t.rangeOfHoldingsRadio}</span>
                                    <label className="eoo-filter__minmax-field">
                                        <span>{t.min}</span>
                                        <input
                                            type="text"
                                            value={filters.holdingsCombinedRange.min}
                                            onChange={(e) =>
                                                update('holdingsCombinedRange', {
                                                    ...filters.holdingsCombinedRange,
                                                    min: e.target.value,
                                                })
                                            }
                                        />
                                    </label>
                                    <label className="eoo-filter__minmax-field">
                                        <span>{t.max}</span>
                                        <input
                                            type="text"
                                            value={filters.holdingsCombinedRange.max}
                                            onChange={(e) =>
                                                update('holdingsCombinedRange', {
                                                    ...filters.holdingsCombinedRange,
                                                    max: e.target.value,
                                                })
                                            }
                                        />
                                    </label>
                                </div>
                            </div>
                        )}

                        {filters.holdingsMode === 'perType' && (
                            <div className="eoo-filter__subsection">
                                <p className="eoo-filter__subsection-label">{t.perTypeHeading}</p>
                                {bookEntryTypes.map((bookType) => {
                                    const row =
                                        filters.holdingsPerType.find((r) => r.code === bookType.code) ??
                                        { code: bookType.code, mode: 'all' as const, min: '', max: '' };
                                    return (
                                        <div key={bookType.code} className="eoo-filter__per-type-row">
                                            <div className="eoo-filter__per-type-label">
                                                <span className="eoo-filter__bold">{bookType.code}</span>
                                                <span className="eoo-filter__muted">{bookType.isin}</span>
                                            </div>
                                            <RadioRow
                                                name={`holdings-${bookType.code}`}
                                                value={row.mode}
                                                onChange={(v) => updatePerType(bookType.code, { mode: v })}
                                                options={[
                                                    { value: 'all', label: 'all holdings' },
                                                    { value: 'range', label: t.rangeOfHoldingsRadio },
                                                ]}
                                            />
                                            {row.mode === 'range' && (
                                                <div className="eoo-filter__minmax-row">
                                                    <label className="eoo-filter__minmax-field">
                                                        <span>{t.min}</span>
                                                        <input
                                                            type="text"
                                                            value={row.min}
                                                            onChange={(e) =>
                                                                updatePerType(bookType.code, { min: e.target.value })
                                                            }
                                                        />
                                                    </label>
                                                    <label className="eoo-filter__minmax-field">
                                                        <span>{t.max}</span>
                                                        <input
                                                            type="text"
                                                            value={row.max}
                                                            onChange={(e) =>
                                                                updatePerType(bookType.code, { max: e.target.value })
                                                            }
                                                        />
                                                    </label>
                                                </div>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                    </div>

                    <InfoBox
                        title={t.holdingsInfoTitle}
                        desc={filters.holdingsMode === 'perType' ? t.holdingsInfoPerTypeDesc : t.holdingsInfoCombinedDesc}
                    />
                </div>
            </section>

            <div className="eoo-filter__divider" />

            {/* ===================== Post address ===================== */}
            <section className="eoo-filter__section">
                <div className="eoo-filter__two-col">
                    <div className="eoo-filter__col-left">
                        <h3 className="eoo-filter__section-title">{t.postAddress}</h3>
                        <RadioRow
                            name="postAddressMode"
                            value={filters.postAddressMode}
                            onChange={(v) => update('postAddressMode', v)}
                            options={[
                                { value: 'all', label: t.selectAll },
                                { value: 'single', label: t.postAddresses },
                                { value: 'range', label: t.rangeOfPostAddresses },
                            ]}
                        />

                        {filters.postAddressMode === 'all' && (
                            <p className="eoo-filter__default-text">{t.postAddressDefault}</p>
                        )}

                        {filters.postAddressMode === 'single' && (
                            <div className="eoo-filter__subsection">
                                <label className="eoo-filter__field-label">{t.postalCode}</label>
                                <div className="eoo-filter__inline-add">
                                    <input
                                        type="text"
                                        value={postalCodeInput}
                                        onChange={(e) => setPostalCodeInput(e.target.value)}
                                        onKeyDown={(e) => e.key === 'Enter' && addPostalCode()}
                                    />
                                    <button type="button" className="eoo-filter__add-btn" onClick={addPostalCode}>
                                        {t.addToSelection} +
                                    </button>
                                </div>
                                {filters.postalCodes.length > 0 && (
                                    <>
                                        <span className="eoo-filter__selected-label">{t.selected}</span>
                                        <TagList
                                            items={filters.postalCodes}
                                            onRemove={(item) =>
                                                update(
                                                    'postalCodes',
                                                    filters.postalCodes.filter((c) => c !== item)
                                                )
                                            }
                                            onDeselectAll={() => update('postalCodes', [])}
                                            deselectLabel={t.deselectAll}
                                        />
                                    </>
                                )}
                            </div>
                        )}

                        {filters.postAddressMode === 'range' && (
                            <div className="eoo-filter__subsection">
                                <p className="eoo-filter__subsection-label">OR {t.rangeOfPostAddresses}</p>
                                <div className="eoo-filter__minmax-row">
                                    <label className="eoo-filter__minmax-field">
                                        <span>{t.from}</span>
                                        <input
                                            type="text"
                                            value={postalRangeFrom}
                                            onChange={(e) => setPostalRangeFrom(e.target.value)}
                                        />
                                    </label>
                                    <label className="eoo-filter__minmax-field">
                                        <span>{t.to}</span>
                                        <input
                                            type="text"
                                            value={postalRangeTo}
                                            onChange={(e) => setPostalRangeTo(e.target.value)}
                                        />
                                    </label>
                                    <button type="button" className="eoo-filter__add-btn" onClick={addPostalRange}>
                                        {t.addToSelection} +
                                    </button>
                                </div>
                                {filters.postalCodeRanges.length > 0 && (
                                    <>
                                        <span className="eoo-filter__selected-label">{t.selected}</span>
                                        <TagList
                                            items={filters.postalCodeRanges.map((r) => `${r.from} - ${r.to}`)}
                                            onRemove={(item) =>
                                                update(
                                                    'postalCodeRanges',
                                                    filters.postalCodeRanges.filter(
                                                        (r) => `${r.from} - ${r.to}` !== item
                                                    )
                                                )
                                            }
                                            onDeselectAll={() => update('postalCodeRanges', [])}
                                            deselectLabel={t.deselectAll}
                                        />
                                    </>
                                )}
                            </div>
                        )}
                    </div>

                    <InfoBox title={t.postAddressInfoTitle} desc={t.postAddressInfoDesc} />
                </div>
            </section>

            <div className="eoo-filter__divider" />

            {/* ===================== Country of residence / registration ===================== */}
            <section className="eoo-filter__section">
                <div className="eoo-filter__two-col">
                    <div className="eoo-filter__col-left">
                        <h3 className="eoo-filter__section-title">{t.country}</h3>
                        <RadioRow
                            name="countryMode"
                            value={filters.countryMode}
                            onChange={(v) => update('countryMode', v)}
                            options={[
                                { value: 'all', label: t.selectAll },
                                { value: 'select', label: t.selectCountries },
                            ]}
                        />

                        {filters.countryMode === 'all' && (
                            <p className="eoo-filter__default-text">{t.countryDefault}</p>
                        )}

                        {filters.countryMode === 'select' && (
                            <div className="eoo-filter__subsection">
                                <SearchableMultiSelect
                                    fieldLabel={t.countryLabel}
                                    placeholder="Type to search, e.g. Fi..."
                                    options={countryOptions.map((c) => ({ value: c, label: c }))}
                                    selected={filters.countries}
                                    matchMode="startsWith"
                                    onToggle={(value) =>
                                        filters.countries.includes(value)
                                            ? update('countries', filters.countries.filter((c) => c !== value))
                                            : update('countries', [...filters.countries, value])
                                    }
                                    onDeselectAll={() => update('countries', [])}
                                    selectedLabel={t.selected}
                                    deselectLabel={t.deselectAll}
                                />
                            </div>
                        )}
                    </div>

                    <InfoBox title={t.countryInfoTitle} desc={t.countryInfoDesc} />
                </div>
            </section>

            <div className="eoo-filter__divider" />

            {/* ===================== Sector classification ===================== */}
            <section className="eoo-filter__section">
                <div className="eoo-filter__two-col">
                    <div className="eoo-filter__col-left">
                        <h3 className="eoo-filter__section-title">{t.sectorClassification}</h3>
                        <RadioRow
                            name="sectorMode"
                            value={filters.sectorMode}
                            onChange={(v) => update('sectorMode', v)}
                            options={[
                                { value: 'all', label: t.selectAll },
                                { value: 'select', label: t.selectSectors },
                            ]}
                        />

                        {filters.sectorMode === 'all' && (
                            <p className="eoo-filter__default-text">{t.sectorDefault}</p>
                        )}

                        {filters.sectorMode === 'select' && (
                            <div className="eoo-filter__subsection">
                                <SearchableMultiSelect
                                    fieldLabel={t.sectorLabel}
                                    placeholder="Type to search, e.g. Domestic..."
                                    options={sectorSearchOptions}
                                    selected={filters.sectors}
                                    matchMode="contains"
                                    onToggle={toggleSector}
                                    onDeselectAll={() => update('sectors', [])}
                                    selectedLabel={t.selected}
                                    deselectLabel={t.deselectAll}
                                />
                            </div>
                        )}
                    </div>

                    <InfoBox title={t.sectorInfoTitle} desc={t.sectorInfoDesc} />
                </div>
            </section>

            <div className="eoo-filter__divider" />

            {/* ===================== Owner type ===================== */}
            <section className="eoo-filter__section">
                <div className="eoo-filter__two-col">
                    <div className="eoo-filter__col-left">
                        <h3 className="eoo-filter__section-title">{t.ownerType}</h3>
                        <RadioRow
                            name="ownerType"
                            value={filters.ownerType}
                            onChange={(v) => update('ownerType', v)}
                            options={[
                                { value: 'both', label: t.both },
                                { value: 'natural', label: t.naturalPersons },
                                { value: 'legal', label: t.legalPersons },
                            ]}
                        />
                    </div>
                    <InfoBox title={t.ownerType} desc={t.ownerTypeInfo} />
                </div>
            </section>

            <div className="eoo-filter__divider" />

            {/* ===================== Registration type ===================== */}
            <section className="eoo-filter__section">
                <div className="eoo-filter__two-col">
                    <div className="eoo-filter__col-left">
                        <h3 className="eoo-filter__section-title">{t.registrationType}</h3>
                        <RadioRow
                            name="registrationType"
                            value={filters.registrationType}
                            onChange={(v) => update('registrationType', v)}
                            options={[
                                { value: 'both', label: t.both },
                                { value: 'direct', label: t.directHoldingOwners },
                                { value: 'nominee', label: t.nomineeRegistrationCustodians },
                            ]}
                        />
                    </div>
                    <InfoBox title={t.registrationType} desc={t.registrationTypeInfo} />
                </div>
            </section>

            <div className="eoo-filter__divider" />

            {/* ===================== Direct marketing prohibitions ===================== */}
            <section className="eoo-filter__section">
                <div className="eoo-filter__two-col">
                    <div className="eoo-filter__col-left">
                        <h3 className="eoo-filter__section-title">{t.directMarketing}</h3>
                        <RadioRow
                            name="directMarketing"
                            value={filters.directMarketing}
                            onChange={(v) => update('directMarketing', v)}
                            options={[
                                { value: 'included', label: t.toBeIncluded },
                                { value: 'notIncluded', label: t.notToBeIncluded },
                            ]}
                        />
                    </div>
                    <InfoBox title={t.directMarketing} desc={t.directMarketingInfo} />
                </div>
            </section>

            <div className="eoo-filter__divider" />

            {/* ===================== Age groups ===================== */}
            <section className="eoo-filter__section">
                <div className="eoo-filter__two-col">
                    <div className="eoo-filter__col-left">
                        <h3 className="eoo-filter__section-title">{t.ageGroups}</h3>
                        <RadioRow
                            name="ageGroupMode"
                            value={filters.ageGroupMode}
                            onChange={(v) => update('ageGroupMode', v)}
                            options={[
                                { value: 'all', label: t.all },
                                { value: 'predefined', label: t.predefinedAgeGroups },
                                { value: 'custom', label: t.customAgeRange },
                            ]}
                        />

                        {filters.ageGroupMode === 'all' && (
                            <p className="eoo-filter__default-text">You can select pre-defined age groups or a custom age range.</p>
                        )}

                        {filters.ageGroupMode === 'predefined' && (
                            <div className="eoo-filter__subsection">
                                <select
                                    className="eoo-filter__sector-search"
                                    value=""
                                    onChange={(e) => e.target.value && toggleAgeGroup(e.target.value)}
                                >
                                    <option value="">{'\u2013'}</option>
                                    {ageGroupOptions.map((g) => (
                                        <option key={g} value={g}>
                                            {g}
                                        </option>
                                    ))}
                                </select>
                                <ul className="eoo-filter__option-list">
                                    {ageGroupOptions.map((g) => (
                                        <li
                                            key={g}
                                            className={
                                                'eoo-filter__option-list-item' +
                                                (filters.predefinedAgeGroups.includes(g)
                                                    ? ' eoo-filter__option-list-item--selected'
                                                    : '')
                                            }
                                            onClick={() => toggleAgeGroup(g)}
                                        >
                                            {filters.predefinedAgeGroups.includes(g) ? '\u2713 ' : ''}
                                            {g}
                                        </li>
                                    ))}
                                </ul>
                                {filters.predefinedAgeGroups.length > 0 && (
                                    <>
                                        <span className="eoo-filter__selected-label">{t.selected}</span>
                                        <TagList
                                            items={filters.predefinedAgeGroups}
                                            onRemove={(item) =>
                                                update(
                                                    'predefinedAgeGroups',
                                                    filters.predefinedAgeGroups.filter((g) => g !== item)
                                                )
                                            }
                                            onDeselectAll={() => update('predefinedAgeGroups', [])}
                                            deselectLabel={t.deselectAll}
                                        />
                                    </>
                                )}
                            </div>
                        )}

                        {filters.ageGroupMode === 'custom' && (
                            <div className="eoo-filter__subsection">
                                <p className="eoo-filter__subsection-label">OR {t.customAgeRange}</p>
                                <div className="eoo-filter__minmax-row">
                                    <label className="eoo-filter__minmax-field">
                                        <span>{t.from}</span>
                                        <input
                                            type="text"
                                            value={ageRangeFrom}
                                            onChange={(e) => setAgeRangeFrom(e.target.value)}
                                        />
                                    </label>
                                    <label className="eoo-filter__minmax-field">
                                        <span>{t.to}</span>
                                        <input
                                            type="text"
                                            value={ageRangeTo}
                                            onChange={(e) => setAgeRangeTo(e.target.value)}
                                        />
                                    </label>
                                    <button type="button" className="eoo-filter__add-btn" onClick={addAgeRange}>
                                        {t.addToSelection} +
                                    </button>
                                </div>
                                {filters.customAgeRanges.length > 0 && (
                                    <>
                                        <span className="eoo-filter__selected-label">{t.selected}</span>
                                        <TagList
                                            items={filters.customAgeRanges.map((r) => `${r.from}-${r.to}`)}
                                            onRemove={(item) =>
                                                update(
                                                    'customAgeRanges',
                                                    filters.customAgeRanges.filter((r) => `${r.from}-${r.to}` !== item)
                                                )
                                            }
                                            onDeselectAll={() => update('customAgeRanges', [])}
                                            deselectLabel={t.deselectAll}
                                        />
                                    </>
                                )}
                            </div>
                        )}
                    </div>

                    <InfoBox title={t.ageGroupsInfoTitle} desc={t.ageGroupsInfoDesc} />
                </div>
            </section>

            <div className="eoo-filter__divider" />

            {/* ===================== Only address information ===================== */}
            <section className="eoo-filter__section">
                <div className="eoo-filter__two-col">
                    <div className="eoo-filter__col-left">
                        <h3 className="eoo-filter__section-title">{t.onlyAddressInfo}</h3>
                        <label className="eoo-filter__checkbox">
                            <input
                                type="checkbox"
                                checked={filters.onlyAddressInfo}
                                onChange={(e) => update('onlyAddressInfo', e.target.checked)}
                            />
                            <span className="eoo-filter__checkbox-box" />
                            <span>{t.yes}</span>
                        </label>
                    </div>
                    <InfoBox title={t.onlyAddressInfoInfoTitle} desc={t.onlyAddressInfoInfoDesc} />
                </div>
            </section>

            <div className="eoo-filter__divider" />

            {/* ===================== Footer ===================== */}
            <div className="eoo-filter__footer">
                <p className="eoo-filter__price-note">{t.priceNote}</p>
                <div className="eoo-filter__actions">
                    <button type="button" className="eoo-filter__btn eoo-filter__btn--outlined" onClick={onCancel}>
                        {t.cancel}
                    </button>
                    <button type="button" className="eoo-filter__btn eoo-filter__btn--primary" onClick={handleSubmit}>
                        {t.continue}
                    </button>
                </div>
            </div>
        </div>
    );
}
