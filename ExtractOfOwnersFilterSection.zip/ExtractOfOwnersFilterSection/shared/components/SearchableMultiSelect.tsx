import { useState, useRef, useEffect, useMemo } from 'react';
import './SearchableMultiSelect.css';

export interface SearchableOption {
    value: string;   // unique key, e.g. country code or sector code
    label: string;   // display text searched against, e.g. "Finland" or "111211 Domestic corporations"
    depth?: number;   // optional indent level for hierarchical lists like sectors
}

interface Props {
    options: SearchableOption[];
    selected: string[];
    onToggle: (value: string) => void;
    onDeselectAll: () => void;
    placeholder?: string;
    fieldLabel?: string;
    deselectLabel?: string;
    selectedLabel?: string;
    /** 'startsWith' mirrors the Figma behavior (typing "Fi" -> Finland, Fiji). 'contains' is broader. */
    matchMode?: 'startsWith' | 'contains';
    maxResults?: number;
    emptyText?: string;
}

/**
 * Front-end owned search-as-you-type picker. Options are supplied as a flat
 * in-memory list (e.g. countries.json, or a flattened sector tree) — no
 * network call, filtering happens client-side on every keystroke.
 */
export default function SearchableMultiSelect({
    options,
    selected,
    onToggle,
    onDeselectAll,
    placeholder = 'Type to search...',
    fieldLabel,
    deselectLabel = 'Deselect all',
    selectedLabel = 'Selected:',
    matchMode = 'startsWith',
    maxResults = 50,
    emptyText = 'No matches',
}: Props) {
    const [query, setQuery] = useState('');
    const [isOpen, setIsOpen] = useState(false);
    const rootRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        function handleClickOutside(e: MouseEvent) {
            if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
                setIsOpen(false);
            }
        }
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const filtered = useMemo(() => {
        const q = query.trim().toLowerCase();
        if (!q) return options.slice(0, maxResults);
        const matcher =
            matchMode === 'startsWith'
                ? (label: string) => label.toLowerCase().startsWith(q)
                : (label: string) => label.toLowerCase().includes(q);
        return options.filter((o) => matcher(o.label)).slice(0, maxResults);
    }, [options, query, matchMode, maxResults]);

    const selectedOptions = options.filter((o) => selected.includes(o.value));

    return (
        <div className="sms" ref={rootRef}>
            {fieldLabel && <label className="sms__label">{fieldLabel}</label>}

            <div className="sms__input-wrap">
                <input
                    type="text"
                    className="sms__input"
                    value={query}
                    placeholder={placeholder}
                    onFocus={() => setIsOpen(true)}
                    onChange={(e) => {
                        setQuery(e.target.value);
                        setIsOpen(true);
                    }}
                />
                <svg className="sms__search-icon" width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <circle cx="7" cy="7" r="5" stroke="currentColor" strokeWidth="1.5" />
                    <path d="M11 11L14.5 14.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                </svg>
            </div>

            {isOpen && (
                <ul className="sms__dropdown" role="listbox">
                    {filtered.length === 0 && <li className="sms__empty">{emptyText}</li>}
                    {filtered.map((opt) => {
                        const isSelected = selected.includes(opt.value);
                        return (
                            <li
                                key={opt.value}
                                role="option"
                                aria-selected={isSelected}
                                className={'sms__option' + (isSelected ? ' sms__option--selected' : '')}
                                style={opt.depth ? { paddingLeft: `${12 + opt.depth * 18}px` } : undefined}
                                onClick={() => onToggle(opt.value)}
                            >
                                <span
                                    className={'sms__check' + (isSelected ? ' sms__check--on' : '')}
                                    aria-hidden="true"
                                >
                                    {isSelected ? '\u2713' : ''}
                                </span>
                                {opt.label}
                            </li>
                        );
                    })}
                </ul>
            )}

            {selectedOptions.length > 0 && (
                <>
                    <span className="sms__selected-label">{selectedLabel}</span>
                    <div className="sms__tag-row">
                        {selectedOptions.map((opt) => (
                            <span key={opt.value} className="sms__tag">
                                {opt.label}
                                <button
                                    type="button"
                                    className="sms__tag-remove"
                                    onClick={() => onToggle(opt.value)}
                                    aria-label={`Remove ${opt.label}`}
                                >
                                    &times;
                                </button>
                            </span>
                        ))}
                        <button type="button" className="sms__deselect-all" onClick={onDeselectAll}>
                            {deselectLabel} <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </>
            )}
        </div>
    );
}
