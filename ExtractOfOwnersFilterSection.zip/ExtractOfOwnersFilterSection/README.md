# ExtractOfOwnersFilterSection

Standalone, drop-in component matching the `DatePicker` / pricing-note pattern
already used in `ois-ui`. This is **step 2** of the Extract of Owners
subscription flow — it renders after the user finishes step 1 in
`SubscriptionModal` (Status date, Book-entry types, reference) and clicks
"Order details 2/2".

## Files

- `ExtractOfOwnersFilterSection.tsx`
- `ExtractOfOwnersFilterSection.css`

Drop both into `src/components/ExtractOfOwnersFilterSection/`.

## Default state

Every section defaults to its broadest option, exactly as specified:

| Section | Default |
|---|---|
| Range of holdings | All holdings |
| Post address | Select all |
| Country of residence/registration | Select all |
| Sector classification | Select all |
| Owner type | Both |
| Registration type | Both |
| Direct marketing prohibitions | To be included |
| Age groups | All |
| Only address information | No (unchecked) |

Sub-fields for a section only render once the user moves off that section's
default radio — each section's reveal is independent of the others (same
behavior you flagged for Range of holdings applies everywhere: Post address,
Country, Sectors, Age groups).

## Basic usage

```tsx
import { useState } from 'react';
import ExtractOfOwnersFilterSection, {
    ExtractOfOwnersFilters,
} from '@/components/ExtractOfOwnersFilterSection/ExtractOfOwnersFilterSection';

function SubscriptionFlow() {
    const [step, setStep] = useState<1 | 2>(1);
    const [step1Data, setStep1Data] = useState(/* Status date, book-entries, reference from SubscriptionModal step 1 */);

    if (step === 2) {
        return (
            <ExtractOfOwnersFilterSection
                isOpen
                bookEntryTypes={step1Data.selectedBookEntries} // pass through from step 1
                onCancel={() => setStep(1)}
                onContinue={(filters: ExtractOfOwnersFilters) => {
                    // merge with step1Data and submit / navigate to price view
                    submitOrder({ ...step1Data, ...filters });
                }}
            />
        );
    }

    // ...render step 1 (existing SubscriptionModal content)
}
```

## Props

| Prop | Type | Default | Notes |
|---|---|---|---|
| `isOpen` | `boolean` | — | required |
| `bookEntryTypes` | `{code, isin}[]` | Euroflex A/B sample | pass the types the user picked in step 1 so "Number of holdings per Book-Entry Type" matches |
| `countryOptions` | `string[]` | 6-country sample list | swap for your real country master list |
| `sectorOptions` | `{code, label, parentCode?}[]` | 4-row sample tree | swap for your real sector classification tree; `parentCode` drives auto-include of subcodes |
| `ageGroupOptions` | `string[]` | 5 sample buckets | swap for your real pre-defined age groups |
| `initialFilters` | `Partial<ExtractOfOwnersFilters>` | — | for re-opening a previously configured order |
| `onCancel` | `() => void` | — | required |
| `onContinue` | `(filters: ExtractOfOwnersFilters) => void` | — | required, fires on Continue with the full filter object |
| `texts` | `Partial<Texts>` | English | pass fi/sv overrides same as your other components |

## Shape of `onContinue` payload

```ts
interface ExtractOfOwnersFilters {
    holdingsMode: 'all' | 'combined' | 'perType';
    holdingsCombinedRange: { min: string; max: string };
    holdingsPerType: { code: string; mode: 'all' | 'range'; min: string; max: string }[];

    postAddressMode: 'all' | 'single' | 'range';
    postalCodes: string[];
    postalCodeRanges: { from: string; to: string }[];

    countryMode: 'all' | 'select';
    countries: string[];

    sectorMode: 'all' | 'select';
    sectors: string[];

    ownerType: 'both' | 'natural' | 'legal';
    registrationType: 'both' | 'direct' | 'nominee';
    directMarketing: 'included' | 'notIncluded';

    ageGroupMode: 'all' | 'predefined' | 'custom';
    predefinedAgeGroups: string[];
    customAgeRanges: { from: string; to: string }[];

    onlyAddressInfo: boolean;
}
```

## Styling

Uses your `--ois-*` design tokens where they exist (`--ois-color-primary`,
`--ois-space-*`, `--ois-text-*`) with hard-coded fallbacks so it still looks
right if the token file isn't loaded in isolation (e.g. Storybook). Swap the
fallback hexes in `.eoo-filter { --eoo-teal: ...; }` if your teal differs
from `#00B9A4`.

## v2 changes — real search-as-you-type

Country and Sector are no longer a static dropdown/click-list. Both now use
the shared `SearchableMultiSelect` component (`shared/components/`), backed
by front-end owned JSON data — no backend call, filtered client-side on
every keystroke:

- **Country** — reads `shared/data/countries.json` (195 countries, ISO
  code + name). Typing `Fi` prefix-matches `Finland`, `Fiji`, etc., exactly
  like your Figma screenshot. Swap the JSON file for your real master list
  any time; the shape is `{ code: string; name: string }[]`.
- **Sector** — searches the existing `sectorOptions` tree by **contains**
  match against `"<code> <label>"` (so typing either the code or the label
  text works), and keeps proper indentation by walking the `parentCode`
  chain to compute depth (supports any nesting depth, not just 2 levels).
  Parent auto-includes children on select, same as before.

Both pickers show selected items as removable tag chips with a
"Deselect all", same interaction pattern as Post address and Age groups.

### Reusable component

`shared/components/SearchableMultiSelect.tsx` isn't specific to this
screen — drop it into any other filter/picker in the app that needs the
same "type to filter a flat or hierarchical list" behavior. Props:

```ts
interface SearchableOption {
    value: string;
    label: string;   // what's searched against
    depth?: number;   // optional indent for hierarchical lists
}

interface Props {
    options: SearchableOption[];
    selected: string[];
    onToggle: (value: string) => void;
    onDeselectAll: () => void;
    matchMode?: 'startsWith' | 'contains'; // default 'startsWith'
    maxResults?: number; // default 50, caps dropdown length for huge lists
    // + label/placeholder/text overrides
}
```

## Still pending — Major Owners dropdown

Separately from this component: you asked for a dropdown just above the
Cancel/Continue footer in the subscription flow's common section file,
shown only when the report type is Major Owners. That's now built as its
own standalone component — see `NumberOfOwnersSection/` (delivered
alongside this zip). I still don't have your actual common-section file to
wire it into directly — upload it whenever you're ready.
